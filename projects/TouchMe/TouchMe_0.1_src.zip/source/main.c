#include <PA9.h>
#include <stdio.h>

// PAGfxConverter Include
#include "gfx/all_gfx.c"
#include "gfx/all_gfx.h"

#include "sprites.h"
#ifdef PLAY_SOUND
  #include "intro_raw.h"
  #include "music_raw.h"
  #include "bomb_raw.h"
  #include "touch_raw.h"
#endif

u16 g_beat = BEAT + 1;
u8 g_beatAdjust = BEAT_ADJUST;
u16 g_beatCounter = 0;
u8 g_BOMB = 0;

u16 g_combo = 0;
u16 g_maxCombo = 0;
u16 g_BOMBed = 0;
u16 g_multiBOMB = 0;
u16 g_TOUCHed = 0;
u16 g_miss = 0;

void printText(const bool p_screen, const u16 p_x, const u16 p_y, const char * p_text)
{
  u8 l_i = 0;
  u16 l_y = p_y;
  const u8 l_length = strlen(p_text);
  for (l_i = 0; l_i < l_length; ++l_i)
  {
    // (bool screen, u16 x, u16 y, char letter)
    PA_SetTileLetter(p_screen, p_x, l_y, p_text[l_i]);
    ++l_y;
  }
}

// -->
void addSprite(const u8 p_number)
{
  if ((p_number > 0) && (p_number <= NB_SPRITES))
  {
    if (!g_sprites[p_number].created)
    {
      // The sprite is not created => create it
      switch (p_number)
      {
//------------------------------------------------------------------------------
        case 1: // Koopa aviateur
          g_sprites[p_number].x = PA_RandMinMax(112, 256 - g_sprites[p_number].w) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = -32;
          g_sprites[p_number].vy = 320;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)koopaAviateur_Sprite, OBJ_SIZE_64X64, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 7, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 2: // Koopa lunettes
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 1 << 8;
          // transformation
          g_sprite02.state = 0;
          g_sprite02.yTransformation = PA_RandMinMax(0, 120 - g_sprites[p_number].w);
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)koopaLunettes_Sprite, OBJ_SIZE_64X64, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 7, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 3: // Koopa lunettes + fusil
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 384;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)koopaLunettesFusil_Sprite, OBJ_SIZE_64X64, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 7, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 4: // Shyguy volant
          g_sprites[p_number].x = PA_RandMinMax(116, 256 - g_sprites[p_number].w) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 1 << 8;
          if ((g_sprites[p_number].x >> 8) < g_sprite04.xLimit)
            g_sprite04.g = PA_RandMinMax(1, 2);
          else
            g_sprite04.g = -PA_RandMinMax(1, 2);
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)shyguyVolant_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed, type, ncycles)
          PA_DualStartSpriteAnimEx(p_number, 0, 3, g_sprites[p_number].animSpeed, ANIM_UPDOWN, -1);
          break;
//------------------------------------------------------------------------------
        case 5: // Shyguy volant + fusil
          g_sprites[p_number].x = PA_RandMinMax(116, 256 - g_sprites[p_number].w) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 2 << 8;
          if ((g_sprites[p_number].x >> 8) < g_sprite05.xLimit)
            g_sprite05.g = 2;
          else
            g_sprite05.g = -2;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)shyguyVolantFusil_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed, type, ncycles)
          PA_DualStartSpriteAnimEx(p_number, 0, 3, g_sprites[p_number].animSpeed, ANIM_UPDOWN, -1);
          break;
//------------------------------------------------------------------------------
        case 6: // Lakitu 1
          g_sprites[p_number].x = PA_RandMinMax(160, 250 - g_sprites[p_number].w) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 768;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)lakitu1_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          break;
//------------------------------------------------------------------------------
        case 7: // Lakitu 2
          g_sprites[p_number].x = PA_RandMinMax(160, 250 - g_sprites[p_number].w) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 256;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)lakitu2_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          break;
//------------------------------------------------------------------------------
        case 8: // Koopa nazi
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 416;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)koopaNazi_Sprite, OBJ_SIZE_64X64, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 7, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 9: // Koopa bazooka
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 1 << 8;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)koopaBazooka_Sprite, OBJ_SIZE_64X64, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 7, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 10: // Shyguy
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 224;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)shyguy_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 6, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 11: // Shyguy + fusil
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 288;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)shyguyFusil_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 6, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        case 12: // Goomba
          g_sprites[p_number].x = (GROUND_X - g_sprites[p_number].ground) << 8;
          g_sprites[p_number].y = -g_sprites[p_number].w << 8;
          g_sprites[p_number].vx = 0;
          g_sprites[p_number].vy = 192;
          // Create sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
          PA_DualCreateSprite(p_number, (void*)goomba_Sprite, OBJ_SIZE_32X32, 1, 0, g_sprites[p_number].x >> 8, g_sprites[p_number].y >> 8);
          // Start the animation (sprite_number, first_frame, last_frame, speed)
          PA_DualStartSpriteAnim(p_number, 0, 6, g_sprites[p_number].animSpeed);
          break;
//------------------------------------------------------------------------------
        default:
          break;
      }
      // common init
      g_sprites[p_number].created = true;
      g_sprites[p_number].alive = true;
      // init rotation
      g_sprites[p_number].rotset = p_number - 1;
      g_sprites[p_number].rotAngle = 0;
      // init rotset (rotset, angle)
      PA_DualSetRotsetNoZoom(g_sprites[p_number].rotset, 0);
      // (sprite, rotset)
      PA_DualSetSpriteRotEnable(p_number, g_sprites[p_number].rotset);
    }
  }
}

void addRandomSprite(void)
{
  u8 l_freeSprites[NB_SPRITES];
  u8 l_nbFreeSprites = 0;
  u8 l_nbFreeMin = 0;
  u8 l_i;
  
  for (l_i = 1; l_i <= NB_SPRITES; ++l_i)
  {
    if (!g_sprites[l_i].created)
    {
      // add the sprite to the free sprites list
      l_freeSprites[l_nbFreeSprites] = l_i;
      ++l_nbFreeSprites;
    }
  }
  
  if (g_beatCounter >= 104)
    // 12 sprites created max
    l_nbFreeMin = 0;
  if (g_beatCounter >= 88)
    // 8 sprites created max
    l_nbFreeMin = 4;
  else if (g_beatCounter >= 64)
    // 7 sprites created max
    l_nbFreeMin = 5;
  else if (g_beatCounter >= 40)
    // 6 sprites created max
    l_nbFreeMin = 6;
  else if (g_beatCounter >= 24)
    // 5 sprites created max
    l_nbFreeMin = 7;
  else
    // 4 sprites created max
    l_nbFreeMin = 8;
    
  if (l_nbFreeSprites > l_nbFreeMin)
  {
    addSprite(l_freeSprites[PA_RandMinMax(0, l_nbFreeSprites - 1)]);
  }
}

void removeSprite(const u8 p_number)
{
  if ((p_number > 0) && (p_number <= NB_SPRITES))
  {
    if (g_sprites[p_number].created)
    {
      // (sprite)
      PA_DualStopSpriteAnim(p_number);
      // Sprite exists => remove it (number)
      PA_DualDeleteSprite(p_number);
      g_sprites[p_number].created = false;
      g_sprites[p_number].alive = false;
    }
  }
}

void removeSprites(void)
{
  u8 l_i;
  for (l_i = 1; l_i <= NB_SPRITES; ++l_i)
  {
    removeSprite(l_i);
  }
}

// -->
void moveSprites(void)
{
  u8 l_i;
  for (l_i = 1; l_i <= NB_SPRITES; ++l_i)
  {
    if (g_sprites[l_i].created)
    {
      if (g_sprites[l_i].alive)
      {
        // Sprite-specific move
        switch (l_i)
        {
//------------------------------------------------------------------------------
          case 2: // Koopa lunettes
            switch (g_sprite02.state)
            {
              case 0:
                if (((g_sprites[l_i].y >> 8) >= g_sprite02.yTransformation)
                    && (g_beat ==  BEAT))
                {
                  PA_DualStopSpriteAnim(l_i);
                  PA_DualStartSpriteAnim(l_i, 8, 12, g_sprites[l_i].animSpeed - 2);
                  g_sprite02.state = 1;
                }
                break;
              case 1:
                if (PA_DualGetSpriteAnimFrame(l_i) == 12)
                {
                  PA_DualStopSpriteAnim(l_i);
                  PA_DualStartSpriteAnim(l_i, 12, 15, g_sprites[l_i].animSpeed);
                  g_sprites[l_i].vy = 2 << 8;
                  g_sprite02.state = 2;
                }
              default:
                break;
            }
            break;
//------------------------------------------------------------------------------
          case 4: // Shyguy volant
            g_sprites[l_i].vx += g_sprite04.g;
            if (((g_sprites[l_i].x >> 8) < g_sprite04.xLimit) && (g_sprites[l_i].vx < 0))
              g_sprite04.g = PA_RandMinMax(1, 2);
            else if (((g_sprites[l_i].x >> 8) > g_sprite04.xLimit) && (g_sprites[l_i].vx > 0))
              g_sprite04.g = -PA_RandMinMax(1, 2);
            break;
//------------------------------------------------------------------------------
          case 5: // Shyguy volant + fusil
            g_sprites[l_i].vx += g_sprite05.g;
            if (((g_sprites[l_i].x >> 8) < g_sprite05.xLimit) && (g_sprites[l_i].vx < 0))
              g_sprite05.g = 2;
            else if (((g_sprites[l_i].x >> 8) > g_sprite05.xLimit) && (g_sprites[l_i].vx > 0))
              g_sprite05.g = -2;
            break;
//------------------------------------------------------------------------------
          case 7: // Lakitu 2
            g_sprites[l_i].vy += 2;
            break;
//------------------------------------------------------------------------------
          case 11: // Shyguy + fusil
            if (g_beat == BEAT)
            {
              if (
                  (g_sprites[l_i].vy > 0) &&
                  (((g_sprites[l_i].y > 0) && ((g_sprites[l_i].y >> 8) < 192 - g_sprites[l_i].w)) ||
                  (((g_sprites[l_i].y >> 8) > 192 + SCREEN_SPACE) && ((g_sprites[l_i].y >> 8) < 384 + SCREEN_SPACE - g_sprites[l_i].w)))
                 )
              {
                // shyguy is walking
                if (PA_RandMinMax(0, 3) == 0)
                {
                  // duck
                  g_sprites[l_i].vy = 0;
                  PA_DualStopSpriteAnim(l_i);
                  PA_DualSetSpriteAnim(l_i, 7);
                }
              }
              else
              {
                // shyguy is ducking
                if (PA_RandMinMax(0, 2) > 0)
                {
                  g_sprites[l_i].vy = 288;
                  PA_DualStartSpriteAnim(l_i, 0, 6, g_sprites[l_i].animSpeed);
                }
              }
            }
            break;
//------------------------------------------------------------------------------
          case 12: // Goomba
            // check end of jump
            if ((g_sprites[l_i].x >> 8) < (GROUND_X - g_sprites[l_i].ground))
            {
              // end of jump
              g_sprites[l_i].x = (GROUND_X - g_sprites[l_i].ground) << 8;
              g_sprites[l_i].vx = 0;
              // (sprite_number, first_frame, last_frame, speed)
              PA_DualStartSpriteAnim(l_i, 0, 6, g_sprites[l_i].animSpeed);
            }
            // Manage jump
            if ((g_beat == BEAT) &&
                ((g_sprites[l_i].x >> 8) == (GROUND_X - g_sprites[l_i].ground)) &&
                (PA_RandMinMax(0, 2) == 0))
            {
              // jump (sprite)
              PA_DualStopSpriteAnim(l_i);
              // (sprite, animframe)
              PA_DualSetSpriteAnim(l_i, 7);
              g_sprites[l_i].vx = PA_RandMinMax(800, 1200);
            }
            // add gravity
            if ((g_sprites[l_i].x >> 8) > (GROUND_X - g_sprites[l_i].ground))
            {
              g_sprites[l_i].vx -= g_sprite12.g;
              if ((g_sprites[l_i].vx <= 0) && (PA_DualGetSpriteAnimFrame(l_i) != 8))
                PA_DualSetSpriteAnim(l_i, 8);
            }
            break;
//------------------------------------------------------------------------------
          default:
            break;
        }
      }
      else
      {
        // sprite is dead
        g_sprites[l_i].vx -= CORPSE_GRAVITY;
        // (rotset, angle)
        PA_DualSetRotsetNoZoom(g_sprites[l_i].rotset, g_sprites[l_i].rotAngle);
        g_sprites[l_i].rotAngle += (g_sprites[l_i].rotSpeed >> 8);
        g_sprites[l_i].rotAngle &= 511;
        // rotation slowdown
        if ((g_sprites[l_i].rotSpeed >> 8) > 8)
          g_sprites[l_i].rotSpeed -= 64;
      }
      // Move sprite
      g_sprites[l_i].x += g_sprites[l_i].vx;
      g_sprites[l_i].y += g_sprites[l_i].vy;
      // (sprite, x, y)
      PA_DualSetSpriteXY(l_i, g_sprites[l_i].x >> 8, g_sprites[l_i].y >> 8);
    }
  }
}

void checkSpritesPosition(void)
{
  u8 l_i;
  for (l_i = 1; l_i <= NB_SPRITES; ++l_i)
  {
    if (g_sprites[l_i].created)
    {
      // Sprite exists => we check its position
      if (
            ((g_sprites[l_i].y >> 8) > 384 + SCREEN_SPACE) ||
            ((g_sprites[l_i].y >> 8) < -g_sprites[l_i].w) ||
            ((g_sprites[l_i].x >> 8) < -g_sprites[l_i].w)
          )
      {
        // check whether the sprite was alive
        if (g_sprites[l_i].alive)
        {
          // reset combo
          g_combo = 0;
          // miss +1
          ++g_miss;
        }
        // Sprite is out of the screen => we delete it
        removeSprite(l_i);
      }
    }
  }
}

// -->
void checkSpritesTouch(void)
{
  u8 l_i;
  bool l_spriteBombed = false;
  bool l_spriteTouched = false;
  
  // manage BOMB
  if (g_BOMB > 0)
    --g_BOMB;
  if (g_BOMB == 1)
    // hide BOMB (sprite, x, y)
    PA_DualSetSpriteXY(0, -32, 0);
  
  for (l_i = 1; l_i <= NB_SPRITES; ++l_i)
  {
    if (g_sprites[l_i].alive)
    {
      // Sprite is alive => we check if touched
      if (Stylus.Newpress && PA_SpriteTouched(l_i))
      {
        // Sprite is touched => we kill it
        g_sprites[l_i].alive = false;
        // (sprite)
        PA_DualStopSpriteAnim(l_i);
        
        // sprite-specific
        switch (l_i)
        {
//------------------------------------------------------------------------------
          case 1: // Koopa aviateur
          case 3: // Koopa lunettes + fusil
          case 4: // Shyguy volant
          case 5: // Shyguy volant + fusil
          case 8: // Koopa nazi
          case 9: // Koopa bazooka
          case 10: // Shyguy
          case 11: // Shyguy + fusil
            // (sprite, animframe)
            PA_DualSetSpriteAnim(l_i, 0);
            break;
//------------------------------------------------------------------------------
          case 2: // Koopa lunettes
            PA_DualSetSpriteAnim(l_i, 16);
            break;
          case 12: // Goomba
            PA_DualSetSpriteAnim(l_i, 2);
            break;
          default:
            break;
        }
        
        // check rythm
        if (((g_beat >= BEAT - BEAT_PERFECT) && (g_beat <= BEAT + BEAT_PERFECT)) ||        // beat
            ((g_beat >= OFFBEAT - BEAT_PERFECT) && (g_beat <= OFFBEAT + BEAT_PERFECT)))    // backbeat
        {
          if (l_spriteBombed)
          {
            // two (or more) ennemies BOMBed at the same time
            ++g_multiBOMB;
          }
          else
          {
            #ifdef PLAY_SOUND
            // play sound (channel, sound)
            PA_PlaySimpleSound(1, bomb_raw);
            #endif
          }
          l_spriteBombed = true;
          // BOMB ! (sprite, x, y)
          PA_DualSetSpriteXY(0, Stylus.X - 16, Stylus.Y - 16 + 192 + SCREEN_SPACE);
          g_BOMB = BOMB_LENGTH;
          // BOMB jump
          g_sprites[l_i].vx += CORPSE_BJUMP;
          if (g_sprites[l_i].vx > CORPSE_BJUMP)
            g_sprites[l_i].vx = CORPSE_BJUMP;
          // rotation speed
          g_sprites[l_i].rotSpeed = ROTATION_BSPEED << 8;
          // combo + 1
          ++g_combo;
          if (g_combo > g_maxCombo)
            g_maxCombo = g_combo;
          // BOMBed + 1
          ++g_BOMBed;
        }
        else
        {
          #ifdef PLAY_SOUND
          if (!l_spriteTouched)
            // play sound (channel, sound)
            PA_PlaySimpleSound(1, touch_raw);
          #endif
          l_spriteTouched = true;
          // out of rythm => little jump
          g_sprites[l_i].vx += CORPSE_JUMP;
          if (g_sprites[l_i].vx > CORPSE_JUMP)
            g_sprites[l_i].vx = CORPSE_JUMP;
          // rotation speed
          g_sprites[l_i].rotSpeed = ROTATION_SPEED << 8;
          // reset combo
          g_combo = 0;
          // nb touched + 1
          ++g_TOUCHed;
        }
      }
    }
  }
}

void manageBeat(void)
{
  --g_beat;
  switch(g_beat)
  {
    case BEAT:
      // (bool screen, s8 bright)
      PA_SetBrightness(0, 3);
      // (bool screen, s8 bright)
      PA_SetBrightness(1, 3);
      ++g_beatCounter;
      break;
    case BEAT-2:
      // (bool screen, s8 bright)
      PA_SetBrightness(0, 2);
      // (bool screen, s8 bright)
      PA_SetBrightness(1, 2);
      break;
    case BEAT-4:
      // (bool screen, s8 bright)
      PA_SetBrightness(0, 1);
      // (bool screen, s8 bright)
      PA_SetBrightness(1, 1);
      break;
    case 0:
      --g_beatAdjust;
      // (bool screen, s8 bright)
      PA_SetBrightness(0, 0);
      // (bool screen, s8 bright)
      PA_SetBrightness(1, 0);
      g_beat = BEAT_COUNT;
      if (g_beatAdjust == 0)
      {
        ++g_beat;
        g_beatAdjust = BEAT_ADJUST;
      }
      break;
    default:
      break;
  }
}

bool intro(const bool p_temporisation)
{
  u16 l_i = 0;
  bool l_loop = true;
  bool l_return = false;

  // first iteration inactive if asked so
  if (p_temporisation)
  {
    #ifdef PLAY_SOUND
    // play intro (channel, data)
    PA_PlaySimpleSound(0, intro_raw);
    #endif
    for (l_i = 0; l_i < BEAT_INTRO; ++l_i)
      PA_WaitForVBL();
  }
  
  printText(0, 16, 8, "TOUCH ME");

  while (l_loop)
  {
    #ifdef PLAY_SOUND
    // play intro (channel, data)
    PA_PlaySimpleSound(0, intro_raw);
    #endif
    for (l_i = 0; l_i < BEAT_INTRO; ++l_i)
    {
      if (l_loop && Stylus.Newpress)
      {
        // (screen)
        PA_ClearTextBg(0);
        PA_ClearTextBg(1);
        if(Pad.Held.R)
        {
          l_return = true;
        }
        else
        {
          // Load backgrounds with their palettes
          PA_LoadTiledBg(0, 3, bg0);
          PA_LoadTiledBg(1, 3, bg1);
        }
        // (screen, x, y, text)
        printText(0, 16, 9, "READY");
        // End loop at the next intro iteration
        l_loop = false;
      }
      PA_WaitForVBL();
    }
  }
  
  return l_return;
}

void initGlobalVariables(void)
{
  // init of global variables
  g_beat = BEAT + 1;
  g_beatAdjust = BEAT_ADJUST;
  g_beatCounter = 0;
  g_BOMB = 0;
  g_combo = 0;
  g_maxCombo = 0;
  g_BOMBed = 0;
  g_multiBOMB = 0;
  g_TOUCHed = 0;
  g_miss = 0;
}

// Main function
int main(void)
{
  u8 l_state = 0;
  u16 l_score = 0;
  char l_message[24];
  bool l_BW = false;
  
  // PAlib init
  PA_Init();
  PA_InitVBL();
  
  // init sprites
  initSprites();
  
  // (screen, bg)
  PA_InitText(0, 0);
  PA_InitText(1, 0);
  // (screen, bg, font)
  PA_InitCustomText(0, 0, nesFont);
  PA_InitCustomText(1, 0, nesFont);
  
  #ifdef PLAY_SOUND
    PA_InitSound();
    // (volume, freq, format)
    PA_SetDefaultSound(127, 11025, 0);
  #endif
  
  // Load the sprite palette for both screens
  // (screen, palette_number, palette)
  PA_LoadSpritePal(0, 0, (void*)TouchMe_Pal);
  PA_LoadSpritePal(1, 0, (void*)TouchMe_Pal);
  
  while (1)
  {
    switch (l_state)
    {
      case 0: // title screen
        if (!l_BW)
        {
          // Load B&W backgrounds with their palettes
          PA_LoadTiledBg(0, 3, bg0nb);
          PA_LoadTiledBg(1, 3, bg1nb);
        }
        // create BOMB sprite (sprite_number, sprite, size, color_mode, palette, X, Y)
        PA_DualCreateSprite(0, (void*)bomb_Sprite, OBJ_SIZE_32X32, 1, 0, -32, 0);
        if (g_beatCounter == 0)
        {
          // first game => display general info
          printText(1, 18, 1, "TOUCH ME (I'M FAMOUS)");
          printText(1, 16, 1, "VERSION: 0.1");
          printText(1, 15, 1, "BY: MIA");
          printText(1, 14, 1, "MUSIC: SOSO");
          // intro without temporisation
          l_BW = intro(false);
        }
        else
        {
          // not first game => display scores
          // compute score
          l_score = (10 * g_BOMBed) + (3 * g_TOUCHed);
          l_score += 10 * g_maxCombo;
          l_score += 20 * g_multiBOMB;
          sprintf(l_message, "SCORE: %d", l_score);
          printText(1, 19, 1, l_message);
          sprintf(l_message, "BOMBED: %d", g_BOMBed);
          printText(1, 17, 1, l_message);
          sprintf(l_message, "MULTIBOMBED: %d", g_multiBOMB);
          printText(1, 16, 1, l_message);
          sprintf(l_message, "MAX COMBO: %d", g_maxCombo);
          printText(1, 15, 1, l_message);
          sprintf(l_message, "TOUCHED: %d", g_TOUCHed);
          printText(1, 14, 1, l_message);
          sprintf(l_message, "MISSED: %d", g_miss);
          printText(1, 13, 1, l_message);
          // intro with temporisation
          l_BW = intro(true);
        }
        // reset globals
        initGlobalVariables();
        // (screen)
        PA_ClearTextBg(0);
        PA_ClearTextBg(1);
        // Go to game state
        l_state = 1;
        break;
      case 1:
        #ifdef PLAY_SOUND
        // play music (channel, data)
        PA_PlaySimpleSound(0, music_raw);
        #endif
        // game loop
        while (g_beatCounter <= TOTAL_BEATS)
        {
          manageBeat();
          if ((g_beat == BEAT) || (g_beat == OFFBEAT))
          {
            addRandomSprite();
          }
          moveSprites();
          checkSpritesPosition();
          checkSpritesTouch();
          PA_WaitForVBL();
        }
        // reset brightness
        PA_SetBrightness(0, 0);
        PA_SetBrightness(1, 0);
        // remove all sprites
        removeSprites();
        // remove BOMB sprite
        PA_DualDeleteSprite(0);
        // (screen)
        PA_ClearTextBg(0);
        PA_ClearTextBg(1);
        l_state = 0;
        break;
      default:
        break;
    }
  }
  
  return 0;
}
