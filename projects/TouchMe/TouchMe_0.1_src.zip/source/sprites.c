#include "sprites.h"

void initSprites(void)
{
  // Init all sprites
  u8 l_i;
  for (l_i = 0; l_i <= NB_SPRITES; ++l_i)
  {
    g_sprites[l_i].x = 0;
    g_sprites[l_i].y = 0;
    g_sprites[l_i].vx = 0;
    g_sprites[l_i].vy = 0;
    g_sprites[l_i].w = 0;
    g_sprites[l_i].rotset = 0;
    g_sprites[l_i].rotAngle = 0;
    g_sprites[l_i].rotSpeed = 0;
    g_sprites[l_i].created = false;
    g_sprites[l_i].alive = false;
    g_sprites[l_i].animSpeed = 0;
    g_sprites[l_i].ground = 0;
    
    switch(l_i)
    {
//------------------------------------------------------------------------------
      case 1:
        // Koopa aviateur
        g_sprites[l_i].w = 64;
        g_sprites[l_i].animSpeed = 16;
        break;
//------------------------------------------------------------------------------
      case 2:
        // Koopa lunettes
        g_sprites[l_i].w = 64;
        g_sprites[l_i].animSpeed = 12;
        g_sprites[l_i].ground = 15;
        g_sprite02.state = 0;
        g_sprite02.yTransformation = 0;
        break;
//------------------------------------------------------------------------------
      case 3:
        // Koopa lunettes + fusil
        g_sprites[l_i].w = 64;
        g_sprites[l_i].animSpeed = 14;
        g_sprites[l_i].ground = 15;
        break;
//------------------------------------------------------------------------------
      case 4:
        // Shyguy volant
        g_sprites[l_i].w = 32;
        g_sprites[l_i].animSpeed = 24;
        g_sprite04.g = 0;
        g_sprite04.xLimit = 160;
        break;
//------------------------------------------------------------------------------
      case 5:
        // Shyguy volant + fusil
        g_sprites[l_i].w = 32;
        g_sprites[l_i].animSpeed = 28;
        g_sprite05.g = 0;
        g_sprite05.xLimit = 160;
        break;
//------------------------------------------------------------------------------
      case 6:
        // Lakitu 1
        g_sprites[l_i].w = 32;
        break;
//------------------------------------------------------------------------------
      case 7:
        // Lakitu 2
        g_sprites[l_i].w = 32;
        break;
//------------------------------------------------------------------------------
      case 8:
        // koopa nazi
        g_sprites[l_i].w = 64;
        g_sprites[l_i].animSpeed = 16;
        g_sprites[l_i].ground = 15;
        break;
//------------------------------------------------------------------------------
      case 9:
        // koopa bazooka
        g_sprites[l_i].w = 64;
        g_sprites[l_i].animSpeed = 12;
        g_sprites[l_i].ground = 15;
        break;
//------------------------------------------------------------------------------
      case 10:
        // shyguy
        g_sprites[l_i].w = 32;
        g_sprites[l_i].animSpeed = 10;
        g_sprites[l_i].ground = 4;
        break;
//------------------------------------------------------------------------------
      case 11:
        // shyguy + fusil
        g_sprites[l_i].w = 32;
        g_sprites[l_i].animSpeed = 12;
        g_sprites[l_i].ground = 4;
        break;
//------------------------------------------------------------------------------
      case 12:
        // goomba
        g_sprites[l_i].w = 32;
        g_sprites[l_i].animSpeed = 14;
        g_sprites[l_i].ground = 6;
        g_sprite12.g = 48;
        break;
//------------------------------------------------------------------------------
      default:
        break;
    }
  }

}
