//Gfx converted using Mollusk's PAGfxConverter

//This file contains all the .h, for easier inclusion in a project
#ifndef __ALL_GFX__
#define __ALL_GFX__


// Sprite files : 
extern const unsigned char bomb_Sprite[1024];  // Pal : TouchMe_Pal
extern const unsigned char koopaAviateur_Sprite[32768];  // Pal : TouchMe_Pal
extern const unsigned char koopaLunettes_Sprite[69632];  // Pal : TouchMe_Pal
extern const unsigned char koopaLunettesFusil_Sprite[32768];  // Pal : TouchMe_Pal
extern const unsigned char shyguyVolant_Sprite[4096];  // Pal : TouchMe_Pal
extern const unsigned char shyguyVolantFusil_Sprite[4096];  // Pal : TouchMe_Pal
extern const unsigned char lakitu1_Sprite[1024];  // Pal : TouchMe_Pal
extern const unsigned char lakitu2_Sprite[1024];  // Pal : TouchMe_Pal
extern const unsigned char koopaNazi_Sprite[32768];  // Pal : TouchMe_Pal
extern const unsigned char koopaBazooka_Sprite[32768];  // Pal : TouchMe_Pal
extern const unsigned char shyguy_Sprite[7168];  // Pal : TouchMe_Pal
extern const unsigned char shyguyFusil_Sprite[8192];  // Pal : TouchMe_Pal
extern const unsigned char goomba_Sprite[9216];  // Pal : TouchMe_Pal

// Background files : 
extern int bg0_Width, bg0_Height;
extern const unsigned short bg0_Map[768];  // Pal : bg0_Pal
extern const unsigned char bg0_Tiles[46400];  // Pal : bg0_Pal

extern int bg1_Width, bg1_Height;
extern const unsigned short bg1_Map[768];  // Pal : bg1_Pal
extern const unsigned char bg1_Tiles[46528];  // Pal : bg1_Pal

extern int bg0nb_Width, bg0nb_Height;
extern const unsigned short bg0nb_Map[768];  // Pal : bg0nb_Pal
extern const unsigned char bg0nb_Tiles[42880];  // Pal : bg0nb_Pal

extern int bg1nb_Width, bg1nb_Height;
extern const unsigned short bg1nb_Map[768];  // Pal : bg1nb_Pal
extern const unsigned char bg1nb_Tiles[40320];  // Pal : bg1nb_Pal

extern int nesFont_Width, nesFont_Height;
extern const unsigned short nesFont_Map[288];  // Pal : nesFont_Pal
extern const unsigned char nesFont_Tiles[2752];  // Pal : nesFont_Pal


// Palette files : 
extern const unsigned short TouchMe_Pal[59];
extern const unsigned short bg0_Pal[213];
extern const unsigned short bg1_Pal[182];
extern const unsigned short bg0nb_Pal[30];
extern const unsigned short bg1nb_Pal[31];
extern const unsigned short nesFont_Pal[2];

#endif

