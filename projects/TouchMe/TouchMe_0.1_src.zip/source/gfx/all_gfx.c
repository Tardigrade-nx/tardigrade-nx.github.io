//Gfx converted using Mollusk's PAGfxConverter

//This file contains all the .c, for easier inclusion in a project


// Sprite files : 
#include "bomb.c"
#include "koopaAviateur.c"
#include "koopaLunettes.c"
#include "koopaLunettesFusil.c"
#include "shyguyVolant.c"
#include "shyguyVolantFusil.c"
#include "lakitu1.c"
#include "lakitu2.c"
#include "koopaNazi.c"
#include "koopaBazooka.c"
#include "shyguy.c"
#include "shyguyFusil.c"
#include "goomba.c"

// Background files : 
#include "bg0.c"
#include "bg1.c"
#include "bg0nb.c"
#include "bg1nb.c"
#include "nesFont.c"

// Palette files : 
#include "TouchMe.pal.c"
#include "bg0.pal.c"
#include "bg1.pal.c"
#include "bg0nb.pal.c"
#include "bg1nb.pal.c"
#include "nesFont.pal.c"
