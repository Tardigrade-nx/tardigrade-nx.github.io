#ifndef _SPRITES_H_
#define _SPRITES_H_

#include <PA9.h>

#define PLAY_SOUND

#define NB_SPRITES       12
#define GROUND_X         45
#define SCREEN_SPACE     48
#define CORPSE_GRAVITY   48
#define CORPSE_JUMP     800 // Little jump when a sprite is shot out of rythm
#define CORPSE_BJUMP   1200 // Big jump when a sprite is shot on rythm
#define ROTATION_SPEED   16
#define ROTATION_BSPEED  24

#define BEAT_COUNT       52 // number of frames for 1 beat
#define BEAT_ADJUST      13 // number of BEATS to wait before addind 1 frame
#define BEAT              6 // value of the g_beat variable which corresponds to a beat
#define OFFBEAT          32 // value of the g_beat variable which corresponds to a beat
#define BEAT_PERFECT      4 // margin to get a perfect, in frames !!! BEAT_PERFECT <= BEAT !!! 
#define BEAT_INTRO      420 // number of frames to wait during intro
#define TOTAL_BEATS     120 // total number of beats of the song

#define BOMB_LENGTH      16 // number of frames to display BOMB!

// generic sprite data
typedef struct
{
	s32 x, y; // coordinates
	s32 vx, vy; // horizontal and vertical speed
  u8 w; // width
  u8 rotset;
  u16 rotAngle;
  u32 rotSpeed;
  bool created;
  bool alive;
  u8 animSpeed;
  u8 ground;
} t_sprite; 

t_sprite g_sprites[NB_SPRITES + 1];

// specific sprite data

struct sprite02 // Koopa lunettes
{
  u8 state; // 0: walk, 1: transformation, 2: shell
  u16 yTransformation; // the y where the transformation occurs
} g_sprite02;

struct sprite04
{
  s32 g; // gravity
  u8 xLimit;
} g_sprite04;

struct sprite05
{
  s32 g; // gravity
  u8 xLimit;
} g_sprite05;

struct sprite12
{
  s32 g; // gravity
} g_sprite12;

// init sprites
void initSprites(void);

#endif
