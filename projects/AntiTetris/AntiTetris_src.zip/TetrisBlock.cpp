#include "TetrisBlock.h"
#include "JRenderer.h"

//------------------------------------------------------------------------------
// Constructor.
//------------------------------------------------------------------------------
TetrisBlock::TetrisBlock(cpSpace *p_space, JResourceManager *p_resMgr, const T_TETRIS_BLOCK p_type):
  m_body(NULL),
  m_quad(NULL),
  m_type(p_type),
  m_space(p_space)
{
  // Moment
  cpFloat l_moment = cpMomentForPoly(TETRIS_BLOCK_MASS, 4, m_verts[m_type][0], cpvzero);
  if (m_type > T_TETRISBLOCK_I) l_moment += cpMomentForPoly(TETRIS_BLOCK_MASS, 4, m_verts[m_type][1], cpvzero);
  // Image
  m_quad = p_resMgr->GetQuad(m_type);
  // Init body
  m_body = cpBodyNew(TETRIS_BLOCK_MASS, l_moment);
  m_body->p = cpv(TETRIS_BLOCK_X_REF, TETRIS_BLOCK_Y_REF);
  cpSpaceAddBody(m_space, m_body);
  // Init 1st shape
  cpShape *l_shape = cpPolyShapeNew(m_body, 4, m_verts[m_type][0], cpvzero);
  l_shape->e = TETRIS_BLOCK_E;
  l_shape->u = TETRIS_BLOCK_U;
  l_shape->collision_type = T_COLLISION_TYPE_CURRENT_BLOCK;
  cpSpaceAddShape(m_space, l_shape);
  m_shapes.push_back(l_shape);
  // Init 2nd shape if necessary
  if (m_type > T_TETRISBLOCK_I)
  {
    l_shape = cpPolyShapeNew(m_body, 4, m_verts[m_type][1], cpvzero);
    l_shape->e = TETRIS_BLOCK_E;
    l_shape->u = TETRIS_BLOCK_U;
    l_shape->collision_type = T_COLLISION_TYPE_CURRENT_BLOCK;
    cpSpaceAddShape(m_space, l_shape);
    m_shapes.push_back(l_shape);
  }
}

//------------------------------------------------------------------------------
// Destructor.
//------------------------------------------------------------------------------
TetrisBlock::~TetrisBlock(void)
{
  // Remove shapes from space and free
  for (std::vector<cpShape *>::iterator l_it = m_shapes.begin(); l_it != m_shapes.end(); l_it++)
  {
    cpSpaceRemoveShape(m_space, *l_it);
    cpShapeFree(*l_it);
  }
  // Remove and free body
  cpSpaceRemoveBody(m_space, m_body);
  cpBodyFree(m_body);
}

//------------------------------------------------------------------------------
// Draw the edges of the block
//------------------------------------------------------------------------------
void TetrisBlock::renderEdges(void)
{
  JRenderer *l_renderer = JRenderer::GetInstance();
  // Draw the edges of the shape(s)
  #ifndef WIN32
  float __attribute__((aligned(16))) l_xVerts[4];
  float __attribute__((aligned(16))) l_yVerts[4];
  #else
  float l_xVerts[4];
  float l_yVerts[4];
  #endif
  cpPolyShape *l_poly(NULL);
  cpVect l_v(cpvzero);
  int l_i(0);
  for (std::vector<cpShape *>::iterator l_it = m_shapes.begin(); l_it != m_shapes.end(); l_it++)
  {
    l_poly = (cpPolyShape *)(*l_it);
    l_v = cpvzero;
    for(l_i = 0; l_i < 4; ++l_i)
    {
      l_v = cpvadd(m_body->p, cpvrotate(l_poly->verts[l_i], m_body->rot));
      l_xVerts[l_i] = l_v.x + XOFFSET;
      l_yVerts[l_i] = -l_v.y + YOFFSET;
    }
    l_renderer->DrawPolygon(l_xVerts, l_yVerts, 4, EDGES_COLOR);
  }
}

//------------------------------------------------------------------------------
// Draw the block
//------------------------------------------------------------------------------
void TetrisBlock::render(void)
{
  JRenderer::GetInstance()->RenderQuad(m_quad, m_body->p.x + XOFFSET, -m_body->p.y + YOFFSET, cpvtoangle(m_body->rot) - 1.570796327f, 1.0f, 1.0f);
}

//------------------------------------------------------------------------------
// Update the block
//------------------------------------------------------------------------------
void TetrisBlock::update(JSample **p_sound)
{
  JGE *l_engine = JGE::GetInstance();
  if (l_engine->GetButtonClick(PSP_CTRL_LEFT))
  {
    m_body->v.x -= TETRIS_BLOCK_MOVE_SPEED;
    if (m_body->v.x < -TETRIS_BLOCK_MOVE_SPEED_MAX) m_body->v.x = -TETRIS_BLOCK_MOVE_SPEED_MAX;
    JSoundSystem::GetInstance()->PlaySample(p_sound[T_SOUND_MOVE]);
  }
  if (l_engine->GetButtonClick(PSP_CTRL_RIGHT))
  {
    m_body->v.x += TETRIS_BLOCK_MOVE_SPEED;
    if (m_body->v.x > TETRIS_BLOCK_MOVE_SPEED_MAX) m_body->v.x = TETRIS_BLOCK_MOVE_SPEED_MAX;
    JSoundSystem::GetInstance()->PlaySample(p_sound[T_SOUND_MOVE]);
  }
  if (l_engine->GetButtonClick(PSP_CTRL_UP))
  {
    m_body->v.y += TETRIS_BLOCK_SLOW_SPEED;
    if (m_body->v.y > 0) m_body->v.y = 0;
  }
  if (l_engine->GetButtonClick(PSP_CTRL_DOWN))
  {
    m_body->v.y -= TETRIS_BLOCK_FALL_SPEED;
    if (m_body->v.y < -TETRIS_BLOCK_FALL_SPEED_MAX) m_body->v.y = -TETRIS_BLOCK_FALL_SPEED_MAX;
  }
  if (l_engine->GetButtonClick(PSP_CTRL_CIRCLE))
  {
    m_body->w -= TETRIS_BLOCK_ROT_SPEED;
    if (m_body->w < -TETRIS_BLOCK_ROT_SPEED_MAX) m_body->w = -TETRIS_BLOCK_ROT_SPEED_MAX;
    JSoundSystem::GetInstance()->PlaySample(p_sound[T_SOUND_TURN]);
  }
  if (l_engine->GetButtonClick(PSP_CTRL_CROSS))
  {
    m_body->w += TETRIS_BLOCK_ROT_SPEED;
    if (m_body->w > TETRIS_BLOCK_ROT_SPEED_MAX) m_body->w = TETRIS_BLOCK_ROT_SPEED_MAX;
    JSoundSystem::GetInstance()->PlaySample(p_sound[T_SOUND_TURN]);
  }
}

//------------------------------------------------------------------------------
// Init verts used for the shape of tetriminos and initial positions
//------------------------------------------------------------------------------
void TetrisBlock::initCoordinates(void)
{
  // Type O
  m_verts[T_TETRISBLOCK_O][0][0] = cpv(-TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_O][0][1] = cpv(-TETRIS_BLOCK_UNIT_WIDTH + 0.5f,  TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_O][0][2] = cpv( TETRIS_BLOCK_UNIT_WIDTH - 0.5f,  TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_O][0][3] = cpv( TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_O][1][0] = cpvzero;
  m_verts[T_TETRISBLOCK_O][1][1] = cpvzero;
  m_verts[T_TETRISBLOCK_O][1][2] = cpvzero;
  m_verts[T_TETRISBLOCK_O][1][3] = cpvzero;
  // Type I
  m_verts[T_TETRISBLOCK_I][0][0] = cpv(-2.0f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH/2.0f + 0.5f);
  m_verts[T_TETRISBLOCK_I][0][1] = cpv(-2.0f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f,  TETRIS_BLOCK_UNIT_WIDTH/2.0f - 0.5f);
  m_verts[T_TETRISBLOCK_I][0][2] = cpv( 2.0f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f,  TETRIS_BLOCK_UNIT_WIDTH/2.0f - 0.5f);
  m_verts[T_TETRISBLOCK_I][0][3] = cpv( 2.0f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH/2.0f + 0.5f);
  m_verts[T_TETRISBLOCK_I][1][0] = cpvzero;
  m_verts[T_TETRISBLOCK_I][1][1] = cpvzero;
  m_verts[T_TETRISBLOCK_I][1][2] = cpvzero;
  m_verts[T_TETRISBLOCK_I][1][3] = cpvzero;
  // Type J
  m_verts[T_TETRISBLOCK_J][0][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_J][0][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_J][0][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_J][0][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_J][1][0] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_J][1][1] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_J][1][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_J][1][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  // Type L
  m_verts[T_TETRISBLOCK_L][0][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_L][0][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_L][0][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_L][0][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_L][1][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_L][1][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_L][1][2] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_L][1][3] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  // Type S
  m_verts[T_TETRISBLOCK_S][0][0] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_S][0][1] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_S][0][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_S][0][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_S][1][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_S][1][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_S][1][2] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_S][1][3] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  // Type Z
  m_verts[T_TETRISBLOCK_Z][0][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_Z][0][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_Z][0][2] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_Z][0][3] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_Z][1][0] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_Z][1][1] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_Z][1][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_Z][1][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  // Type T
  m_verts[T_TETRISBLOCK_T][0][0] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_T][0][1] = cpv(-1.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_T][0][2] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, TETRIS_BLOCK_UNIT_WIDTH - 0.5f);
  m_verts[T_TETRISBLOCK_T][0][3] = cpv( 1.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_T][1][0] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
  m_verts[T_TETRISBLOCK_T][1][1] = cpv(-0.5f*TETRIS_BLOCK_UNIT_WIDTH + 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_T][1][2] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, 0.0f);
  m_verts[T_TETRISBLOCK_T][1][3] = cpv( 0.5f*TETRIS_BLOCK_UNIT_WIDTH - 0.5f, -TETRIS_BLOCK_UNIT_WIDTH + 0.5f);
}

//------------------------------------------------------------------------------
// Set the block passive (i.e. not under control)
//------------------------------------------------------------------------------
void TetrisBlock::setPassive(void)
{
  for (std::vector<cpShape *>::iterator l_it = m_shapes.begin(); l_it != m_shapes.end(); l_it++)
    (*l_it)->collision_type = T_COLLISION_TYPE_BLOCK;
}

//------------------------------------------------------------------------------
// Get block type
//------------------------------------------------------------------------------
const T_TETRIS_BLOCK TetrisBlock::getType(void) const
{
  return m_type;
}

//------------------------------------------------------------------------------
// Get body
//------------------------------------------------------------------------------
cpBody *TetrisBlock::getBody(void)
{
  return m_body;
}
