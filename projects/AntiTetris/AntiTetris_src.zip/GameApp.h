//------------------------------------------------------------------------------
//
// JGE++ is a hardware accelerated 2D game SDK for PSP/Windows.
//
// Licensed under the BSD license, see LICENSE in JGE root for details.
// 
// Copyright (c) 2007 James Hui (a.k.a. Dr.Watson) <jhkhui@gmail.com>
// 
//------------------------------------------------------------------------------

#ifndef _GAMEAPP_H_
#define _GAMEAPP_H_

#include <vector>
#include "JApp.h"
#include "chipmunk.h"
#include "JGE.h"
#include "JResourceManager.h"
#include "JSoundSystem.h"
#include "def.h"
#include "TetrisBlock.h"

class GameApp:  public JApp
{
  
public:

  GameApp(void);
  virtual ~GameApp(void);
  virtual void Create(void);
  virtual void Destroy(void);
  virtual void Update(void);
  virtual void Render(void);
  virtual void Pause(void);
  virtual void Resume(void);
  
  // Collision callback
  static int collFunc(cpShape *p_a, cpShape *p_b, cpContact *p_contacts, int p_numContacts, cpFloat p_normalCoef, void *p_data);
  // Flag for block change
  static bool m_changeBlock;

private:

  // Forbidden
  GameApp(const GameApp &p_source);
  const GameApp &operator=(const GameApp &p_right);
  
  // Draw ground
  void renderGround(void);
  // Generate a random int
  int randomInt(const int p_min, const int p_max);
  // Change block
  void changeBlock(void);
  // Step the physical engine
  void step(void);
  // Draw the score
  void drawScore(void);

  // Space
  cpSpace *m_space;
  // Static body used for the ground
  cpBody *m_staticBody;
  // Shapes used for the ground
  std::vector<cpShape *> m_groundShapes;
  // Tetris blocks
  std::vector<TetrisBlock *> m_tetrisBlocks;
  // Resource manager
  JResourceManager *m_resourceMgr;
  // Seed for random numbers
  unsigned int m_seed;
  // Next block
  T_TETRIS_BLOCK m_nextBlock;
  // Game state
  T_GAME_STATE m_state;
  // Score
  unsigned int m_score;
  // Sound
  JSample *m_samples[6];
  //JMusic *m_music;

};

#endif
