//------------------------------------------------------------------------------
//
// JGE++ is a hardware accelerated 2D game SDK for PSP/Windows.
//
// Licensed under the BSD license, see LICENSE in JGE root for details.
// 
// Copyright (c) 2007 James Hui (a.k.a. Dr.Watson) <jhkhui@gmail.com>
// 
//------------------------------------------------------------------------------

#include "GameApp.h"
#include "JRenderer.h"

// Coordinates
#ifndef WIN32
cpVect __attribute__((aligned(16))) TetrisBlock::m_verts[7][2][4];
#else
cpVect TetrisBlock::m_verts[7][2][4];
#endif

//------------------------------------------------------------------------------
// Constructor. Variables can be initialized here.
//------------------------------------------------------------------------------
GameApp::GameApp(void):
  m_space(NULL),
  m_staticBody(NULL),
  m_resourceMgr(NULL),
  m_seed(0),
  m_nextBlock(T_TETRISBLOCK_O),
  m_state(T_GAME_STATE_PAUSE),
  m_score(0)//,
  //m_music(NULL)
{
  // Init verts
  TetrisBlock::initCoordinates();
}

//------------------------------------------------------------------------------
// Destructor.
//------------------------------------------------------------------------------
GameApp::~GameApp(void)
{
}

//------------------------------------------------------------------------------
// This is the init callback function. You should load and create your in-game 
// resources here.
//------------------------------------------------------------------------------
void GameApp::Create(void)
{
  // Init renderer
  JRenderer::GetInstance()->Enable2D();
  JRenderer::GetInstance()->EnableTextureFilter(false);
  JRenderer::GetInstance()->EnableVSync(true);
  // Init resource manager
  m_resourceMgr = new JResourceManager();
  m_resourceMgr->LoadResource("TetrisBlocks.res");
  // Init sounds
  m_samples[T_SOUND_COLLISION] = JSoundSystem::GetInstance()->LoadSample("Collision.wav");
  m_samples[T_SOUND_GAMEOVER] = JSoundSystem::GetInstance()->LoadSample("Gameover.wav");
  m_samples[T_SOUND_LOOSE] = JSoundSystem::GetInstance()->LoadSample("Loose.wav");
  m_samples[T_SOUND_MOVE] = JSoundSystem::GetInstance()->LoadSample("Move.wav");
  m_samples[T_SOUND_PAUSE] = JSoundSystem::GetInstance()->LoadSample("Pause.wav");
  m_samples[T_SOUND_TURN] = JSoundSystem::GetInstance()->LoadSample("Turn.wav");
  //m_music = JSoundSystem::GetInstance()->LoadMusic("TypeA.mp3");
  // Init seed
  m_seed = JGE::GetInstance()->GetTime();
  // Init Chipmunk
  cpInitChipmunk();
  // Create and initialize space
  m_space = cpSpaceNew();
  m_space->gravity = cpv(0.0f, -GRAVITY);
  // Add collision callbacks for current block / ground, and current block / passive block
  cpSpaceAddCollisionPairFunc(m_space, T_COLLISION_TYPE_GROUND, T_COLLISION_TYPE_CURRENT_BLOCK, &collFunc, NULL);
  cpSpaceAddCollisionPairFunc(m_space, T_COLLISION_TYPE_BLOCK, T_COLLISION_TYPE_CURRENT_BLOCK, &collFunc, NULL);
  // Create static body
  m_staticBody = cpBodyNew(INFINITY, INFINITY);
  // Create ground
  cpResetShapeIdCounter();
  cpShape *l_shape = cpSegmentShapeNew(m_staticBody, cpv(-320.0f, -31.5f), cpv(160.0f, -31.5f), 0.0f);
  l_shape->e = GROUND_E;
  l_shape->u = GROUND_U;
  l_shape->collision_type = T_COLLISION_TYPE_GROUND;
  cpSpaceAddStaticShape(m_space, l_shape);
  m_groundShapes.push_back(l_shape);
  l_shape = cpSegmentShapeNew(m_staticBody, cpv(-216.5f, -31.5f), cpv(-216.5f, 479.5f), 0.0f);
  l_shape->e = WALLS_E;
  l_shape->u = WALLS_U;
  l_shape->collision_type = T_COLLISION_TYPE_WALL;
  cpSpaceAddStaticShape(m_space, l_shape);
  m_groundShapes.push_back(l_shape);
  l_shape = cpSegmentShapeNew(m_staticBody, cpv(-55.5f, -31.5f), cpv(-55.5f, 479.5f), 0.0f);
  l_shape->e = WALLS_E;
  l_shape->u = WALLS_U;
  l_shape->collision_type = T_COLLISION_TYPE_WALL;
  cpSpaceAddStaticShape(m_space, l_shape);
  m_groundShapes.push_back(l_shape);
  // Next block
  m_nextBlock = (T_TETRIS_BLOCK)this->randomInt(0, 6);
}

//------------------------------------------------------------------------------
// This is the clean up callback function. You should delete all your in-game 
// resources, for example texture and quads, here.
//------------------------------------------------------------------------------
void GameApp::Destroy(void)
{
  // Free Tetris blocks
  for (std::vector<TetrisBlock *>::iterator l_it = m_tetrisBlocks.begin(); l_it != m_tetrisBlocks.end(); l_it++)
    delete *l_it;
  // Free ground shapes
  for (std::vector<cpShape *>::iterator l_it = m_groundShapes.begin(); l_it != m_groundShapes.end(); l_it++)
  {
    if (l_it == m_groundShapes.begin() && m_state == T_GAME_STATE_LOST)
    {
      // First shape (ground) already removed from space in this state
    }
    else
      cpSpaceRemoveStaticShape(m_space, *l_it);
    cpShapeFree(*l_it);
  }
  // Free static body
  cpBodyFree(m_staticBody);
  // Free space
  cpSpaceFree(m_space);
  // Free resource manager
  SAFE_DELETE(m_resourceMgr);
  // Free sounds
  for (int l_i = 0; l_i < 6; ++l_i)
    SAFE_DELETE(m_samples[l_i]);
  //SAFE_DELETE(m_music);
}

//------------------------------------------------------------------------------
// This is the update callback function and is called at each update frame
// before rendering. You should update the game logic here.
//------------------------------------------------------------------------------
void GameApp::Update(void)
{
  JGE *l_engine = JGE::GetInstance();
  // Exit when the Select button is pressed
  if (l_engine->GetButtonClick(PSP_CTRL_SELECT)) 
  {
    l_engine->End();
    return;
  }
  else
  {
    // State-specific update
    switch(m_state)
    {
//------------------------------------------------------------------------------
      case T_GAME_STATE_PAUSE:
        if (l_engine->GetButtonClick(PSP_CTRL_START))
        {
          // Create a Tetris block if it's the beginning of the game
          if (m_tetrisBlocks.empty())
          {
            //JSoundSystem::GetInstance()->PlayMusic(m_music, true);
            this->changeBlock();
          }
          #ifndef WIN32
          //else
            //JSoundSystem::GetInstance()->ResumeMusic(m_music);
          #endif
          m_state = T_GAME_STATE_PLAY;
        }
        break;
//------------------------------------------------------------------------------
      case T_GAME_STATE_PLAY:
        if (l_engine->GetButtonClick(PSP_CTRL_START))
        {
          //JSoundSystem::GetInstance()->StopMusic(m_music);
          JSoundSystem::GetInstance()->PlaySample(m_samples[T_SOUND_PAUSE]);
          m_state = T_GAME_STATE_PAUSE;
        }
        else
        {
          // Change block if necessary
          if(m_changeBlock)
          {
            if (m_tetrisBlocks.back()->getBody()->p.y > 235.0f)
            {
              // Game over man
              //JSoundSystem::GetInstance()->StopMusic(m_music);
              JSoundSystem::GetInstance()->PlaySample(m_samples[T_SOUND_LOOSE]);
              cpSpaceRemoveStaticShape(m_space, m_groundShapes.front());
              m_state = T_GAME_STATE_LOST;
            }
            else
            {
              // Change block
              JSoundSystem::GetInstance()->PlaySample(m_samples[T_SOUND_COLLISION]);
              this->changeBlock();
              ++m_score;
            }
            // Set flag to false again
            m_changeBlock = false;
          }
          // Update current block
          m_tetrisBlocks.back()->update(m_samples);
          // Step the engine
          this->step();
        }
        break;
//------------------------------------------------------------------------------
      case T_GAME_STATE_LOST:
      {
        // Step the engine
        this->step();
        // Remove blocks outside of the screen
        std::vector<TetrisBlock *>::iterator l_it = m_tetrisBlocks.begin();
        while ((l_it != m_tetrisBlocks.end()) && ((*l_it)->getBody()->p.y > -80.0f))
          l_it++;
        if (l_it != m_tetrisBlocks.end())
        {
          delete *l_it;
          m_tetrisBlocks.erase(l_it);
        }
        if (m_tetrisBlocks.empty())
        {
          JSoundSystem::GetInstance()->PlaySample(m_samples[T_SOUND_GAMEOVER]);
          cpSpaceAddStaticShape(m_space, m_groundShapes.front());
          m_state = T_GAME_STATE_GAME_OVER;
        }
      }
      break;
//------------------------------------------------------------------------------
      case T_GAME_STATE_GAME_OVER:
        if (l_engine->GetButtonClick(PSP_CTRL_START))
        {
          //JSoundSystem::GetInstance()->PlayMusic(m_music, true);
          m_changeBlock = false;
          m_score = 0;
          this->changeBlock();
          m_state = T_GAME_STATE_PLAY;
        }
        break;
//------------------------------------------------------------------------------
      default: break;
    }
  }
}

//------------------------------------------------------------------------------
// All rendering operations should be done in Render() only.
//------------------------------------------------------------------------------
void GameApp::Render()
{
  JRenderer *l_renderer = JRenderer::GetInstance();
  // Clear screen
  l_renderer->ClearScreen(GB_COLOR_3);
  // Draw background
  l_renderer->RenderQuad(m_resourceMgr->GetQuad(7), 240.0f, 136.0f, 0.0f, 1.0f, 1.0f);
  // Draw ground
  //this->renderGround();
  // Draw next block
  l_renderer->RenderQuad(m_resourceMgr->GetQuad(m_nextBlock), 343.0f, 223.0f, 0.0f, 1.0f, 1.0f);
  // State-specific drawing
  switch(m_state)
  {
    case T_GAME_STATE_PAUSE:
      // Draw pause screen and score
      l_renderer->RenderQuad(m_resourceMgr->GetQuad(8), 183.0f, 135.0f, 0.0f, 1.0f, 1.0f);
      this->drawScore();
      break;
    case T_GAME_STATE_PLAY:
    case T_GAME_STATE_LOST:
    {
      // Draw score
      this->drawScore();
      // Draw tetris blocks
      for (std::vector<TetrisBlock *>::iterator l_it = m_tetrisBlocks.begin(); l_it != m_tetrisBlocks.end(); l_it++)
        (*l_it)->render();
        //(*l_it)->renderEdges();
    }
    break;
    case T_GAME_STATE_GAME_OVER:
      // Draw game over screen
      l_renderer->RenderQuad(m_resourceMgr->GetQuad(19), 183.0f, 135.0f, 0.0f, 1.0f, 1.0f);
      // Draw score
      this->drawScore();
      break;
    default: break;
  }
}

//------------------------------------------------------------------------------
// Draw ground
//------------------------------------------------------------------------------
void GameApp::renderGround(void)
{
  JRenderer *l_renderer = JRenderer::GetInstance();
  cpSegmentShape *l_seg(NULL);
  cpVect l_a(cpvzero);
  cpVect l_b(cpvzero);
  for (std::vector<cpShape *>::iterator l_it = m_groundShapes.begin(); l_it != m_groundShapes.end(); l_it++)
  {
    l_seg = (cpSegmentShape *)(*l_it);
    l_a = cpvadd((*l_it)->body->p, cpvrotate(l_seg->a, (*l_it)->body->rot));
    l_b = cpvadd((*l_it)->body->p, cpvrotate(l_seg->b, (*l_it)->body->rot));
    l_renderer->DrawLine(l_a.x + XOFFSET, -l_a.y + YOFFSET, l_b.x + XOFFSET, -l_b.y + YOFFSET, 0.5, GROUND_COLOR);
  }
}

//------------------------------------------------------------------------------
// This function is called when the system wants to pause the game. You can set
// a flag here to stop the update loop and audio playback.
//------------------------------------------------------------------------------
void GameApp::Pause(void)
{
}

//------------------------------------------------------------------------------
// This function is called when the game returns from the pause state.
//------------------------------------------------------------------------------
void GameApp::Resume(void)
{
}

//------------------------------------------------------------------------------
// Generate a random int
//------------------------------------------------------------------------------
int GameApp::randomInt(const int p_min, const int p_max)
{
  m_seed = 214013 * m_seed + 2531011;
  return p_min + (m_seed ^ m_seed >> 15) % (p_max - p_min + 1);
}

//------------------------------------------------------------------------------
// Collision callback
//------------------------------------------------------------------------------
int GameApp::collFunc(cpShape *p_a, cpShape *p_b, cpContact *p_contacts, int p_numContacts, cpFloat p_normalCoef, void *p_data)
{
  // There was a collision between the current block and (the ground or another block)
  m_changeBlock = true;
  return 1;
}

//------------------------------------------------------------------------------
// Change block
//------------------------------------------------------------------------------
void GameApp::changeBlock(void)
{
  // Set current block passive
  if (!m_tetrisBlocks.empty()) m_tetrisBlocks.back()->setPassive();
  // Create new block
  m_tetrisBlocks.push_back(new TetrisBlock(m_space, m_resourceMgr, m_nextBlock));
  // Set next block
  m_nextBlock = (T_TETRIS_BLOCK)this->randomInt(0, 6);
  if (m_nextBlock == m_tetrisBlocks.back()->getType()) m_nextBlock = (T_TETRIS_BLOCK)((m_nextBlock + 1) % 7);
}

//------------------------------------------------------------------------------
// Step Chipmunk
//------------------------------------------------------------------------------
void GameApp::step(void)
{
  // Step the engine, with possible sub-steps
  cpFloat l_dt = (1.0f/60.0f) / (cpFloat)SUBSTEPS;
  for (int l_i = 0; l_i < SUBSTEPS; ++l_i)
    cpSpaceStep(m_space, l_dt);
}

//------------------------------------------------------------------------------
// Draw the score
//------------------------------------------------------------------------------
void GameApp::drawScore(void)
{
  JRenderer *l_renderer = JRenderer::GetInstance();
  char l_score[16];
  sprintf(l_score, "%u", m_score);
  int l_limit = strlen(l_score) - 1;
  for (int l_i = l_limit; l_i >= 0; --l_i)
    l_renderer->RenderQuad(m_resourceMgr->GetQuad(l_score[l_i] - 48 + 9), 368.0f - ((l_limit - l_i) * 16.0f), 52.0f, 0.0f, 1.0f, 1.0f);
}
