#ifndef _DEF_H_
#define _DEF_H_

// Tetris blocks
#define TETRIS_BLOCK_UNIT_WIDTH 16 // Width of a unit square for Tetris blocks
#define TETRIS_BLOCK_MASS 1
#define TETRIS_BLOCK_E 0.0f
#define TETRIS_BLOCK_U 0.8f
#define TETRIS_BLOCK_X_REF -136.0f
#define TETRIS_BLOCK_Y_REF 256.0f
#define TETRIS_BLOCK_ROT_SPEED 5.0f // rad/sec
#define TETRIS_BLOCK_ROT_SPEED_MAX 15.0f // rad/sec
#define TETRIS_BLOCK_MOVE_SPEED 50.0f
#define TETRIS_BLOCK_MOVE_SPEED_MAX 200.0f
#define TETRIS_BLOCK_FALL_SPEED 80.0f
#define TETRIS_BLOCK_FALL_SPEED_MAX 400.0f
#define TETRIS_BLOCK_SLOW_SPEED 30.0f
#define EDGES_COLOR ARGB(255,200,64,64)

// Ground & Walls
#define GROUND_E 1.0f
#define GROUND_U 0.8f
#define WALLS_E 1.0f
#define WALLS_U 0.0f
#define GROUND_COLOR ARGB(255,64,200,64)

typedef enum
{
  T_TETRISBLOCK_O = 0,
  T_TETRISBLOCK_I,
  T_TETRISBLOCK_J,
  T_TETRISBLOCK_L,
  T_TETRISBLOCK_S,
  T_TETRISBLOCK_Z,
  T_TETRISBLOCK_T
}
T_TETRIS_BLOCK;

// Chipmunk
#define SUBSTEPS 1
#define XOFFSET 320.0f
#define YOFFSET 240.0f
#define GRAVITY 30.0f

// Game Boy colors
#define GB_COLOR_0 ARGB(255,255,255,255)
#define GB_COLOR_1 ARGB(255,209,174,145)
#define GB_COLOR_2 ARGB(255,116,92,73)
#define GB_COLOR_3 ARGB(255,0,0,0)

// Collision type
typedef enum
{
  T_COLLISION_TYPE_GROUND = 0,
  T_COLLISION_TYPE_WALL,
  T_COLLISION_TYPE_CURRENT_BLOCK,
  T_COLLISION_TYPE_BLOCK
}
T_COLLISION_TYPE;

// Game states
typedef enum
{
  T_GAME_STATE_PAUSE = 0,
  T_GAME_STATE_PLAY,
  T_GAME_STATE_LOST,
  T_GAME_STATE_GAME_OVER
}
T_GAME_STATE;

// Sound samples
enum
{
  T_SOUND_COLLISION = 0,
  T_SOUND_GAMEOVER,
  T_SOUND_LOOSE,
  T_SOUND_MOVE,
  T_SOUND_PAUSE,
  T_SOUND_TURN
};

#endif
