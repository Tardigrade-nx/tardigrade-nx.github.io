#ifndef _TETRISBLOCK_H_
#define _TETRISBLOCK_H_

#include <vector>
#include "chipmunk.h"
#include "JGE.h"
#include "JResourceManager.h"
#include "JSoundSystem.h"
#include "def.h"

//------------------------------------------------------------------------------
// Class TetrisBlock
//------------------------------------------------------------------------------
class TetrisBlock
{

public:

  // Constructor
  TetrisBlock(cpSpace *p_space, JResourceManager *p_resMgr, const T_TETRIS_BLOCK p_type);
  // Destructor
  virtual ~TetrisBlock(void);
  
  // Draw the edges of the block
  void renderEdges(void);
  // Draw the block
  void render(void);
  // Update the block
  void update(JSample **p_sound);
  // Set the block passive (i.e. not under control)
  void setPassive(void);
  // Get block type
  const T_TETRIS_BLOCK getType(void) const;
  // Get body
  cpBody *getBody(void);
  
  // Coordinates for the shapes of tetriminos
  // 7 tetriminos, 2 verts each, 4 points for each vert
  #ifndef WIN32
  static cpVect __attribute__((aligned(16))) m_verts[7][2][4];
  #else
  static cpVect m_verts[7][2][4];
  #endif
  // Init verts and positions
  static void initCoordinates(void);

private:

  // Forbidden
  TetrisBlock(const TetrisBlock &p_source);
  const TetrisBlock &operator=(const TetrisBlock &p_right);

  // Physical body of the block
  cpBody *m_body;
  // Shape(s) of the block
  std::vector<cpShape *> m_shapes;
  // Quad
  JQuad *m_quad;
  // Type of block
  T_TETRIS_BLOCK m_type;
  // Reference to the space
  cpSpace *m_space;

};

#endif
