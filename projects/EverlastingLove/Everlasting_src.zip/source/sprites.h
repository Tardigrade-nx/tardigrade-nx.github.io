#ifndef _SPRITES_H_
#define _SPRITES_H_

#include <PA9.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

#define GRAVITY 90

#define MONKEY_SPRITE_NUMBER 64
#define MONKEY_ROTSET_NUMBER 0
#define MONKEY_MIN_JUMP 1024
#define MONKEY_X_MAX_SPEED 800
#define MONKEY_INJUMP_MOVE 64
#define MONKEY_IDLE_JUMP_SPEED 64
#define MONKEY_HEAD_MOVE 8

#define X (g_spriteMonkey.x>>8)
#define Y (g_spriteMonkey.y>>8)

#define HITBOX_UP_X 15
#define HITBOX_UP_Y 9
#define HITBOX_LEFT_X 8
#define HITBOX_LEFT_Y 16
#define HITBOX_RIGHT_X 23
#define HITBOX_RIGHT_Y 16
#define HITBOX_DOWN_X 15
#define HITBOX_DOWN_Y 28

#define TEXT_SPRITE_NUMBER 65

//------------------------------------------------------------------------------
// Types
//------------------------------------------------------------------------------

// Monkey states
typedef enum
{
  MONKEY_STATE_IDLE,
  MONKEY_STATE_JUMP,
  MONKEY_STATE_HANG_LEFT,
  MONKEY_STATE_HANG_RIGHT,
  MONKEY_STATE_KO,
  MONKEY_STATE_LOVE
}
T_MONKEY_STATE;

// Direction
typedef enum
{
  DIRECTION_LEFT = 0,
  DIRECTION_RIGHT = 1
}
T_DIRECTION;

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------

// Monkey sprite
struct spriteMonkey
{
  s32 x; // x coordinate
  s32 y; // y coordinate
  s32 vx; // horizontal speed
  s32 vy; // vertical speed
  s32 sx; // horizontal scroll
  T_DIRECTION direction; // monkey looking left or right
  T_MONKEY_STATE state; // current state
} g_spriteMonkey;

bool g_sprites[128];

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

inline u16 getTile(const s16 p_x, const s16 p_y);

void updateMonkeyPosition(void);

void manageCollisions(void);

void goToMonkeyState(const T_MONKEY_STATE p_destState);

void turnMonkey(T_DIRECTION p_newDirection);

void moveMonkey(void);

#endif
