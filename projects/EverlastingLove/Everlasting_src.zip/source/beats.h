#ifndef _BEATS_H_
#define _BEATS_H_

#include <PA9.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

#define BEAT_MARGIN 20
#define BEAT_DIFF_FACTOR 64

//------------------------------------------------------------------------------
// Types
//------------------------------------------------------------------------------

// Beat info
typedef struct STRUCT_BEAT_INFO
{
  u16 g_beatLimitValue;
  u16 g_beatAdjustLimit;
  u16 g_beatAdjustLimit2;
  u16 g_totalBeatsLimit;
}
T_BEAT_INFO;

T_BEAT_INFO g_beatInfo[2];

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------

u16 g_beat;
u16 g_beatLimit;
u16 g_beatAdjust;
u16 g_beatAdjust2;
u16 g_totalBeats;

T_BEAT_INFO * g_currentBeatInfo;

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

u16 beatDifference(void);

void manageBeat(void);

#endif
