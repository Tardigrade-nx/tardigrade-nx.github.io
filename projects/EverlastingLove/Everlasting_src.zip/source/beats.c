#include "beats.h"
#include "sprites.h"

#include "tomorrow.h"

// Returns the number of frames before or after the beat
u16 beatDifference(void)
{
  if (g_beat >= g_beatLimit - BEAT_MARGIN)
    return (g_beatLimit - g_beat - 1);
  else if (g_beat <= BEAT_MARGIN)
    return g_beat;
  else return BEAT_MARGIN;
}

// Manage beat
void manageBeat(void)
{
  ++g_beat;
  if (g_beat >= g_beatLimit)
  {
    g_beat = 0;
  }
  if (g_beat == 0)
  {
    // Update beatLimit
    if (g_beatAdjust == g_currentBeatInfo->g_beatAdjustLimit)
    {
      ++g_beatAdjust2;
      if (g_beatAdjust2 == g_currentBeatInfo->g_beatAdjustLimit2)
      {
        g_beatAdjust2 = 0;
      }
      else
      {
        g_beatLimit = g_currentBeatInfo->g_beatLimitValue - 1;
      }
      g_beatAdjust = 0;
    }
    else if (g_beatAdjust == 0)
    {
      g_beatLimit = g_currentBeatInfo->g_beatLimitValue;
      ++g_beatAdjust;
    }
    else
    {
      ++g_beatAdjust;
    }
    // Change color of numbers
    if (g_sprites[TEXT_SPRITE_NUMBER]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 1]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 1, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 2]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 2, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 3]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 3, 1);
    // Increment total beats number
    ++g_totalBeats;
    if (g_totalBeats >= g_currentBeatInfo->g_totalBeatsLimit)
    {
      // Loop song
      g_totalBeats = 0;
      g_beatLimit = g_currentBeatInfo->g_beatLimitValue;
      g_beatAdjust = 0;
      g_beatAdjust2 = 0;
      PA_PlaySoundEx(0, tomorrow, (u32)tomorrow_size, 64, 11025, 0);
    }
  }
  else if (g_beat == MONKEY_HEAD_MOVE + 1)
  {
    if (g_sprites[TEXT_SPRITE_NUMBER]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER, 0);
    if (g_sprites[TEXT_SPRITE_NUMBER + 1]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 1, 0);
    if (g_sprites[TEXT_SPRITE_NUMBER + 2]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 2, 0);
    if (g_sprites[TEXT_SPRITE_NUMBER + 3]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 3, 0);
  }
  if (g_spriteMonkey.state == MONKEY_STATE_IDLE)
  {
    if (g_beat <= MONKEY_HEAD_MOVE)
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 1);
    else if (g_beat == MONKEY_HEAD_MOVE + 1)
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 0);
  }
  else if (g_spriteMonkey.state == MONKEY_STATE_HANG_LEFT || g_spriteMonkey.state == MONKEY_STATE_HANG_RIGHT)
  {
    if (g_beat <= MONKEY_HEAD_MOVE)
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 4);
    else if (g_beat == MONKEY_HEAD_MOVE + 1)
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 3);
  }
}
