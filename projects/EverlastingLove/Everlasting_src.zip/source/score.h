#ifndef _SCORE_H_
#define _SCORE_H_

#include <PA9.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

#define SAVE_STRING "love"

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------

// total number of jumps
u32 g_jumps;

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

// Returns the number of digits displayed
u8 displayNumber(u32 p_number, s16 p_x, s16 p_y, u8 p_spriteNumber);

void displayNbJumps(void);

// Returns the score saved in SRAM, 0 if none
u32 getBestScoreSRAM(void);

// Returns the score saved in a file using the FAT driver, 0 if none
u32 getBestScoreFAT(void);

#endif
