#include "levels.h"
#include "sprites.h"
#include "beats.h"
#include "score.h"

#include "gfx/all_gfx.h"

#include "tomorrow.h"

const unsigned short yellow1_Pal[3] __attribute__ ((aligned (4))) = {64543, YELLOW0, YELLOW3};
const unsigned short yellow2_Pal[5] __attribute__ ((aligned (4))) = {64543, YELLOW3, YELLOW2, YELLOW1, YELLOW0};
const unsigned short yellow3_Pal[5] __attribute__ ((aligned (4))) = {64543, YELLOW0, YELLOW2, YELLOW3, YELLOW1};
const unsigned short yellow4_Pal[4] __attribute__ ((aligned (4))) = {64543, YELLOW1, YELLOW2, YELLOW3};
const unsigned short yellow5_Pal[5] __attribute__ ((aligned (4))) = {64543, YELLOW2, YELLOW3, YELLOW1, YELLOW0};
const unsigned short yellow6_Pal[5] __attribute__ ((aligned (4))) = {64543, YELLOW0, YELLOW2, YELLOW1, YELLOW3};
 
void leaveGameState(void)
{
  switch(g_gameState)
  {
    case GAME_STATE_TITLE:
      fadeToBlack(1, false);
      // Reset backgrounds
      PA_DualResetBg();
    break;
    case GAME_STATE_LEVEL1:
    case GAME_STATE_LEVEL2:
    case GAME_STATE_RESULT1:
    case GAME_STATE_RESULT2:
    {
      u8 l_i = 0;
      // Stop song if necessary
      if (g_gameState == GAME_STATE_LEVEL1 || g_gameState == GAME_STATE_LEVEL2)
        PA_StopSound(0);
      fadeToBlack(1, false);
      // Reset backgrounds
      PA_DualResetBg();
      // Delete all sprites
      for (; l_i <= 127; ++l_i)
      {
        if (g_sprites[l_i])
        {
          PA_DualDeleteSprite(l_i);
          g_sprites[l_i] = false;
        }
      }
    }
    break;
    default:
    break;
  }
}

void goToGameState(T_GAME_STATE p_newState)
{
  switch(p_newState)
  {
//------------------------------------------------------------------------------
    case GAME_STATE_TITLE:
      g_spriteMonkey.sx = 0;
      // Load backgrounds
      PA_DualLoadPAGfxLargeBg(3, level1back3);
      PA_DualLoadPAGfxLargeBg(2, level0back2);
      if (g_yellowFilter)
        setYellowFilter(GAME_STATE_TITLE);
      PA_DualInitParallaxX(0, 0, 0, 64);
      fadeFromBlack(1, false);
    break;
//------------------------------------------------------------------------------
    case GAME_STATE_LEVEL1:
      // Load backgrounds
      PA_DualLoadPAGfxLargeBg(0, level1back0);
      PA_DualLoadPAGfxLargeBg(1, level1back1);
      PA_DualLoadPAGfxLargeBg(2, level1back2);
      PA_DualLoadPAGfxLargeBg(3, level1back3);
      if (g_yellowFilter)
      {
        setYellowFilter(GAME_STATE_LEVEL1);
        PA_DualLoadSpritePal(0, (void*)yellow3_Pal);
      }
      else
      {
        PA_DualLoadSpritePal(0, (void*)Gameboy_Pal);
      }
      // Init parallax scrolling
      PA_DualInitParallaxX(256, 192, 128, 64);
      // Collision map
      g_currentCollisionMap = level1map_Map;
      g_currentCollisionMapInfo = level1map_Info;
      // Beats
      g_currentBeatInfo = &(g_beatInfo[0]);
      g_beat = 4;
      g_beatLimit = g_currentBeatInfo->g_beatLimitValue;
      g_beatAdjust = 0;
      g_beatAdjust2 = 0;
      g_totalBeats = 0;
      // Number of jumps
      g_jumps = 0;
      // Init monkey sprite
      //g_spriteMonkey.x = 3840 << 8;
      g_spriteMonkey.x = g_checkPointsL1[0].x << 8;
      g_spriteMonkey.y = g_checkPointsL1[0].y << 8;
      g_spriteMonkey.vx = 256;
      g_spriteMonkey.vy = 0;
      g_spriteMonkey.sx = 0;
      g_spriteMonkey.direction = DIRECTION_RIGHT;
      g_spriteMonkey.state = MONKEY_STATE_JUMP;
      // fade from black
      fadeFromBlack(1, false);
      // Create monkey sprite
      PA_DualCreateSprite(MONKEY_SPRITE_NUMBER, (void*)monkeyRight_Sprite, OBJ_SIZE_32X32, 1, 0, X, Y);
      g_sprites[MONKEY_SPRITE_NUMBER] = true;
      PA_DualSetSpriteRotEnable(MONKEY_SPRITE_NUMBER, MONKEY_ROTSET_NUMBER);
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 2);
      // Play song
      //PA_PlaySimpleSound(0, everlasting);
    break;
//------------------------------------------------------------------------------
    case GAME_STATE_LEVEL2:
    {
      // Load backgrounds
      PA_DualLoadPAGfxLargeBg(0, level2back1);
      PA_DualLoadPAGfxLargeBg(1, level2back2);
      PA_DualLoadPAGfxLargeBg(2, level2back3);
      if (g_yellowFilter)
      {
        setYellowFilter(GAME_STATE_LEVEL2);
        PA_DualLoadSpritePal(0, (void*)yellow3_Pal);
      }
      else
      {
        PA_DualLoadSpritePal(0, (void*)Gameboy_Pal);
      }
      // Init parallax scrolling
      PA_DualInitParallaxX(256, 256, 128, 0);
      // Collision map
      g_currentCollisionMap = level2map_Map;
      g_currentCollisionMapInfo = level2map_Info;
      // Beats
      g_currentBeatInfo = &(g_beatInfo[1]);
      g_beat = 1;
      g_beatLimit = g_currentBeatInfo->g_beatLimitValue;
      g_beatAdjust = 0;
      g_beatAdjust2 = 0;
      g_totalBeats = 0;
      // Number of jumps
      g_jumps = 0;
      // Init monkey sprite
      g_spriteMonkey.x = g_checkPointsL2[0].x << 8;
      g_spriteMonkey.y = g_checkPointsL2[0].y << 8;
      g_spriteMonkey.vx = 256;
      g_spriteMonkey.vy = 0;
      g_spriteMonkey.sx = 0;
      g_spriteMonkey.direction = DIRECTION_RIGHT;
      g_spriteMonkey.state = MONKEY_STATE_JUMP;
      // fade from black
      fadeFromBlack(1, false);
      // Create monkey sprite
      PA_DualCreateSprite(MONKEY_SPRITE_NUMBER, (void*)monkeyRight_Sprite, OBJ_SIZE_32X32, 1, 0, X, Y);
      g_sprites[MONKEY_SPRITE_NUMBER] = true;
      PA_DualSetSpritePrio(MONKEY_SPRITE_NUMBER, 1);
      PA_DualSetSpriteRotEnable(MONKEY_SPRITE_NUMBER, MONKEY_ROTSET_NUMBER);
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 2);
      // Play song
      PA_PlaySoundEx(0, tomorrow, (u32)tomorrow_size, 64, 11025, 0);
    }
    break;
//------------------------------------------------------------------------------
    case GAME_STATE_RESULT1:
    {
      u8 l_nbDigits = 0;
      #ifdef SRAM_SAVE_ENABLED
      // Get saved best
      u32 l_bestInt = getBestScoreSRAM();
      #endif
      // Delete existing sprites
      for (l_nbDigits = TEXT_SPRITE_NUMBER; l_nbDigits <= TEXT_SPRITE_NUMBER + 3; ++l_nbDigits)
      {
        if (g_sprites[l_nbDigits])
        {
          PA_DualDeleteSprite(l_nbDigits);
          g_sprites[l_nbDigits] = false;
        }
      }
      #ifdef SRAM_SAVE_ENABLED
      // Write results
      if (l_bestInt > 0)
      {
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER, (void*)jumps_Sprite, OBJ_SIZE_64X32, 1, 0, 80, 80);
        g_sprites[TEXT_SPRITE_NUMBER] = true;
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER + 1, (void*)best_Sprite, OBJ_SIZE_64X32, 1, 0, 92, 112);
        g_sprites[TEXT_SPRITE_NUMBER + 1] = true;
        l_nbDigits = displayNumber(g_jumps, 136, 80, TEXT_SPRITE_NUMBER + 2);
        displayNumber(l_bestInt, 136, 112, TEXT_SPRITE_NUMBER + 2 + l_nbDigits);
      }
      else
      {
      #endif
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER, (void*)jumps_Sprite, OBJ_SIZE_64X32, 1, 0, 80, 96);
        g_sprites[TEXT_SPRITE_NUMBER] = true;
        displayNumber(g_jumps, 136, 96, TEXT_SPRITE_NUMBER + 1);
      #ifdef SRAM_SAVE_ENABLED
      }
      #endif
    }
    break;
//------------------------------------------------------------------------------
    case GAME_STATE_RESULT2:
    {
      u8 l_nbDigits = 0;
      #ifdef SRAM_SAVE_ENABLED
      // Get saved best
      u32 l_bestInt = getBestScoreSRAM();
      #endif
      // Delete existing sprites
      for (l_nbDigits = TEXT_SPRITE_NUMBER; l_nbDigits <= TEXT_SPRITE_NUMBER + 3; ++l_nbDigits)
      {
        if (g_sprites[l_nbDigits])
        {
          PA_DualDeleteSprite(l_nbDigits);
          g_sprites[l_nbDigits] = false;
        }
      }
      #ifdef SRAM_SAVE_ENABLED
      // Write results
      if (l_bestInt > 0)
      {
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER, (void*)jumps_Sprite, OBJ_SIZE_64X32, 1, 0, 88, 312);
        g_sprites[TEXT_SPRITE_NUMBER] = true;
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER + 1, (void*)best_Sprite, OBJ_SIZE_64X32, 1, 0, 100, 344);
        g_sprites[TEXT_SPRITE_NUMBER + 1] = true;
        l_nbDigits = displayNumber(g_jumps, 144, 312, TEXT_SPRITE_NUMBER + 2);
        displayNumber(l_bestInt, 144, 344, TEXT_SPRITE_NUMBER + 2 + l_nbDigits);
      }
      else
      {
      #endif
        PA_DualCreateSprite(TEXT_SPRITE_NUMBER, (void*)jumps_Sprite, OBJ_SIZE_64X32, 1, 0, 88, 328);
        g_sprites[TEXT_SPRITE_NUMBER] = true;
        displayNumber(g_jumps, 144, 328, TEXT_SPRITE_NUMBER + 1);
      #ifdef SRAM_SAVE_ENABLED
      }
      #endif
    }
    break;
//------------------------------------------------------------------------------
    default:
    break;
  }
  g_gameState = p_newState;
}

void manageScroll(void)
{
  if (X - g_spriteMonkey.sx > SCROLL_RIGHT_EDGE)
  {
      g_spriteMonkey.sx = X - SCROLL_RIGHT_EDGE;
      if (g_spriteMonkey.sx > g_currentCollisionMapInfo[1] - 256)
        g_spriteMonkey.sx = g_currentCollisionMapInfo[1] - 256;
  }
  else if (X - g_spriteMonkey.sx < SCROLL_LEFT_EDGE)
  {
    g_spriteMonkey.sx = X - SCROLL_LEFT_EDGE;
    if (g_spriteMonkey.sx < 0)
      g_spriteMonkey.sx = 0;
  }
  PA_DualParallaxScrollX(g_spriteMonkey.sx);
}

void init(void)
{
  // Sprite creation flags
  u8 l_i = 0;
  for (; l_i <= 127; ++l_i)
    g_sprites[l_i] = false;
  // Check points level 1
  g_checkPointsL1[0].x = 74;
  g_checkPointsL1[0].y = 304;
  g_checkPointsL1[1].x = 784;
  g_checkPointsL1[1].y = 48;
  g_checkPointsL1[2].x = 1640;
  g_checkPointsL1[2].y = 336;
  g_checkPointsL1[3].x = 1936;
  g_checkPointsL1[3].y = 336;
  g_checkPointsL1[4].x = 2776;
  g_checkPointsL1[4].y = 336;
  g_checkPointsL1[5].x = 3424;
  g_checkPointsL1[5].y = 336;
  // Check points level 2
  g_checkPointsL2[0].x = 74;
  g_checkPointsL2[0].y = 336;
  g_checkPointsL2[1].x = 896;
  g_checkPointsL2[1].y = 40;
  g_checkPointsL2[2].x = 1376;
  g_checkPointsL2[2].y = 336;
  g_checkPointsL2[3].x = 1832;
  g_checkPointsL2[3].y = 328;
  g_checkPointsL2[4].x = 2600;
  g_checkPointsL2[4].y = 328;
  g_checkPointsL2[5].x = 3088;
  g_checkPointsL2[5].y = 64;
  g_checkPointsL2[6].x = 3648;
  g_checkPointsL2[6].y = 328;
  // Beat info level 1
  g_beatInfo[0].g_beatLimitValue = 46;
  g_beatInfo[0].g_beatAdjustLimit = 3;
  g_beatInfo[0].g_beatAdjustLimit2 = 48;
  g_beatInfo[0].g_totalBeatsLimit = 376;
  // Beat info level 2
  g_beatInfo[1].g_beatLimitValue = 60;
  g_beatInfo[1].g_beatAdjustLimit = 3;
  g_beatInfo[1].g_beatAdjustLimit2 = 6;
  g_beatInfo[1].g_totalBeatsLimit = 144;
  // global
  g_gameState = GAME_STATE_TITLE;
  g_yellowFilter = true;
  g_currentBeatInfo = NULL;
}

void goToLastCheckPoint(void)
{
  bool l_found = false;
  s8 l_i = 0;
  
  switch(g_gameState)
  {
    case GAME_STATE_LEVEL1:
      l_i = NB_CHECKPOINTS_LEVEL1 - 1;
      while (!l_found && l_i >= 0)
      {
        if (X >= g_checkPointsL1[l_i].x)
        {
          g_spriteMonkey.x = g_checkPointsL1[l_i].x << 8;
          g_spriteMonkey.y = g_checkPointsL1[l_i].y << 8;
          l_found = true;
        }
        --l_i;
      }
      if (!l_found)
      {
        g_spriteMonkey.x = g_checkPointsL1[0].x << 8;
        g_spriteMonkey.y = g_checkPointsL1[0].y << 8;
      }
      break;
    case GAME_STATE_LEVEL2:
      l_i = NB_CHECKPOINTS_LEVEL2 - 1;
      while (!l_found && l_i >= 0)
      {
        if (X >= g_checkPointsL2[l_i].x)
        {
          g_spriteMonkey.x = g_checkPointsL2[l_i].x << 8;
          g_spriteMonkey.y = g_checkPointsL2[l_i].y << 8;
          l_found = true;
        }
        --l_i;
      }
      if (!l_found)
      {
        g_spriteMonkey.x = g_checkPointsL2[0].x << 8;
        g_spriteMonkey.y = g_checkPointsL2[0].y << 8;
      }
      break;
    default:
      break;
  }
}

void fadeToBlack(u8 p_speed, bool p_beat)
{
  s8 l_i = 0;
  for (; l_i > -31; l_i -= p_speed)
  {
    PA_SetBrightness(0, l_i);
    PA_SetBrightness(1, l_i);
    if (p_beat)
      manageBeat();
    PA_WaitForVBL();
  }
  PA_SetBrightness(0, -31);
  PA_SetBrightness(1, -31);
}

void fadeFromBlack(u8 p_speed, bool p_beat)
{
  s8 l_i = -31;
  for (; l_i < 0; l_i += p_speed)
  {
    PA_SetBrightness(0, l_i);
    PA_SetBrightness(1, l_i);
    if (p_beat)
      manageBeat();
    PA_WaitForVBL();
  }
  PA_SetBrightness(0, 0);
  PA_SetBrightness(1, 0);
}

void setYellowFilter(T_GAME_STATE p_gameState)
{
  switch(p_gameState)
  {
    case GAME_STATE_TITLE:
      if (g_yellowFilter)
      {
        PA_DualLoadBgPal(2, (void*)yellow1_Pal);
        PA_DualLoadBgPal(3, (void*)yellow2_Pal);
      }
      else
      {
        PA_DualLoadBgPal(2, (void*)level0back2_Pal);
        PA_DualLoadBgPal(3, (void*)level1back3_Pal);
      }
    break;
    case GAME_STATE_LEVEL1:
      PA_DualLoadBgPal(0, (void*)yellow5_Pal);
      PA_DualLoadBgPal(1, (void*)yellow4_Pal);
      PA_DualLoadBgPal(2, (void*)yellow3_Pal);
      PA_DualLoadBgPal(3, (void*)yellow2_Pal);
    break;
    case GAME_STATE_LEVEL2:
      PA_DualLoadBgPal(0, (void*)yellow6_Pal);
      PA_DualLoadBgPal(1, (void*)yellow6_Pal);
      PA_DualLoadBgPal(2, (void*)yellow2_Pal);
    break;
    default:
    break;
  }
}
