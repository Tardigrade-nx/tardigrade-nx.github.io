//Gfx converted using Mollusk's PAGfx Converter

//This file contains all the .h, for easier inclusion in a project

#ifndef ALL_GFX_H
#define ALL_GFX_H

#ifndef PAGfx_struct
    typedef struct{
    void *Map;
    int MapSize;
    void *Tiles;
    int TileSize;
    void *Palette;
    int *Info;
} PAGfx_struct;
#endif


// Sprite files : 
extern const unsigned char monkeyLeft_Sprite[6144] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char monkeyRight_Sprite[6144] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char best_Sprite[2048] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char jumps_Sprite[2048] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number0_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number1_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number2_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number3_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number4_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number5_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number6_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number7_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number8_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal
extern const unsigned char number9_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Gameboy_Pal

// Background files : 
extern const int level0back2_Info[3]; // BgMode, Width, Height
extern const unsigned short level0back2_Map[1728] __attribute__ ((aligned (4))) ;  // Pal : level0back2_Pal
extern const unsigned char level0back2_Tiles[2368] __attribute__ ((aligned (4))) ;  // Pal : level0back2_Pal
extern PAGfx_struct level0back2; // background pointer

extern const int level1back0_Info[3]; // BgMode, Width, Height
extern const unsigned short level1back0_Map[27486] __attribute__ ((aligned (4))) ;  // Pal : level1back0_Pal
extern const unsigned char level1back0_Tiles[3648] __attribute__ ((aligned (4))) ;  // Pal : level1back0_Pal
extern PAGfx_struct level1back0; // background pointer

extern const int level1back1_Info[3]; // BgMode, Width, Height
extern const unsigned short level1back1_Map[5454] __attribute__ ((aligned (4))) ;  // Pal : level1back1_Pal
extern const unsigned char level1back1_Tiles[576] __attribute__ ((aligned (4))) ;  // Pal : level1back1_Pal
extern PAGfx_struct level1back1; // background pointer

extern const int level1back2_Info[3]; // BgMode, Width, Height
extern const unsigned short level1back2_Map[5454] __attribute__ ((aligned (4))) ;  // Pal : level1back2_Pal
extern const unsigned char level1back2_Tiles[192] __attribute__ ((aligned (4))) ;  // Pal : level1back2_Pal
extern PAGfx_struct level1back2; // background pointer

extern const int level1back3_Info[3]; // BgMode, Width, Height
extern const unsigned short level1back3_Map[4590] __attribute__ ((aligned (4))) ;  // Pal : level1back3_Pal
extern const unsigned char level1back3_Tiles[384] __attribute__ ((aligned (4))) ;  // Pal : level1back3_Pal
extern PAGfx_struct level1back3; // background pointer

extern const int level1map_Info[3]; // BgMode, Width, Height
extern const unsigned short level1map_Map[27486] __attribute__ ((aligned (4))) ;  // Pal : level1map_Pal
extern const unsigned char level1map_Tiles[320] __attribute__ ((aligned (4))) ;  // Pal : level1map_Pal
extern PAGfx_struct level1map; // background pointer

extern const int level2back1_Info[3]; // BgMode, Width, Height
extern const unsigned short level2back1_Map[27486] __attribute__ ((aligned (4))) ;  // Pal : level2back1_Pal
extern const unsigned char level2back1_Tiles[4352] __attribute__ ((aligned (4))) ;  // Pal : level2back1_Pal
extern PAGfx_struct level2back1; // background pointer

extern const int level2back2_Info[3]; // BgMode, Width, Height
extern const unsigned short level2back2_Map[27486] __attribute__ ((aligned (4))) ;  // Pal : level2back2_Pal
extern const unsigned char level2back2_Tiles[7680] __attribute__ ((aligned (4))) ;  // Pal : level2back2_Pal
extern PAGfx_struct level2back2; // background pointer

extern const int level2back3_Info[3]; // BgMode, Width, Height
extern const unsigned short level2back3_Map[3456] __attribute__ ((aligned (4))) ;  // Pal : level2back3_Pal
extern const unsigned char level2back3_Tiles[320] __attribute__ ((aligned (4))) ;  // Pal : level2back3_Pal
extern PAGfx_struct level2back3; // background pointer

extern const int level2map_Info[3]; // BgMode, Width, Height
extern const unsigned short level2map_Map[27486] __attribute__ ((aligned (4))) ;  // Pal : level2map_Pal
extern const unsigned char level2map_Tiles[384] __attribute__ ((aligned (4))) ;  // Pal : level2map_Pal
extern PAGfx_struct level2map; // background pointer


// Palette files : 
extern const unsigned short Gameboy_Pal[5] __attribute__ ((aligned (4))) ;
extern const unsigned short level0back2_Pal[3] __attribute__ ((aligned (4))) ;
extern const unsigned short level1back0_Pal[5] __attribute__ ((aligned (4))) ;
extern const unsigned short level1back1_Pal[4] __attribute__ ((aligned (4))) ;
extern const unsigned short level1back2_Pal[5] __attribute__ ((aligned (4))) ;
extern const unsigned short level1back3_Pal[3] __attribute__ ((aligned (4))) ;
extern const unsigned short level1map_Pal[6] __attribute__ ((aligned (4))) ;
extern const unsigned short level2back1_Pal[5] __attribute__ ((aligned (4))) ;
extern const unsigned short level2back2_Pal[5] __attribute__ ((aligned (4))) ;
extern const unsigned short level2back3_Pal[3] __attribute__ ((aligned (4))) ;
extern const unsigned short level2map_Pal[7] __attribute__ ((aligned (4))) ;


#endif

