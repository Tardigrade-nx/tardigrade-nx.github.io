#include "score.h"
#include "sprites.h"
#include "beats.h"

#include "gfx/all_gfx.h"

u8 displayNumber(u32 p_number, s16 p_x, s16 p_y, u8 p_spriteNumber)
{
  u8 l_length = 0;
  if (p_number < 10000)
  {
    u8 l_i = 0;
    u8 l_digits[4];
    bool l_digitDisplayed = false;
    l_digits[3] = (u8)(p_number / 1000);
    p_number -= l_digits[3] * 1000;
    l_digits[2] = (u8)(p_number / 100);
    p_number -= l_digits[2] * 100;
    l_digits[1] = (u8)(p_number / 10);
    p_number -= l_digits[1] * 10;
    l_digits[0] = (u8)(p_number);
    for (l_i = 0; l_i <= 3; ++l_i)
    {
      switch(l_digits[3 - l_i])
      {
        case 0:
          if (l_digitDisplayed)
          {
            PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number0_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
            g_sprites[p_spriteNumber + l_i] = true;
            ++l_length;
          }
          break;
        case 1:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number1_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 2:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number2_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 3:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number3_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 4:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number4_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 5:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number5_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 6:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number6_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 7:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number7_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 8:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number8_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        case 9:
          PA_DualCreateSprite(p_spriteNumber + l_i, (void*)number9_Sprite, OBJ_SIZE_16X16, 1, 0, p_x + (8 * l_i), p_y);
          g_sprites[p_spriteNumber + l_i] = true;
          l_digitDisplayed = true;
          ++l_length;
          break;
        default:
          break;
      }
    }
  }
  return l_length;
}

void displayNbJumps(void)
{
  // Delete existing sprites
  if (g_sprites[TEXT_SPRITE_NUMBER]) PA_DualDeleteSprite(TEXT_SPRITE_NUMBER);
  if (g_sprites[TEXT_SPRITE_NUMBER + 1]) PA_DualDeleteSprite(TEXT_SPRITE_NUMBER + 1);
  if (g_sprites[TEXT_SPRITE_NUMBER + 2]) PA_DualDeleteSprite(TEXT_SPRITE_NUMBER + 2);
  if (g_sprites[TEXT_SPRITE_NUMBER + 3]) PA_DualDeleteSprite(TEXT_SPRITE_NUMBER + 3);
  // Display jumps
  displayNumber(g_jumps, 216, 8, TEXT_SPRITE_NUMBER);
  // Change color of numbers if needed
  if (g_beat <= MONKEY_HEAD_MOVE)
  {
    if (g_sprites[TEXT_SPRITE_NUMBER]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 1]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 1, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 2]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 2, 1);
    if (g_sprites[TEXT_SPRITE_NUMBER + 3]) PA_DualSetSpriteAnim(TEXT_SPRITE_NUMBER + 3, 1);
  }
}

u32 getBestScoreSRAM(void)
{
  char l_string[16];
  char l_best[16];
  u32 l_bestInt = 0;
  memset(l_string, 0, 16);
  memset(l_best, 0, 16);
  PA_LoadData(1, l_string, 16);
  if (PA_CompareText(l_string, SAVE_STRING))
  {
    // A best score has been saved before => get it
    l_bestInt = PA_Load32bit(17);
    // If current score is better, take it instead and save it
    if (g_jumps < l_bestInt)
    {
      l_bestInt = g_jumps;
      PA_Save32bit(17, l_bestInt);
    }
  }
  else
  {
    // Format SRAM
    PA_SaveData(1, (void*)Blank, 128);
    PA_SaveString(1, SAVE_STRING);
    PA_Save32bit(17, g_jumps);
  }
  return l_bestInt;
}

u32 getBestScoreFAT(void)
{
  return 0;
}
