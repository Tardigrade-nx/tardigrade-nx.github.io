#ifndef _LEVELS_H_
#define _LEVELS_H_

#include <PA9.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

#define SCROLL_RIGHT_EDGE 140
#define SCROLL_LEFT_EDGE 84

#define NB_CHECKPOINTS_LEVEL1 6
#define NB_CHECKPOINTS_LEVEL2 7

#define YELLOW0 36039
#define YELLOW1 44462
#define YELLOW2 47798
#define YELLOW3 53083

//#define SRAM_SAVE_ENABLED

//------------------------------------------------------------------------------
// Types
//------------------------------------------------------------------------------

// Game states
typedef enum
{
  GAME_STATE_TITLE,
  GAME_STATE_LEVEL1,
  GAME_STATE_RESULT1,
  GAME_STATE_LEVEL2,
  GAME_STATE_RESULT2
}
T_GAME_STATE;

// Point
typedef struct STRUCT_POINT
{
  u16 x;
  u16 y;
}
T_POINT;

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------

T_GAME_STATE g_gameState;

T_POINT g_checkPointsL1[NB_CHECKPOINTS_LEVEL1];

T_POINT g_checkPointsL2[NB_CHECKPOINTS_LEVEL2];

const unsigned short * g_currentCollisionMap;

const int * g_currentCollisionMapInfo;

bool g_yellowFilter;

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------

void goToGameState(T_GAME_STATE p_newState);

void leaveGameState(void);

void manageScroll(void);

void init(void);

void goToLastCheckPoint(void);

void fadeToBlack(u8 p_speed, bool p_beat);

void fadeFromBlack(u8 p_speed, bool p_beat);

void setYellowFilter(T_GAME_STATE p_gameState);

#endif
