#include "sprites.h"
#include "beats.h"
#include "levels.h"
#include "score.h"

#include "gfx/all_gfx.h"

inline u16 getTile(const s16 p_x, const s16 p_y)
{
  return g_currentCollisionMap[((p_y >> 3) * (g_currentCollisionMapInfo[1] >> 3)) + (p_x >> 3)];
}

void manageCollisions(void)
{
  // Memorize collisions
  u16 l_collisionDown = getTile(X + HITBOX_DOWN_X, Y + HITBOX_DOWN_Y);
  u16 l_collisionUp = getTile(X + HITBOX_UP_X, Y + HITBOX_UP_Y);
  u16 l_collisionLeft = getTile(X + HITBOX_LEFT_X, Y + HITBOX_LEFT_Y);
  u16 l_collisionRight = getTile(X + HITBOX_RIGHT_X, Y + HITBOX_RIGHT_Y);
  // Adjust down collision
  while (getTile(X + HITBOX_DOWN_X, Y + HITBOX_DOWN_Y) && (getTile(X + HITBOX_DOWN_X, Y + HITBOX_DOWN_Y) != 2))
    g_spriteMonkey.y -= 256;
  // Adjust up collision
  while (getTile(X + HITBOX_UP_X, Y + HITBOX_UP_Y)  && (getTile(X + HITBOX_UP_X, Y + HITBOX_UP_Y) != 2))
    g_spriteMonkey.y += 256;
  // Adjust left collision
  while (getTile(X + HITBOX_LEFT_X, Y + HITBOX_LEFT_Y) && (getTile(X + HITBOX_LEFT_X, Y + HITBOX_LEFT_Y) != 3))
    g_spriteMonkey.x += 256;
  // Adjust right collision
  while (getTile(X + HITBOX_RIGHT_X, Y + HITBOX_RIGHT_Y) && (getTile(X + HITBOX_RIGHT_X, Y + HITBOX_RIGHT_Y) != 3))
    g_spriteMonkey.x -= 256;
  // Chech if spikes were touched
  if (l_collisionDown == 2 || l_collisionUp == 2 || l_collisionLeft == 4 || l_collisionRight == 3)
  {
    goToMonkeyState(MONKEY_STATE_KO);
  }
  // Check if the heart was touched
  else if (l_collisionDown == 5 || l_collisionUp == 5 || l_collisionLeft == 5 || l_collisionRight == 5)
  {
    goToMonkeyState(MONKEY_STATE_LOVE);
  }
  else
  {
    // Manage collision down
    if (l_collisionDown)
    {
      if (g_spriteMonkey.vy > 0)
      {
        // End of jump
        goToMonkeyState(MONKEY_STATE_IDLE);
        // Handle immediate flip
        if ((Pad.Newpress.Left || Pad.Held.Left) && (g_spriteMonkey.direction == DIRECTION_RIGHT))
          turnMonkey(DIRECTION_LEFT);
        else if ((Pad.Newpress.Right || Pad.Held.Right) && (g_spriteMonkey.direction == DIRECTION_LEFT))
          turnMonkey(DIRECTION_RIGHT);
      }
    }
    // Manage collision up
    else if (l_collisionUp)
    {
      if (g_spriteMonkey.vy < 0)
        g_spriteMonkey.vy = 0;
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, PA_GetAngle(g_spriteMonkey.x, g_spriteMonkey.y, g_spriteMonkey.x + g_spriteMonkey.vx, g_spriteMonkey.y + g_spriteMonkey.vy) + 384);
    }
    // Manage collision left
    else if (l_collisionLeft)
    {
      if (g_spriteMonkey.vx < 0)
      {
        // Hang on left wall
        if (g_spriteMonkey.direction == DIRECTION_RIGHT)
          turnMonkey(DIRECTION_LEFT);
        goToMonkeyState(MONKEY_STATE_HANG_LEFT);
      }
    }
    // Manage collision right
    else if (l_collisionRight)
    {
      if (g_spriteMonkey.vx > 0)
      {
        // Hang on right wall
        if (g_spriteMonkey.direction == DIRECTION_LEFT)
          turnMonkey(DIRECTION_RIGHT);
        goToMonkeyState(MONKEY_STATE_HANG_RIGHT);
      }
    }
    else
    {
      // Still jumping
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, PA_GetAngle(g_spriteMonkey.x, g_spriteMonkey.y, g_spriteMonkey.x + g_spriteMonkey.vx, g_spriteMonkey.y + g_spriteMonkey.vy) + 384);
    }
  }
}

// Change state
void goToMonkeyState(const T_MONKEY_STATE p_destState)
{
  switch(p_destState)
  {
    case MONKEY_STATE_IDLE:
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, 0);
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 0);
      g_spriteMonkey.vx = 0;
      g_spriteMonkey.vy = 0;
      break;
    case MONKEY_STATE_JUMP:
      switch (g_spriteMonkey.state)
      {
        case MONKEY_STATE_IDLE:
          if (Pad.Newpress.Left || Pad.Held.Left)
            g_spriteMonkey.vx = -MONKEY_X_MAX_SPEED;
          else if (Pad.Newpress.Right || Pad.Held.Right)
            g_spriteMonkey.vx = MONKEY_X_MAX_SPEED;
          else
          {
            if (g_spriteMonkey.direction == DIRECTION_LEFT)
              g_spriteMonkey.vx = -MONKEY_IDLE_JUMP_SPEED;
            else
              g_spriteMonkey.vx = MONKEY_IDLE_JUMP_SPEED;
          }
          g_spriteMonkey.vy = -(MONKEY_MIN_JUMP + ((BEAT_MARGIN - beatDifference()) * BEAT_DIFF_FACTOR));
          ++g_jumps;
          displayNbJumps();
          break;
        case MONKEY_STATE_HANG_LEFT:
          g_spriteMonkey.vx = MONKEY_X_MAX_SPEED;
          g_spriteMonkey.vy = -(MONKEY_MIN_JUMP + ((BEAT_MARGIN - beatDifference()) * BEAT_DIFF_FACTOR));
          ++g_jumps;
          displayNbJumps();
          break;
        case MONKEY_STATE_HANG_RIGHT:
          g_spriteMonkey.vx = -MONKEY_X_MAX_SPEED;
          g_spriteMonkey.vy = -(MONKEY_MIN_JUMP + ((BEAT_MARGIN - beatDifference()) * BEAT_DIFF_FACTOR));
          ++g_jumps;
          displayNbJumps();
          break;
        case MONKEY_STATE_KO:
          g_spriteMonkey.vx = 256;
          g_spriteMonkey.vy = 0;
          g_spriteMonkey.sx = 0;
          if (g_spriteMonkey.direction == DIRECTION_LEFT)
            turnMonkey(DIRECTION_RIGHT);
          break;
        default:
          break;
      }
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 2);
      break;
    case MONKEY_STATE_HANG_LEFT:
    case MONKEY_STATE_HANG_RIGHT:
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, 0);
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 3);
      g_spriteMonkey.vx = 0;
      g_spriteMonkey.vy = 0;
      break;
    case MONKEY_STATE_KO:
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, 0);
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 5);
      g_spriteMonkey.vx = 0;
      g_spriteMonkey.vy = 0;
      break;
    case MONKEY_STATE_LOVE:
      PA_DualSetRotsetNoZoom(MONKEY_ROTSET_NUMBER, 0);
      if (X + 15 <= 3951)
      {
        if (g_spriteMonkey.direction == DIRECTION_LEFT)
          turnMonkey(DIRECTION_RIGHT);
        g_spriteMonkey.x = 3921 << 8;
      }
      else
      {
        if (g_spriteMonkey.direction == DIRECTION_RIGHT)
          turnMonkey(DIRECTION_LEFT);
        g_spriteMonkey.x = 3951 << 8;
      }
      switch(g_gameState)
      {
        case GAME_STATE_LEVEL1: g_spriteMonkey.y = 272 << 8; break;
        case GAME_STATE_LEVEL2: g_spriteMonkey.y = 32 << 8; break;
        default: break;
      }
      g_spriteMonkey.vx = 0;
      g_spriteMonkey.vy = 0;
      PA_DualSetSpriteAnim(MONKEY_SPRITE_NUMBER, 3);
      break;
    default:
      break;
  }
  g_spriteMonkey.state = p_destState;
}

// Turn monkey right or left
void turnMonkey(T_DIRECTION p_newDirection)
{
  switch (p_newDirection)
  {
    case DIRECTION_LEFT:
      PA_DualDeleteSprite(MONKEY_SPRITE_NUMBER);
      PA_DualCreateSprite(MONKEY_SPRITE_NUMBER, (void*)monkeyLeft_Sprite, OBJ_SIZE_32X32, 1, 0, X, Y);
      if (g_gameState == GAME_STATE_LEVEL2) PA_DualSetSpritePrio(MONKEY_SPRITE_NUMBER, 1);
      PA_DualSetSpriteRotEnable(MONKEY_SPRITE_NUMBER, MONKEY_ROTSET_NUMBER);
      break;
    case DIRECTION_RIGHT:
      PA_DualDeleteSprite(MONKEY_SPRITE_NUMBER);
      PA_DualCreateSprite(MONKEY_SPRITE_NUMBER, (void*)monkeyRight_Sprite, OBJ_SIZE_32X32, 1, 0, X, Y);
      if (g_gameState == GAME_STATE_LEVEL2) PA_DualSetSpritePrio(MONKEY_SPRITE_NUMBER, 1);
      PA_DualSetSpriteRotEnable(MONKEY_SPRITE_NUMBER, MONKEY_ROTSET_NUMBER);
      break;
    default:
      break;
  }
  g_spriteMonkey.direction = p_newDirection;
}

void updateMonkeyPosition(void)
{
  // Add gravity
  g_spriteMonkey.vy += GRAVITY;
  // In-jump control
  if (Pad.Newpress.Left || Pad.Held.Left)
  {
    if (g_spriteMonkey.vx - MONKEY_INJUMP_MOVE >= -MONKEY_X_MAX_SPEED)
      g_spriteMonkey.vx = g_spriteMonkey.vx - MONKEY_INJUMP_MOVE;
  }
  else if (Pad.Newpress.Right || Pad.Held.Right)
  {
    if (g_spriteMonkey.vx + MONKEY_INJUMP_MOVE <= MONKEY_X_MAX_SPEED)
      g_spriteMonkey.vx = g_spriteMonkey.vx + MONKEY_INJUMP_MOVE;
  }
  // Set new position
  g_spriteMonkey.x += g_spriteMonkey.vx;
  g_spriteMonkey.y += g_spriteMonkey.vy;
}

// Move monkey
void moveMonkey(void)
{
  // Handle input for state change
  switch(g_spriteMonkey.state)
  {
//------------------------------------------------------------------------------
    case MONKEY_STATE_KO:
      fadeToBlack(1, true);
      goToLastCheckPoint();
      g_spriteMonkey.sx = 0;
      manageScroll();
      PA_DualSetSpriteXY(MONKEY_SPRITE_NUMBER, -32, -32);
      fadeFromBlack(2, true);
      goToMonkeyState(MONKEY_STATE_JUMP);
      break;
//------------------------------------------------------------------------------
    case MONKEY_STATE_IDLE:
      if (Pad.Newpress.A)
        goToMonkeyState(MONKEY_STATE_JUMP);
      else if (Pad.Newpress.Left && (g_spriteMonkey.direction == DIRECTION_RIGHT))
        turnMonkey(DIRECTION_LEFT);
      else if (Pad.Newpress.Right && (g_spriteMonkey.direction == DIRECTION_LEFT))
        turnMonkey(DIRECTION_RIGHT);
      break;
//------------------------------------------------------------------------------
    case MONKEY_STATE_JUMP:
    {
      // Update monkey position
      updateMonkeyPosition();
      // Manage collisions
      manageCollisions();
      // Manage scroll
      if (g_spriteMonkey.state != MONKEY_STATE_LOVE)
        manageScroll();
    }
    break;
//------------------------------------------------------------------------------
    case MONKEY_STATE_HANG_LEFT:
      if (Pad.Newpress.A)
      {
        turnMonkey(DIRECTION_RIGHT);
        goToMonkeyState(MONKEY_STATE_JUMP);
      }
      break;
//------------------------------------------------------------------------------
    case MONKEY_STATE_HANG_RIGHT:
      if (Pad.Newpress.A)
      {
        turnMonkey(DIRECTION_LEFT);
        goToMonkeyState(MONKEY_STATE_JUMP);
      }
      break;
//------------------------------------------------------------------------------
    case MONKEY_STATE_LOVE:
      if (g_spriteMonkey.sx < g_currentCollisionMapInfo[1] - 256)
      {
        ++g_spriteMonkey.sx;
        PA_DualParallaxScrollX(g_spriteMonkey.sx);
      }
      else
      {
        // Go to result of the current level
        goToGameState((T_GAME_STATE)(g_gameState + 1));
        // Stop sound
        PA_StopSound(0);
      }
      break;
//------------------------------------------------------------------------------
    default:
      break;
  }
//------------------------------------------------------------------------------
  // Set new position
  PA_DualSetSpriteXY(MONKEY_SPRITE_NUMBER, X - g_spriteMonkey.sx, Y);
}
