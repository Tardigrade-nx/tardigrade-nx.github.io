#include <PA9.h>

#include "gfx/all_gfx.h"

#include "sprites.h"
#include "beats.h"
#include "levels.h"

// Main function
int main(void)
{
  // PAlib init
  PA_Init();
  PA_InitVBL();
  PA_InitSound();
  
  // Init stuff
  init();
  // Black !
  PA_SetBrightness(0, -31);
  PA_SetBrightness(1, -31);
  // Go to title
  goToGameState(GAME_STATE_LEVEL2);
  
  while (1)
  {
    switch (g_gameState)
    {
//------------------------------------------------------------------------------
      case GAME_STATE_TITLE:
        if (Pad.Newpress.A)
        {
          leaveGameState();
          goToGameState(GAME_STATE_LEVEL1);
        }
        else if (Pad.Newpress.B)
        {
          leaveGameState();
          goToGameState(GAME_STATE_LEVEL2);
        }
        else if (Pad.Newpress.Select)
        {
          g_yellowFilter = !g_yellowFilter;
          setYellowFilter(GAME_STATE_TITLE);
        }
        else
        {
          PA_DualParallaxScrollX(g_spriteMonkey.sx++);
          PA_WaitForVBL();
        }
        break;
//------------------------------------------------------------------------------
      case GAME_STATE_LEVEL1:
      case GAME_STATE_LEVEL2:
        if (Pad.Newpress.Start)
        {
          leaveGameState();
          goToGameState(GAME_STATE_LEVEL2);
        }
        else
        {
          manageBeat();
          moveMonkey();
          PA_WaitForVBL();
        }
        break;
//------------------------------------------------------------------------------
      case GAME_STATE_RESULT1:
      case GAME_STATE_RESULT2:
        if (Pad.Newpress.A)
        {
          leaveGameState();
          goToGameState(GAME_STATE_LEVEL2);
        }
        else
        {
          PA_WaitForVBL();
        }
        break;
//------------------------------------------------------------------------------
      default:
        // Wait for frame
        PA_WaitForVBL();
        break;
    }
  }
  
  return 0;
}
