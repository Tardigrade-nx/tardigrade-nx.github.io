#include <PA9.h>
#include <stdio.h>

// PAGfxConverter Include
#include "gfx/all_gfx.c"
#include "gfx/all_gfx.h"

#include "sprites.h"

#include "boom.h"
#include "wind.h"
#include "cherry.h"
#include "ding.h"
#include "hit.h"
#include "land.h"

u16 g_shurikenRotationAngle = 0;
u16 g_explosionTimer[2] = {0, 0};
u8 g_life[2] = {HEART_NB_MAX, HEART_NB_MAX};
bool g_damaged[2] = {false, false};
u32 g_frameCounter = 0;
u32 g_score = 0;
u32 g_scoreAdd = 0;
u16 g_bulletsTotal = 0;
u16 g_bulletsKilled = 0;
u16 g_DSTotal = 0;
u16 g_DSGot = 0;

// Init global variables
inline void initGlobalVariables(void)
{
  g_shurikenRotationAngle = 0;
  g_explosionTimer[0] = 0;
  g_explosionTimer[1] = 0;
  g_life[0] = HEART_NB_MAX;
  g_life[1] = HEART_NB_MAX;
  g_damaged[0] = false;
  g_damaged[1] = false;
  g_frameCounter = 0;
  g_score = 0;
  g_scoreAdd = 0;
  g_bulletsTotal = 0;
  g_bulletsKilled = 0;
  g_DSTotal = 0;
  g_DSGot = 0;
}

// Go to a given state
void goToState(const T_NINJI_STATE p_destState)
{
  switch (p_destState)
  {
    case NINJI_STATE_IDLE:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_StartSpriteAnim(0, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
      PA_StartSpriteAnim(1, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
      g_spriteNinji.vx = 0;
      break;
    case NINJI_STATE_WALK_RIGHT:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteHflip(0, NINJI_SPRITE_NUMBER, 1);
      PA_SetSpriteHflip(1, NINJI_SPRITE_NUMBER, 1);
      PA_StartSpriteAnim(0, NINJI_SPRITE_NUMBER, 2, 7, NINJI_WALK_ANIM_SPEED);
      PA_StartSpriteAnim(1, NINJI_SPRITE_NUMBER, 2, 7, NINJI_WALK_ANIM_SPEED);
      g_spriteNinji.vx = NINJI_WALK_SPEED;
      break;
    case NINJI_STATE_WALK_LEFT:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteHflip(0, NINJI_SPRITE_NUMBER, 0);
      PA_SetSpriteHflip(1, NINJI_SPRITE_NUMBER, 0);
      PA_StartSpriteAnim(0, NINJI_SPRITE_NUMBER, 2, 7, NINJI_WALK_ANIM_SPEED);
      PA_StartSpriteAnim(1, NINJI_SPRITE_NUMBER, 2, 7, NINJI_WALK_ANIM_SPEED);
      g_spriteNinji.vx = -NINJI_WALK_SPEED;
      break;
    case NINJI_STATE_PRE_JUMP:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 8);
      PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 8);
      g_spriteNinji.jumpCharge = NINJI_JUMP_MIN_CHARGE;
      break;
    case NINJI_STATE_JUMP:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 9);
      PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 9);
      g_spriteNinji.vy = - g_spriteNinji.jumpCharge * (NINJI_JUMP / NINJI_JUMP_MAX_CHARGE);
      break;
    case NINJI_STATE_PUNCH:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 12);
      PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 0);
      g_spriteNinji.vx = 0;
      g_spriteNinji.attackTimer = 0;
      break;
    case NINJI_STATE_KICK:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 14);
      PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 0);
      g_spriteNinji.vx = 0;
      g_spriteNinji.attackTimer = 0;
      break;
    case NINJI_STATE_JUMP_PUNCH:
      g_spriteNinji.attackTimer = 0;
      if (g_spriteNinji.weapon == NINJI_WEAPON_SWORD) PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 18);
      else PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 12);
      break;
    case NINJI_STATE_JUMP_KICK:
      g_spriteNinji.attackTimer = 0;
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 14);
      break;
    case NINJI_STATE_DAMAGE:
      PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
      PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 17);
      PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 12);
      g_spriteNinji.vy = -NINJI_DAMAGE_VY;
      if (PA_GetSpriteHflip(0, NINJI_SPRITE_NUMBER))
        g_spriteNinji.vx = -NINJI_DAMAGE_VX;
      else
        g_spriteNinji.vx = NINJI_DAMAGE_VX;
      break;
    case NINJI_STATE_SPIN_NUNCHAK:
      g_spriteNinji.attackTimer = 0;
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 18);
      break;
    default:
      break;
  }
  g_spriteNinji.state = p_destState;
}

// Change weapon
void changeWeapon(const T_NINJI_WEAPON p_destWeapon)
{
  // Stop animations
  PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
  PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
  // Memorize current HFlip
  const u8 l_hflip = PA_GetSpriteHflip(0, NINJI_SPRITE_NUMBER);
  // Delete current Ninji sprite
  PA_DeleteSprite(0, NINJI_SPRITE_NUMBER);
  // Create specific sprite
  switch(p_destWeapon)
  {
    case NINJI_WEAPON_NONE:
      // Create Sword Ninji sprite
      PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
      // Adjust weapon selection frame
      PA_SetSpriteX(0, FRAME_SPRITE_NUMBER, 188);
      break;
    case NINJI_WEAPON_SWORD:
      // Create Sword Ninji sprite
      PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_sword_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
      // Adjust weapon selection frame
      PA_SetSpriteX(0, FRAME_SPRITE_NUMBER, 204);
      break;
    case NINJI_WEAPON_NUNCHAK:
      // Create Nunchak Ninji sprite
      PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_nunchak_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
      // Adjust weapon selection frame
      PA_SetSpriteX(0, FRAME_SPRITE_NUMBER, 220);
      break;
    case NINJI_WEAPON_SHURIKEN:
      // Create Shuriken Ninji sprite
      PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_shuriken_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
      // Adjust weapon selection frame
      PA_SetSpriteX(0, FRAME_SPRITE_NUMBER, 236);
      break;
    default:
      break;
  }
  // Set hflip
  PA_SetSpriteHflip(0, NINJI_SPRITE_NUMBER, l_hflip);
  // Set new current weapon
  g_spriteNinji.weapon = p_destWeapon;
  // Initialize state
  switch (g_spriteNinji.state)
  {
    case NINJI_STATE_PUNCH:
    case NINJI_STATE_KICK:
      goToState(NINJI_STATE_IDLE);
    case NINJI_STATE_JUMP:
    case NINJI_STATE_JUMP_PUNCH:
    case NINJI_STATE_JUMP_KICK:
      if (g_spriteNinji.vy > 0) PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 10);
      else PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 9);
      g_spriteNinji.state = NINJI_STATE_JUMP;
      break;
    case NINJI_STATE_DAMAGE:
      if (g_spriteNinji.vy > 0) PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 16);
      else PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 17);
      g_spriteNinji.state = NINJI_STATE_DAMAGE;
      break;
    default:
      goToState(g_spriteNinji.state);
      break;
  }
}

// Upgrade weapon
void upgradeWeapon(const u8 p_upgrade)
{
  if (p_upgrade == 1)
  {
    if (g_spriteNinji.weapon < NB_NINJI_WEAPONS - 1)
      changeWeapon(g_spriteNinji.weapon + 1);
  }
  else
  {
    if (g_spriteNinji.weapon > 0)
      changeWeapon(g_spriteNinji.weapon - 1);
  }
}

// Create a shuriken, if possible
void createShuriken(void)
{
  u8 l_i = 0;
  bool l_found = false;

  // Get first free number
  while ((!l_found) && (l_i < SHURIKEN_NB_MAX))
  {
    if (!g_shurikens[l_i].created)
    {
      // This sprite number is free
      l_found = true;
    }
    else 
    {
      // Next
      ++l_i;
    }
  }
  if (l_found)
  {
    // Set the sprite attributes depending on Ninji HFlip
    if (PA_GetSpriteHflip(0, NINJI_SPRITE_NUMBER))
    {
      g_shurikens[l_i].x = g_spriteNinji.x + (38 << 8);
      g_shurikens[l_i].y = g_spriteNinji.y + (12 << 8);
      g_shurikens[l_i].vx = SHURIKEN_SPEED;
      g_shurikens[l_i].created = true;
      PA_CreateSprite(0, l_i + SHURIKEN_NB_START, (void*)shuriken_Sprite, OBJ_SIZE_16X16, 1, 0, g_shurikens[l_i].x >> 8, g_shurikens[l_i].y >> 8);
      PA_SetSpriteRotEnable(0, l_i + SHURIKEN_NB_START, 0);
    }
    else
    {
      g_shurikens[l_i].x = g_spriteNinji.x + (10 << 8);
      g_shurikens[l_i].y = g_spriteNinji.y + (12 << 8);
      g_shurikens[l_i].vx = -SHURIKEN_SPEED;
      g_shurikens[l_i].created = true;
      PA_CreateSprite(0, l_i + SHURIKEN_NB_START, (void*)shuriken_Sprite, OBJ_SIZE_16X16, 1, 0, g_shurikens[l_i].x >> 8, g_shurikens[l_i].y >> 8);
      PA_SetSpriteRotEnable(0, l_i + SHURIKEN_NB_START, 1);
    }
  }
}

// Create a bullet, if possible
void createBullet(const u8 p_screen, const u8 p_direction, const u8 p_y)
{
  u8 l_i = 0;
  bool l_found = false;
  
  // Get first free number
  while ((!l_found) && (l_i < BULLET_NB_MAX))
  {
    if (g_bullets[p_screen][l_i].state == BULLET_STATE_INACTIVE)
      // This sprite number is free
      l_found = true;
    else 
      // Next
      ++l_i;
  }
  if (l_found)
  {
    switch(p_direction)
    {
      case 0: // Left
        g_bullets[p_screen][l_i].x = (256 - BULLET_COLLISION_X_GAP) << 8;
        g_bullets[p_screen][l_i].y = p_y << 8;
        g_bullets[p_screen][l_i].vx = -BULLET_SPEED;
        g_bullets[p_screen][l_i].vy = 0;
        g_bullets[p_screen][l_i].state = BULLET_STATE_ALIVE;
        g_bullets[p_screen][l_i].angle = 0;
        PA_SetRotsetNoZoom(p_screen, l_i + BULLET_ROTSET_START, 0);
        PA_CreateSprite(p_screen, l_i + BULLET_NB_START, (void*)bulletLeft_Sprite, OBJ_SIZE_32X32, 1, 0, g_bullets[p_screen][l_i].x >> 8, g_bullets[p_screen][l_i].y >> 8);
        PA_SetSpriteRotEnable(p_screen, l_i + BULLET_NB_START, l_i + BULLET_ROTSET_START);
        ++g_bulletsTotal;
        break;
      case 1: // Right
        g_bullets[p_screen][l_i].x = (-BULLET_WIDTH + BULLET_COLLISION_X_GAP) << 8;
        g_bullets[p_screen][l_i].y = p_y << 8;
        g_bullets[p_screen][l_i].vx = BULLET_SPEED;
        g_bullets[p_screen][l_i].vy = 0;
        g_bullets[p_screen][l_i].state = BULLET_STATE_ALIVE;
        g_bullets[p_screen][l_i].angle = 0;
        PA_SetRotsetNoZoom(p_screen, l_i + BULLET_ROTSET_START, 0);
        PA_CreateSprite(p_screen, l_i + BULLET_NB_START, (void*)bulletRight_Sprite, OBJ_SIZE_32X32, 1, 0, g_bullets[p_screen][l_i].x >> 8, g_bullets[p_screen][l_i].y >> 8);
        PA_SetSpriteRotEnable(p_screen, l_i + BULLET_NB_START, l_i + BULLET_ROTSET_START);
        ++g_bulletsTotal;
        break;
      default:
        break;
    }
  }
}

// Create the item
void createItem(const s16 p_x, const s16 p_y)
{
  if (!g_spriteItem.created)
  {
    g_spriteItem.x = p_x;
    g_spriteItem.y = p_y;
    g_spriteItem.created = true;
    g_spriteItem.alive = true;
    g_spriteItem.alpha = 0;
    PA_CreateSprite(1, ITEM_SPRITE_NUMBER, (void*)DS_Sprite, OBJ_SIZE_16X16, 1, 0, g_spriteItem.x, g_spriteItem.y);
    PA_SetSpriteMode(1, ITEM_SPRITE_NUMBER, 1);
    ++g_DSTotal;
  }
}

// Destroy the item
void destroyItem(void)
{
  if (g_spriteItem.created)
  {
    PA_DeleteSprite(1, ITEM_SPRITE_NUMBER);
    g_spriteItem.created = false;
  }
}

// Manage punch attack while jumping
void manageJumpPunch(void)
{
  // Update timer
  ++g_spriteNinji.attackTimer;
  // Manage punch
  if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION + NINJI_ATTACK_DURATION)
  {
    // End of punch
    if (g_spriteNinji.vy > 0) PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 10);
    else PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 9);
    g_spriteNinji.state = NINJI_STATE_JUMP;
  }
  else if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION)
  {
    if (g_spriteNinji.weapon == NINJI_WEAPON_SWORD) PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 19);
    else PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 13);
    if (g_spriteNinji.weapon == NINJI_WEAPON_SHURIKEN) createShuriken();
  }
}

// Manage kick attack while jumping
void manageJumpKick(void)
{
  // Update timer
  ++g_spriteNinji.attackTimer;
  // Manage kick
  if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION + NINJI_ATTACK_DURATION)
  {
    // End of kick
    if (g_spriteNinji.vy > 0)
    {
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 10);
    }
    else
    {
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 9);
    }
    g_spriteNinji.state = NINJI_STATE_JUMP;
  }
  else if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION)
  {
    PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 15);
  }
}

// Manage jump
void manageJump(void)
{
  // Add gravity
  g_spriteNinji.vy += GRAVITY;
  // Adjust jump
  if (Pad.Newpress.Left || Pad.Held.Left)
  {
    if (g_spriteNinji.vx > -NINJI_WALK_SPEED)
      g_spriteNinji.vx -= NINJI_ADJUST_JUMP;
  }
  else if (Pad.Newpress.Right || Pad.Held.Right)
  {
    if (g_spriteNinji.vx < NINJI_WALK_SPEED)
      g_spriteNinji.vx += NINJI_ADJUST_JUMP;
  }
  // Check 'fall' anim frame
  if (g_spriteNinji.vy > 0)
  {
    switch(g_spriteNinji.state)
    {
      case NINJI_STATE_JUMP:
        PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 10);
        PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 10);
        break;
      case NINJI_STATE_DAMAGE:
        PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 16);
        PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 11);
        break;
      default:
        break;
    }
  }
}

// Manage end of jump
void manageEndOfJump(void)
{
  // Check end of jump at next frame
  if ((g_spriteNinji.y + g_spriteNinji.vy) > (NINJI_GROUND_Y << 8))
  {
    // End of jump
    g_spriteNinji.y = NINJI_GROUND_Y << 8;
    g_spriteNinji.vy = 0;
    // Check damage
    if (g_spriteNinji.state == NINJI_STATE_DAMAGE)
    {
      // -1 heart
      if (g_damaged[0])
      {
        if (g_life[0] > 0)
        {
          PA_SetSpriteAnim(0, g_life[0] - 1 + HEART_NB_START, 1);
          --g_life[0];
        }
        g_damaged[0] = false;
      }
      if (g_damaged[1])
      {
        if (g_life[1] > 0)
        {
          PA_SetSpriteAnim(1, g_life[1] - 1 + HEART_NB_START, 1);
          --g_life[1];
        }
        g_damaged[1] = false;
      }
    }
    if (Pad.Newpress.Left || Pad.Held.Left)
    {
      goToState(NINJI_STATE_WALK_LEFT);
    }
    else if (Pad.Newpress.Right || Pad.Held.Right)
    {
      goToState(NINJI_STATE_WALK_RIGHT);
    }
    else
    {
      goToState(NINJI_STATE_IDLE);
    }
  }
}

// Manage kick
void manageKick(void)
{
  // Update timer
  ++g_spriteNinji.attackTimer;
  // Manage kick
  if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION + NINJI_ATTACK_DURATION)
  {
    // End of kick
    if (Pad.Newpress.Left || Pad.Held.Left)
      goToState(NINJI_STATE_WALK_LEFT);
    else if (Pad.Newpress.Right || Pad.Held.Right)
      goToState(NINJI_STATE_WALK_RIGHT);
    else
      goToState(NINJI_STATE_IDLE);
  }
  else if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION)
    PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 15);
}

// Manage punch
void managePunch(void)
{
  // Update timer
  ++g_spriteNinji.attackTimer;
  // Manage punch
  if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION + NINJI_ATTACK_DURATION)
  {
    if ((g_spriteNinji.weapon == NINJI_WEAPON_NUNCHAK) && (Pad.Held.Y))
    {
      goToState(NINJI_STATE_SPIN_NUNCHAK);
    }
    else
    {
      // End of punch
      if (Pad.Newpress.Left || Pad.Held.Left)
        goToState(NINJI_STATE_WALK_LEFT);
      else if (Pad.Newpress.Right || Pad.Held.Right)
        goToState(NINJI_STATE_WALK_RIGHT);
      else
        goToState(NINJI_STATE_IDLE);
    }
  }
  else if (g_spriteNinji.attackTimer == NINJI_PRE_ATTACK_DURATION)
  {
    PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 13);
    if (g_spriteNinji.weapon == NINJI_WEAPON_SHURIKEN) createShuriken();
  }
}

// Spin the nunchak
void manageSpinNunchak(void)
{
  if (Pad.Held.Y)
  {
    // Update timer
    ++g_spriteNinji.attackTimer;
    // Manage spin nunchak
    if (g_spriteNinji.attackTimer == NINJI_SPIN_NUNCHAK_SPEED + NINJI_SPIN_NUNCHAK_SPEED)
    {
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 18);
      g_spriteNinji.attackTimer = 0;
    }
    else if (g_spriteNinji.attackTimer == NINJI_SPIN_NUNCHAK_SPEED)
    {
      PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 19);
    }
  }
  else
  {
    // End of spin
    if (Pad.Newpress.Left || Pad.Held.Left)
      goToState(NINJI_STATE_WALK_LEFT);
    else if (Pad.Newpress.Right || Pad.Held.Right)
      goToState(NINJI_STATE_WALK_RIGHT);
    else
      goToState(NINJI_STATE_IDLE);
  }
}

// Move Ninji
inline void moveNinji(void)
{
  switch (g_spriteNinji.state)
  {
//------------------------------------------------------------------------------
    case NINJI_STATE_IDLE:
      if (Pad.Newpress.Right || Pad.Held.Right)
        goToState(NINJI_STATE_WALK_RIGHT);
      else if (Pad.Newpress.Left || Pad.Held.Left)
        goToState(NINJI_STATE_WALK_LEFT);
      else if (Pad.Newpress.B)
        goToState(NINJI_STATE_PRE_JUMP);
      else if (Pad.Newpress.Y)
        goToState(NINJI_STATE_PUNCH);
      else if (Pad.Newpress.A)
        goToState(NINJI_STATE_KICK);
      else if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_WALK_RIGHT:
      if (Pad.Released.Right)
        goToState(NINJI_STATE_IDLE);
      if (Pad.Newpress.B)
        goToState(NINJI_STATE_PRE_JUMP);
      else if (Pad.Newpress.Y)
        goToState(NINJI_STATE_PUNCH);
      else if (Pad.Newpress.A)
        goToState(NINJI_STATE_KICK);
      else if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_WALK_LEFT:
      if (Pad.Released.Left)
        goToState(NINJI_STATE_IDLE);
      if (Pad.Newpress.B)
        goToState(NINJI_STATE_PRE_JUMP);
      else if (Pad.Newpress.Y)
        goToState(NINJI_STATE_PUNCH);
      else if (Pad.Newpress.A)
        goToState(NINJI_STATE_KICK);
      else if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_PRE_JUMP:
      // Sprite doesn't move but keeps the same vx
      g_spriteNinji.x -= g_spriteNinji.vx;
      // Manage jump
      if (Pad.Released.B)
        goToState(NINJI_STATE_JUMP);
      else if (g_spriteNinji.jumpCharge < NINJI_JUMP_MAX_CHARGE)
        ++g_spriteNinji.jumpCharge;
      else if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_JUMP:
      manageJump();
      if (Pad.Newpress.Y)
        goToState(NINJI_STATE_JUMP_PUNCH);
      else if (Pad.Newpress.A)
        goToState(NINJI_STATE_JUMP_KICK);
      else if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      manageEndOfJump();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_JUMP_PUNCH:
      manageJump();
      manageJumpPunch();
      manageEndOfJump();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_JUMP_KICK:
      manageJump();
      manageJumpKick();
      manageEndOfJump();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_PUNCH:
      managePunch();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_KICK:
      manageKick();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_DAMAGE:
      // Jump
      manageJump();
      if (Pad.Newpress.R)
        upgradeWeapon(1);
      else if (Pad.Newpress.L)
        upgradeWeapon(0);
      // End of jump
      manageEndOfJump();
      break;
//------------------------------------------------------------------------------
    case NINJI_STATE_SPIN_NUNCHAK:
      manageSpinNunchak();
      break;
//------------------------------------------------------------------------------
    default:
      break;
  }

  // Move Ninji
  g_spriteNinji.x += g_spriteNinji.vx;
  g_spriteNinji.y += g_spriteNinji.vy;
  // Check x
  if (g_spriteNinji.x < ((1 - NINJI_OFFSET_X) << 8))
    g_spriteNinji.x = (1 - NINJI_OFFSET_X) << 8;
  else if (g_spriteNinji.x > ((255 - NINJI_WIDTH + NINJI_OFFSET_X) << 8))
    g_spriteNinji.x = (255 - NINJI_WIDTH + NINJI_OFFSET_X) << 8;
  // Set new position
  PA_SetSpriteXY(0, NINJI_SPRITE_NUMBER, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
  // Zarbi copies Ninji's position
  PA_SetSpriteXY(1, NINJI_SPRITE_NUMBER, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
}

// Move created shurikens
inline void moveShurikens(void)
{
  // Loop on all shurikens
  u8 l_i = 0;
  bool l_shurikenFound = false;
  for (l_i = 0; l_i < SHURIKEN_NB_MAX; ++l_i)
  {
    if (g_shurikens[l_i].created)
    {
      if (!l_shurikenFound)
        l_shurikenFound = true;
      // Shuriken exists => we move it
      g_shurikens[l_i].x += g_shurikens[l_i].vx;
      // Check whether the shuriken is outside of the screen
      if (((g_shurikens[l_i].x >> 8) < -14) || ((g_shurikens[l_i].x >> 8) > 253))
      {
        // It is outside => we delete it
        g_shurikens[l_i].created = false;
        PA_DeleteSprite(0, l_i + SHURIKEN_NB_START);
      }
      // Set new position
      PA_SetSpriteX(0, l_i + SHURIKEN_NB_START, g_shurikens[l_i].x >> 8);
    }
  }
  // Rotate if there is at least one shuriken
  if (l_shurikenFound)
  {
    g_shurikenRotationAngle += SHURIKEN_ROTATION_SPEED;
    g_shurikenRotationAngle &= 511;
    PA_SetRotsetNoZoom(0, 0, -g_shurikenRotationAngle);
    PA_SetRotsetNoZoom(0, 1, g_shurikenRotationAngle);
  }
}

// Move created bullets
inline void moveBullets(void)
{
  u8 l_i = 0;
  u8 l_screen = 0;
  
  // Loop on all bullets
  for (l_screen = 0; l_screen < 2; ++l_screen)
  {
    for (l_i = 0; l_i < BULLET_NB_MAX; ++l_i)
    {
      if (g_bullets[l_screen][l_i].state != BULLET_STATE_INACTIVE)
      {
        // Bullet exists => we move it
        g_bullets[l_screen][l_i].x += g_bullets[l_screen][l_i].vx;
        g_bullets[l_screen][l_i].y += g_bullets[l_screen][l_i].vy;
        // Add gravity and rotate if dead
        switch (g_bullets[l_screen][l_i].state)
        {
          case BULLET_STATE_DEAD:
            g_bullets[l_screen][l_i].vy += GRAVITY / 2;
            if (g_bullets[l_screen][l_i].vx > 0)
              PA_SetRotsetNoZoom(l_screen, l_i + BULLET_ROTSET_START, PA_GetAngle(g_bullets[l_screen][l_i].x, g_bullets[l_screen][l_i].y, g_bullets[l_screen][l_i].x + g_bullets[l_screen][l_i].vx, g_bullets[l_screen][l_i].y + g_bullets[l_screen][l_i].vy));
            else
              PA_SetRotsetNoZoom(l_screen, l_i + BULLET_ROTSET_START, 256 + PA_GetAngle(g_bullets[l_screen][l_i].x, g_bullets[l_screen][l_i].y, g_bullets[l_screen][l_i].x + g_bullets[l_screen][l_i].vx, g_bullets[l_screen][l_i].y + g_bullets[l_screen][l_i].vy));
            break;
          case BULLET_STATE_SLASHED:
            g_bullets[l_screen][l_i].vy += GRAVITY;
            if (g_bullets[l_screen][l_i].vx < 0)
              g_bullets[l_screen][l_i].angle += BULLET_ROTATION_SPEED;
            else
              g_bullets[l_screen][l_i].angle -= BULLET_ROTATION_SPEED;
            g_bullets[l_screen][l_i].angle &= 511;
            PA_SetRotsetNoZoom(l_screen, l_i + BULLET_ROTSET_START, g_bullets[l_screen][l_i].angle);
            break;
          default:
            break;
        }
        // Check whether the bullet is outside of the screen
        if (((g_bullets[l_screen][l_i].x >> 8) < -BULLET_WIDTH) ||
            ((g_bullets[l_screen][l_i].x >> 8) > 255) ||
            ((g_bullets[l_screen][l_i].y >> 8) > 191))
        {
          // It is outside => we delete it
          g_bullets[l_screen][l_i].state = BULLET_STATE_INACTIVE;
          PA_DeleteSprite(l_screen, l_i + BULLET_NB_START);
        }
        else
        {
          // Set new position
          PA_SetSpriteXY(l_screen, l_i + BULLET_NB_START, g_bullets[l_screen][l_i].x >> 8, g_bullets[l_screen][l_i].y >> 8);
        }
      }
    }
  }
}

// Manage a contact between Ninji and a bullet
inline bool manageCollisionNinjiBullet(const u8 p_screen, const u8 p_bulletIndex)
{
  // Check whether Ninji hits the bullet (only on bottom screen)
  if (p_screen == 0)
  {
    if (g_spriteNinji.state == NINJI_STATE_PUNCH ||
        g_spriteNinji.state == NINJI_STATE_KICK ||
        g_spriteNinji.state == NINJI_STATE_JUMP_PUNCH ||
        g_spriteNinji.state == NINJI_STATE_JUMP_KICK ||
        g_spriteNinji.state == NINJI_STATE_SPIN_NUNCHAK)
    {
      // Kill the bullet
      if (PA_GetSpriteHflip(0, NINJI_SPRITE_NUMBER) == 0)
        g_bullets[0][p_bulletIndex].vx = -BULLET_SPEED;
      else
        g_bullets[0][p_bulletIndex].vx = BULLET_SPEED;
      g_bullets[0][p_bulletIndex].vy = -BULLET_KILL_JUMP;
      g_bullets[0][p_bulletIndex].state = BULLET_STATE_SLASHED;
      // Add points
      g_scoreAdd += NB_POINTS_BULLET_SLASHED;
      ++g_bulletsKilled;
      // Play sound
      PA_StopStream(5);
      PA_PlaySoundEx(5, hit, (u32)hit_size, 127, 11025, 0);
      return false;
    }
  }
  // Check whether Ninji stomps on the bullet
  if (g_spriteNinji.state == NINJI_STATE_JUMP ||
      g_spriteNinji.state == NINJI_STATE_JUMP_PUNCH ||
      g_spriteNinji.state == NINJI_STATE_JUMP_KICK ||
      g_spriteNinji.state == NINJI_STATE_DAMAGE)
  {
    if ((g_spriteNinji.vy >= 0) &&
        ((g_spriteNinji.y >> 8) + NINJI_HEIGHT <= (g_bullets[p_screen][p_bulletIndex].y >> 8) + (BULLET_HEIGHT * 0.75)))
    {
      g_bullets[p_screen][p_bulletIndex].state = BULLET_STATE_DEAD;
      // Add points
      g_scoreAdd += NB_POINTS_BULLET_STOMP;
      ++g_bulletsKilled;
      return true;
    }
  }
  // Explosion of the bullet
  PA_StopStream(p_screen + 1);
  PA_PlaySoundEx(p_screen + 1, boom, (u32)boom_size, 127, 11025, 0);
  PA_SetSpriteXY(p_screen, EXPLOSION_SPRITE_NUMBER, (g_bullets[p_screen][p_bulletIndex].x >> 8) - 16, (g_bullets[p_screen][p_bulletIndex].y >> 8) - 47);
  PA_StopSpriteAnim(p_screen, EXPLOSION_SPRITE_NUMBER);
  PA_StartSpriteAnimEx(p_screen, EXPLOSION_SPRITE_NUMBER, 0, 5, EXPLOSION_ANIM_SPEED, ANIM_ONESHOT);
  g_explosionTimer[p_screen] = EXPLOSION_DURATION;
  // Destroy bullet sprite
  g_bullets[p_screen][p_bulletIndex].state = BULLET_STATE_INACTIVE;
  PA_DeleteSprite(p_screen, p_bulletIndex + BULLET_NB_START);
  // Ninji takes damage
  g_damaged[p_screen] = true;
  goToState(NINJI_STATE_DAMAGE);
  return false;
}

// Check collisions between Ninji/Zarbi and bullets
inline void checkCollisionsNinjiBullets(void)
{
  u8 l_i = 0;
  u8 l_screen = 0;
  bool l_stomp = false;
  // Loop on all bullets
  for (l_screen = 0; l_screen < 2; ++l_screen)
  {
    for (l_i = 0; l_i < BULLET_NB_MAX; ++l_i)
    {
      if (g_bullets[l_screen][l_i].state == BULLET_STATE_ALIVE)
      {
        // Check collision between a bullet and Ninji/Zarbi
        // check coordinates
        if (PA_GetSpriteHflip(0, NINJI_SPRITE_NUMBER) == 0)
        {
          // Ninji looking left
          if (((g_bullets[l_screen][l_i].x >> 8) + BULLET_WIDTH - BULLET_COLLISION_X_GAP > (g_spriteNinji.x >> 8) + g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].frontGap) &&
              ((g_bullets[l_screen][l_i].x >> 8) + BULLET_COLLISION_X_GAP < (g_spriteNinji.x >> 8) + NINJI_WIDTH - g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].backGap) &&
              ((g_bullets[l_screen][l_i].y >> 8) + BULLET_HEIGHT - BULLET_COLLISION_BOTTOM_GAP > (g_spriteNinji.y >> 8) + g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].topGap) &&
              ((g_bullets[l_screen][l_i].y >> 8) + BULLET_COLLISION_TOP_GAP < (g_spriteNinji.y >> 8) + NINJI_HEIGHT))
            l_stomp = manageCollisionNinjiBullet(l_screen, l_i);
        }
        else
        {
          // Ninji looking right
          if (((g_bullets[l_screen][l_i].x >> 8) + BULLET_WIDTH - BULLET_COLLISION_X_GAP > (g_spriteNinji.x >> 8) + g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].backGap) &&
              ((g_bullets[l_screen][l_i].x >> 8) + BULLET_COLLISION_X_GAP < (g_spriteNinji.x >> 8) + NINJI_WIDTH - g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].frontGap) &&
              ((g_bullets[l_screen][l_i].y >> 8) + BULLET_HEIGHT - BULLET_COLLISION_BOTTOM_GAP > (g_spriteNinji.y >> 8) + g_collisionGap[g_spriteNinji.state][g_spriteNinji.weapon].topGap) &&
              ((g_bullets[l_screen][l_i].y >> 8) + BULLET_COLLISION_TOP_GAP < (g_spriteNinji.y >> 8) + NINJI_HEIGHT))
            l_stomp = manageCollisionNinjiBullet(l_screen, l_i);
        }
      }
    }
    
    // Manage explosion timer
    if (g_explosionTimer[l_screen] > 0)
    {
      if (g_explosionTimer[l_screen] == 1)
        // Hide bottom explosion
        PA_SetSpriteXY(l_screen, EXPLOSION_SPRITE_NUMBER, -EXPLOSION_WIDTH, -EXPLOSION_WIDTH);
      --g_explosionTimer[l_screen];
    }
  }
  
  // Manage stomp jump
  if (l_stomp)
  {
    // Stomp on the bullet
    if (Pad.Newpress.B || Pad.Held.B)
      g_spriteNinji.vy = -NINJI_KILL_SJUMP;
    else
      g_spriteNinji.vy = -NINJI_KILL_JUMP;
    PA_SetSpriteAnim(0, NINJI_SPRITE_NUMBER, 9);
    PA_SetSpriteAnim(1, NINJI_SPRITE_NUMBER, 9);
    // Play sound
    PA_StopStream(6);
    PA_PlaySoundEx(6, land, (u32)land_size, 127, 11025, 0);
  }
}

// Check collisions between shurikens and bullets
inline void checkCollisionsShurikensBullet(void)
{
  u8 l_bullet = 0;
  u8 l_shuriken = 0;
  // Loop on all bottom bullets
  for (l_bullet = 0; l_bullet < BULLET_NB_MAX; ++l_bullet)
  {
    if (g_bullets[0][l_bullet].state == BULLET_STATE_ALIVE)
    {
      // Loop on all shurikens
      for (l_shuriken = 0; l_shuriken < SHURIKEN_NB_MAX; ++l_shuriken)
      {
        if (g_shurikens[l_shuriken].created)
        {
          if (((g_bullets[0][l_bullet].x >> 8) + BULLET_WIDTH - BULLET_COLLISION_X_GAP > (g_shurikens[l_shuriken].x >> 8) + SHURIKEN_COLLISION_X_GAP) &&
              ((g_bullets[0][l_bullet].x >> 8) + BULLET_COLLISION_X_GAP < (g_shurikens[l_shuriken].x >> 8) + SHURIKEN_WIDTH - SHURIKEN_COLLISION_X_GAP) &&
              ((g_bullets[0][l_bullet].y >> 8) + BULLET_HEIGHT - BULLET_COLLISION_BOTTOM_GAP > (g_shurikens[l_shuriken].y >> 8) + SHURIKEN_COLLISION_Y_GAP) &&
              ((g_bullets[0][l_bullet].y >> 8) + BULLET_COLLISION_TOP_GAP < (g_shurikens[l_shuriken].y >> 8) + SHURIKEN_WIDTH - SHURIKEN_COLLISION_Y_GAP))
          {
            // Collision !
            // Delete Shuriken
            g_shurikens[l_shuriken].created = false;
            PA_DeleteSprite(0, l_shuriken + SHURIKEN_NB_START);
            // Kill bullet
            if (g_shurikens[l_shuriken].vx > 0)
              g_bullets[0][l_bullet].vx = BULLET_SPEED;
            else
              g_bullets[0][l_bullet].vx = -BULLET_SPEED;
            g_bullets[0][l_bullet].vy = -BULLET_KILL_JUMP;
            g_bullets[0][l_bullet].state = BULLET_STATE_SLASHED;
            // Add points
            g_scoreAdd += NB_POINTS_BULLET_SHURIKEN;
            // Play sound
            PA_StopStream(5);
            PA_PlaySoundEx(5, hit, (u32)hit_size, 127, 11025, 0);
          }
        }
      }
    }
  }
}

// Check collisions between Zarbi and the item
inline void checkCollisionsZarbiItem(void)
{
  if (g_spriteItem.created)
  {
    if ((g_spriteItem.x + ITEM_WIDTH > (g_spriteNinji.x >> 8) + NINJI_COLLISION_X_GAP) &&
        (g_spriteItem.x < (g_spriteNinji.x >> 8) + NINJI_WIDTH - NINJI_COLLISION_X_GAP) &&
        (g_spriteItem.y + ITEM_WIDTH > (g_spriteNinji.y >> 8) + NINJI_COLLISION_TOP_GAP) &&
        (g_spriteItem.y < (g_spriteNinji.y >> 8) + NINJI_HEIGHT))
    {
      // Zarbi catches the item
      PA_PlaySoundEx(3, ding, (u32)ding_size, 127, 11025, 0);
      ++g_DSGot;
      g_scoreAdd += NB_POINTS_ITEM_GOT;
      destroyItem();
    }
  }
}

// Manage item alpha blending
inline void manageItemAlpha(void)
{
  if (g_spriteItem.created)
  {
    if (g_spriteItem.alive)
    {
      // make the sprite more visible if necessary
      if (g_spriteItem.alpha < 15)
      {
        ++g_spriteItem.alpha;
        PA_SetSFXAlpha(1, g_spriteItem.alpha, 15 - g_spriteItem.alpha);
      }
    }
    else
    {
      // make the sprite less visible, and destroy it if necessary
      if (g_spriteItem.alpha > 0)
      {
        --g_spriteItem.alpha;
        PA_SetSFXAlpha(1, g_spriteItem.alpha, 15 - g_spriteItem.alpha);
      }
      else
      {
        // destroy
        destroyItem();
      }
    }
  }
}

// Update and display score
inline void manageScore(void)
{
  if (g_scoreAdd > 0)
  {
    g_score += 5;
    g_scoreAdd -= 5;
    if (g_score >= 1000000)
      PA_OutputText(1, SCORE_X - 6, 1, "%d", g_score);
    else if (g_score >= 100000)
      PA_OutputText(1, SCORE_X - 5, 1, "%d", g_score);
    else if (g_score >= 10000)
      PA_OutputText(1, SCORE_X - 4, 1, "%d", g_score);
    else if (g_score >= 1000)
      PA_OutputText(1, SCORE_X - 3, 1, "%d", g_score);
    else if (g_score >= 100)
      PA_OutputText(1, SCORE_X - 2, 1, "%d", g_score);
    else if (g_score >= 10)
      PA_OutputText(1, SCORE_X - 1, 1, "%d", g_score);
  }
}

// Wait for all bullets to disappear
void waitForBullets(void)
{
  u8 l_i = 0;
  bool l_found = false;
  // Loop on all bullets
  while ((!l_found) && (l_i < BULLET_NB_MAX))
  {
    if ((g_bullets[0][l_i].state != BULLET_STATE_INACTIVE) ||
        (g_bullets[1][l_i].state != BULLET_STATE_INACTIVE))
    {
      l_found = true;
      --g_frameCounter;
    }
    else
      ++l_i;
  }
}

// Manage the game script ("scenario")
inline void manageScript(void)
{
  // Update frame counter
  ++g_frameCounter;
  // Do something according to the script
  switch(g_frameCounter)
  {
    case 60:
      createBullet(0, 0, 120);
      break;
//------------------------------------------------------------------------------
    case 300:
      createBullet(0, 0, 120);
      break;
    case 340:
      createBullet(1, 0, 100);
      break;
//------------------------------------------------------------------------------
    case 600:
      createBullet(0, 0, 120);
      createBullet(0, 1, 100);
      break;
//------------------------------------------------------------------------------
    case 900:
      createBullet(0, 0, 120);
      createItem(120, 16);
      break;
    case 940:
      createBullet(1, 0, 70);
      break;
//------------------------------------------------------------------------------
    case 1200:
      g_spriteItem.alive = false;
      createBullet(0, 0, 120);
      break;
    case 1240:
      createBullet(1, 1, 130);
      createBullet(1, 1, 100);
      createBullet(1, 1, 70);
      break;
//------------------------------------------------------------------------------
    case 1500:
      createBullet(0, 0, 57);
      break;
    case 1532:
      createBullet(0, 0, 57);
      break;
    case 1550:
      createBullet(1, 0, 110);
      createItem(200, 40);
      break;
//------------------------------------------------------------------------------
    case 1800:
      g_spriteItem.alive = false;
      createBullet(0, 1, 134);
      break;
    case 1850:
      createBullet(1, 0, 124);
      break;
    case 1900:
      createBullet(0, 1, 114);
      break;
    case 1950:
      createBullet(1, 0, 104);
      break;
    case 2000:
      createBullet(0, 1, 94);
      break;
    case 2050:
      createBullet(1, 0, 84);
      break;
    case 2100:
      createItem(180, 16);
      createBullet(0, 1, 74);
      break;
    case 2150:
      createBullet(1, 0, 64);
      break;
//------------------------------------------------------------------------------
    case 2400:
      g_spriteItem.alive = false;
      createBullet(0, 1, 55);
      createBullet(0, 1, 80);
      createBullet(0, 1, 105);
      createBullet(0, 1, 130);
      break;
    case 2420:
      createItem(10, 140);
      break;
//------------------------------------------------------------------------------
    case 2700:
      g_spriteItem.alive = false;
      createBullet(1, 0, 130);
      break;
    case 2740:
      createBullet(1, 0, 130);
      break;
    case 2780:
      createBullet(1, 0, 130);
      break;
    case 2820:
      createBullet(1, 0, 130);
      createBullet(0, 0, 95);
      break;
//------------------------------------------------------------------------------
    case 3100:
      createBullet(0, 0, 130);
      break;
    case 3140:
      createBullet(1, 0, 130);
      break;
    case 3180:
      createBullet(0, 0, 130);
      break;
    case 3220:
      createBullet(1, 0, 130);
      break;
//------------------------------------------------------------------------------
    case 3500:
      createBullet(0, 0, 130);
      break;
    case 3540:
      createBullet(1, 0, 80);
      break;
    case 3580:
      createBullet(0, 0, 130);
      break;
    case 3620:
      createBullet(1, 0, 80);
      createItem(190, 16);
      break;
//------------------------------------------------------------------------------
    case 3900:
      g_spriteItem.alive = false;
      createBullet(1, 0, 130);
      break;
    case 3940:
      createBullet(0, 0, 50);
      break;
    case 3980:
      createBullet(1, 0, 130);
      break;
    case 4020:
      createBullet(0, 0, 50);
      break;
    case 4060:
      createBullet(1, 0, 130);
      break;
    case 4100:
      createBullet(0, 0, 50);
      break;
//------------------------------------------------------------------------------
    case 4400:
      createBullet(0, 0, 100);
      createBullet(0, 1, 100);
      break;
    case 4460:
      createBullet(1, 0, 50);
      createBullet(1, 1, 50);
      createItem(120, 4);
      break;
//------------------------------------------------------------------------------
    case 4800:
      g_spriteItem.alive = false;
      createBullet(1, 0, 110);
      break;
    case 4830:
      createBullet(1, 0, 100);
      break;
    case 4860:
      createBullet(1, 0, 90);
      break;
    case 4900:
      createBullet(0, 0, 55);
      break;
//------------------------------------------------------------------------------
    case 5100:
      createItem(10, 140);
      createBullet(1, 0, 100);
      break;
    case 5300:
      createBullet(0, 0, 25);
      createBullet(0, 0, 130);
      break;
    case 5332:
      createBullet(0, 0, 25);
      break;
//------------------------------------------------------------------------------
    case 5600:
      g_spriteItem.alive = false;
      createBullet(0, 1, 110);
      createBullet(1, 1, 110);
      break;
    case 5700:
      createBullet(0, 1, 80);
      createBullet(1, 1, 80);
      break;
    case 5800:
      createBullet(0, 1, 50);
      createBullet(1, 1, 50);
      break;
//------------------------------------------------------------------------------
    case 6100:
      createBullet(0, 1, 25);
      break;
    case 6150:
      createBullet(1, 1, 100);
      break;
    case 6300:
      createBullet(0, 0, 30);
      break;
//------------------------------------------------------------------------------
    case 6600:
      createBullet(0, 1, 130);
      createBullet(1, 0, 130);
      break;
    case 6640:
      createBullet(0, 1, 130);
      createBullet(1, 0, 130);
      break;
    case 6680:
      createBullet(0, 1, 130);
      createBullet(1, 0, 130);
      break;
    case 6720:
      createBullet(0, 1, 130);
      createBullet(1, 0, 130);
      break;
//------------------------------------------------------------------------------
    case 7000:
      createBullet(0, 1, 100);
      break;
    case 7040:
      createBullet(0, 1, 100);
      break;
    case 7080:
      createBullet(0, 1, 100);
      break;
    case 7120:
      createBullet(0, 1, 100);
      break;
    case 7200:
      createBullet(1, 0, 50);
      break;
    case 7240:
      createBullet(1, 0, 50);
      break;
    case 7280:
      createBullet(1, 0, 50);
      break;
    case 7320:
      createItem(234, 20);
      createBullet(1, 0, 50);
      break;
//------------------------------------------------------------------------------
    case 7600:
      g_spriteItem.alive = false;
      createBullet(0, 0, 100);
      createBullet(0, 0, 80);
      createBullet(1, 1, 100);
      createBullet(1, 1, 80);
      break;
//------------------------------------------------------------------------------
    case 7900:
      createItem(124, 10);
      createBullet(0, 1, 80);
      createBullet(0, 1, 120);
      createBullet(0, 0, 100);
      break;
//------------------------------------------------------------------------------
    case 8150:
      g_spriteItem.alive = false;
      break;
    case 8200:
      createItem(228, 140);
      createBullet(0, 0, 130);
      break;
    case 8240:
      createBullet(0, 0, 130);
      break;
    case 8280:
      createBullet(0, 0, 130);
      break;
    case 8320:
      createBullet(0, 0, 130);
      break;
    case 8400:
      g_spriteItem.alive = false;
      break;
//------------------------------------------------------------------------------
    case 8600:
      createBullet(0, 1, 100);
      break;
    case 8680:
      createBullet(0, 1, 70);
      break;
    case 8720:
      createBullet(1, 0, 40);
      createBullet(1, 1, 40);
      break;
    case 8760:
      createBullet(1, 0, 40);
      createBullet(1, 1, 40);
      createItem(40, 30);
      break;
//------------------------------------------------------------------------------
    case 9100:
      g_spriteItem.alive = false;
      createBullet(0, 1, 100);
      break;
    case 9170:
      createBullet(0, 1, 70);
      break;
    case 9240:
      createBullet(0, 1, 40);
      break;
    case 9310:
      createBullet(1, 1, 40);
      break;
    case 9380:
      createBullet(1, 1, 40);
      break;
    case 9450:
      createBullet(1, 1, 40);
      break;
    case 9520:
      createBullet(0, 1, 40);
      break;
    case 9590:
      createBullet(0, 1, 40);
      break;
    case 9660:
      createBullet(0, 1, 40);
      break;
    case 9750:
      createItem(234, 30);
      break;
//------------------------------------------------------------------------------
    case 10000:
      g_spriteItem.alive = false;
      createBullet(0, 1, 80);
      break;
    case 10100:
      createBullet(1, 1, 80);
      createBullet(1, 1, 60);
      createBullet(1, 1, 40);
      createBullet(1, 1, 20);
      break;
    case 10200:
      createBullet(0, 1, 100);
      break;
    case 10300:
      createItem(30, 30);
      break;
//------------------------------------------------------------------------------
    case 10600:
      g_spriteItem.alive = false;
      createBullet(0, 0, 100);
      break;
    case 10640:
      createBullet(0, 0, 80);
      break;
    case 10680:
      createBullet(0, 0, 60);
      break;
    case 10720:
      createItem(124, 10);
      createBullet(0, 0, 40);
      break;
    case 10780:
      createBullet(1, 0, 40);
      break;
    case 10820:
      createBullet(1, 0, 60);
      break;
    case 10860:
      createBullet(1, 0, 80);
      break;
    case 10900:
      g_spriteItem.alive = false;
      createBullet(1, 0, 100);
      break;
//------------------------------------------------------------------------------
    case 11300:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11350:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11400:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11450:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11500:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11550:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11600:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11650:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11700:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11750:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11800:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11850:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11900:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 11950:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12000:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12050:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12100:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12150:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12200:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12250:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12300:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12350:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12400:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12450:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12500:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12550:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12600:
      createBullet(0, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
    case 12650:
      createBullet(1, PA_RandMinMax(0, 1), PA_RandMinMax(40, 130));
      break;
//------------------------------------------------------------------------------
    case 12900:
      createItem(PA_RandMinMax(10, 230), PA_RandMinMax(60, 140));
      break;
    case 12960:
      g_spriteItem.alive = false;
      break;
//------------------------------------------------------------------------------
    default:
      break;
  }
}

// Main function
int main(void)
{
  T_GAME_STATE l_state = GAME_STATE_TITLE;
  u8 l_i = 0;
  
  // PAlib init
  PA_Init();
  PA_InitVBL();
  PA_InitSound();
  
  // Init text
  PA_InitText(0, 0);
  PA_InitCustomText(0, 0, fontSMB3);
  PA_InitText(1, 0);
  PA_InitCustomText(1, 0, fontSMB3);

  // Load the palettes for both screens (screen, palette_number, palette)
  PA_LoadSpritePal(0, 0, (void*)Ninji_Pal);
  PA_LoadSpritePal(1, 0, (void*)Ninji_Pal);
  
  // Enable alpha blending on top screen
  PA_EnableSpecialFx(1, SFX_ALPHA, 0, SFX_BG0 | SFX_BG1 | SFX_BG2 | SFX_BG3 | SFX_BD);
  
  while (1)
  {
    switch (l_state)
    {
//------------------------------------------------------------------------------
      case GAME_STATE_TITLE:
        // inits
        initGlobalVariables();
        initSprites();
        // load black & white backgrounds
        PA_LoadTiledBg(0, 3, bw0);
        PA_LoadTiledBg(1, 3, bw1);
        // print boring stuff
        PA_OutputSimpleText(1, 9, 11, "NINJI AND ZARBI");
        PA_OutputSimpleText(1, 25, 22, "BY MIA");
        PA_OutputSimpleText(0, 10, 11, "A: GAME");
        PA_OutputSimpleText(0, 10, 12, "B: PRACTICE");
        // Play sound
        PA_StopStream(0);
        PA_PlaySoundEx2(0, wind, (u32)wind_size, 127, 11025, 0, true, 0);
        // wait user start
        while (l_state == GAME_STATE_TITLE)
        {
          if (Pad.Newpress.A)
          {
            // Start the game
            PA_ClearTextBg(0);
            PA_ClearTextBg(1);
            // load backgrounds
            PA_LoadTiledBg(0, 3, bg0);
            PA_LoadTiledBg(0, 2, bg0_ground);
            PA_LoadTiledBg(1, 3, bg1);
            PA_LoadTiledBg(1, 2, bg1_ground);
            // Create arch sprite
            PA_CreateSprite(1, ARCH_SPRITE_NUMBER, (void*)arche_Sprite, OBJ_SIZE_64X64, 1, 0, 32, 112);
            // Create frame sprite
            PA_CreateSprite(0, FRAME_SPRITE_NUMBER, (void*)cadre_Sprite, OBJ_SIZE_16X16, 1, 0, 188, 5);
            // Create heart sprites
            for (l_i = 0; l_i < HEART_NB_MAX; ++l_i)
            {
              PA_CreateSprite(0, l_i + HEART_NB_START, (void*)heart0_Sprite, OBJ_SIZE_16X16, 1, 0, (l_i * 10) + 6, 6);
              PA_CreateSprite(1, l_i + HEART_NB_START, (void*)heart1_Sprite, OBJ_SIZE_16X16, 1, 0, (l_i * 10) + 6, 6);
            }
            // Create explosion sprites
            PA_CreateSprite(0, EXPLOSION_SPRITE_NUMBER, (void*)explosion_Sprite, OBJ_SIZE_64X64, 1, 0, -EXPLOSION_WIDTH, -EXPLOSION_WIDTH);
            PA_CreateSprite(1, EXPLOSION_SPRITE_NUMBER, (void*)explosion_Sprite, OBJ_SIZE_64X64, 1, 0, -EXPLOSION_WIDTH, -EXPLOSION_WIDTH);
            // Create Ninji
            PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
            // Create Zarbi
            PA_CreateSprite(1, NINJI_SPRITE_NUMBER, (void*)zarbi00_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
            // Idle animations
            PA_StartSpriteAnim(0, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
            PA_StartSpriteAnim(1, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
            // print info
            PA_OutputText(1, SCORE_X , 1, "%d", g_score);
            PA_OutputSimpleText(0, 24 , 1, "1 2 3 4");
            // Play music
            PA_StopStream(0);
            PA_PlaySoundEx(0, cherry, (u32)cherry_size, 127, 11025, 0);
            // go to actual game
            l_state = GAME_STATE_GAME;
            // Wait a frame, to cancel the button pressed
            PA_WaitForVBL();
          }
          else if (Pad.Newpress.B)
          {
            // Start practice
            PA_ClearTextBg(0);
            PA_ClearTextBg(1);
            // Create N&B arch sprite
            PA_CreateSprite(1, ARCH_SPRITE_NUMBER, (void*)archeNB_Sprite, OBJ_SIZE_64X64, 1, 0, 32, 112);
            // Create frame sprite
            PA_CreateSprite(0, FRAME_SPRITE_NUMBER, (void*)cadre_Sprite, OBJ_SIZE_16X16, 1, 0, 188, 5);
            // Create Ninji
            PA_CreateSprite(0, NINJI_SPRITE_NUMBER, (void*)ninji00_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
            // Create Zarbi
            PA_CreateSprite(1, NINJI_SPRITE_NUMBER, (void*)zarbi00_Sprite, OBJ_SIZE_64X32, 1, 0, g_spriteNinji.x >> 8, g_spriteNinji.y >> 8);
            // Idle animations
            PA_StartSpriteAnim(0, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
            PA_StartSpriteAnim(1, NINJI_SPRITE_NUMBER, 0, 1, NINJI_IDLE_ANIM_SPEED);
            // print info
            PA_OutputSimpleText(0, 24 , 1, "1 2 3 4");
            PA_OutputSimpleText(1, 1 , 1, "START TO QUIT");
            // Stop sound
            PA_StopStream(0);
            // go to practice
            l_state = GAME_STATE_PRACTICE;
            // Wait a frame, to cancel the button pressed
            PA_WaitForVBL();
          }
          else
          {
            PA_OutputText(0, 1, 1, "%02d:%02d", PA_RTC.Hour, PA_RTC.Minutes);
            PA_WaitForVBL();
          }
        }
        break;
//------------------------------------------------------------------------------
      case GAME_STATE_GAME: // game
        if ((g_frameCounter < 13050) &&
            (g_life[0] > 0) &&
            (g_life[1] > 0))
        {
          manageScript();
          manageItemAlpha();
          moveNinji();
          moveShurikens();
          moveBullets();
          checkCollisionsShurikensBullet();
          checkCollisionsNinjiBullets();
          checkCollisionsZarbiItem();
          manageScore();
          PA_WaitForVBL();
        }
        else // end game
        {
          PA_ClearTextBg(0);
          PA_ClearTextBg(1);
          PA_DeleteSprite(1, ARCH_SPRITE_NUMBER);
          PA_DeleteSprite(0, FRAME_SPRITE_NUMBER);
          for (l_i = 0; l_i < HEART_NB_MAX; ++l_i)
          {
            PA_DeleteSprite(0, l_i + HEART_NB_START);
            PA_DeleteSprite(1, l_i + HEART_NB_START);
          }
          PA_StopSpriteAnim(0, EXPLOSION_SPRITE_NUMBER);
          PA_StopSpriteAnim(1, EXPLOSION_SPRITE_NUMBER);
          PA_DeleteSprite(0, EXPLOSION_SPRITE_NUMBER);
          PA_DeleteSprite(1, EXPLOSION_SPRITE_NUMBER);
          PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
          PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
          PA_DeleteSprite(0, NINJI_SPRITE_NUMBER);
          PA_DeleteSprite(1, NINJI_SPRITE_NUMBER);
          // Delete all remaining bullets
          for (l_i = 0; l_i < BULLET_NB_MAX; ++l_i)
          {
            if (g_bullets[0][l_i].state != BULLET_STATE_INACTIVE)
              PA_DeleteSprite(0, l_i + BULLET_NB_START);
            if (g_bullets[1][l_i].state != BULLET_STATE_INACTIVE)
            PA_DeleteSprite(1, l_i + BULLET_NB_START);
          }
          // Delete all remaining shurikens
          for (l_i = 0; l_i < SHURIKEN_NB_MAX; ++l_i)
          {
            if (g_shurikens[l_i].created)
              PA_DeleteSprite(0, l_i + SHURIKEN_NB_START);
          }
          // Delete remaining item
          if (g_spriteItem.created)
            PA_DeleteSprite(1, ITEM_SPRITE_NUMBER);
          PA_DeleteBg (0, 2);
          PA_DeleteBg (0, 3);
          PA_DeleteBg (1, 2);
          PA_DeleteBg (1, 3);
          PA_StopStream(0);
          l_state = GAME_STATE_GAME_OVER;
        }
        break;
//------------------------------------------------------------------------------
      case GAME_STATE_PRACTICE: // practice
        PA_OutputText(0, 1, 1, "%02d:%02d", PA_RTC.Hour, PA_RTC.Minutes);
        moveNinji();
        moveShurikens();
        if (Pad.Newpress.Start)
        {
          PA_ClearTextBg(0);
          PA_ClearTextBg(1);
          PA_DeleteSprite(0, FRAME_SPRITE_NUMBER);
          PA_StopSpriteAnim(0, NINJI_SPRITE_NUMBER);
          PA_StopSpriteAnim(1, NINJI_SPRITE_NUMBER);
          PA_DeleteSprite(0, NINJI_SPRITE_NUMBER);
          PA_DeleteSprite(1, NINJI_SPRITE_NUMBER);
          PA_DeleteSprite(1, ARCH_SPRITE_NUMBER);
          PA_DeleteBg (0, 3);
          PA_DeleteBg (1, 3);
          l_state = GAME_STATE_TITLE;
        }
        PA_WaitForVBL();
        break;
//------------------------------------------------------------------------------
      case GAME_STATE_GAME_OVER: // game over screen
        PA_LoadTiledBg(0, 3, bw0);
        PA_LoadTiledBg(1, 3, bw1);
        // print score
        PA_OutputSimpleText(1, 12, 11, "GAME OVER");
        PA_OutputText(0, 9, 9, "SCORE: %d", g_score);
        PA_OutputText(0, 9, 11, "BULLETS: %d/%d", g_bulletsKilled, g_bulletsTotal);
        PA_OutputText(0, 9, 12, "DS: %d/%d", g_DSGot, g_DSTotal);
        while (!Pad.Newpress.A)
          PA_WaitForVBL();
        PA_WaitForVBL();
        PA_DeleteBg (0, 3);
        PA_DeleteBg (1, 3);
        PA_ClearTextBg(0);
        PA_ClearTextBg(1);
        l_state = GAME_STATE_TITLE;
        break;
//------------------------------------------------------------------------------
      default:
        break;
    }
  }
  
  return 0;
}
