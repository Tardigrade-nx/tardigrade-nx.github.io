//Gfx converted using Mollusk's PAGfx Converter

//This file contains all the .c, for easier inclusion in a project

#ifdef __cplusplus
extern "C" {
#endif


// Sprite files : 
#include "ninji00.c"
#include "zarbi00.c"
#include "ninji00_sword.c"
#include "ninji00_nunchak.c"
#include "ninji00_shuriken.c"
#include "shuriken.c"
#include "bulletLeft.c"
#include "bulletRight.c"
#include "explosion.c"
#include "arche.c"
#include "archeNB.c"
#include "heart0.c"
#include "heart1.c"
#include "DS.c"
#include "cadre.c"

// Background files : 
#include "bg0.c"
#include "bg1.c"
#include "bg0_ground.c"
#include "bg1_ground.c"
#include "bw0.c"
#include "bw1.c"
#include "fontSMB3.c"

// Palette files : 
#include "Ninji.pal.c"
#include "bg0.pal.c"
#include "bg1.pal.c"
#include "bg0_ground.pal.c"
#include "bg1_ground.pal.c"
#include "bw0.pal.c"
#include "bw1.pal.c"
#include "fontSMB3.pal.c"


#ifdef __cplusplus
}
#endif

