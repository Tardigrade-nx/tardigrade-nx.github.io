//Palette created using Mollusk's PAGfxConverter

const unsigned short fontSMB3_Pal[3] __attribute__ ((aligned (4))) = {
64543, 32768, 65535};
