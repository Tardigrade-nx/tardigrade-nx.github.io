//Gfx converted using Mollusk's PAGfx Converter

//This file contains all the .h, for easier inclusion in a project

#ifndef ALL_GFX_H
#define ALL_GFX_H


// Sprite files : 
extern const unsigned char ninji00_Sprite[36864] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char zarbi00_Sprite[26624] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char ninji00_sword_Sprite[40960] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char ninji00_nunchak_Sprite[40960] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char ninji00_shuriken_Sprite[36864] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char shuriken_Sprite[256] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char bulletLeft_Sprite[1024] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char bulletRight_Sprite[1024] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char explosion_Sprite[24576] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char arche_Sprite[4096] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char archeNB_Sprite[4096] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char heart0_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char heart1_Sprite[512] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char DS_Sprite[256] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal
extern const unsigned char cadre_Sprite[256] __attribute__ ((aligned (4))) ;  // Pal : Ninji_Pal

// Background files : 
extern const int bg0_Info[3]; // BgMode, Width, Height
extern const unsigned short bg0_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bg0_Pal
extern const unsigned char bg0_Tiles[49088] __attribute__ ((aligned (4))) ;  // Pal : bg0_Pal

extern const int bg1_Info[3]; // BgMode, Width, Height
extern const unsigned short bg1_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bg1_Pal
extern const unsigned char bg1_Tiles[48960] __attribute__ ((aligned (4))) ;  // Pal : bg1_Pal

extern const int bg0_ground_Info[3]; // BgMode, Width, Height
extern const unsigned short bg0_ground_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bg0_ground_Pal
extern const unsigned char bg0_ground_Tiles[8256] __attribute__ ((aligned (4))) ;  // Pal : bg0_ground_Pal

extern const int bg1_ground_Info[3]; // BgMode, Width, Height
extern const unsigned short bg1_ground_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bg1_ground_Pal
extern const unsigned char bg1_ground_Tiles[12480] __attribute__ ((aligned (4))) ;  // Pal : bg1_ground_Pal

extern const int bw0_Info[3]; // BgMode, Width, Height
extern const unsigned short bw0_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bw0_Pal
extern const unsigned char bw0_Tiles[46016] __attribute__ ((aligned (4))) ;  // Pal : bw0_Pal

extern const int bw1_Info[3]; // BgMode, Width, Height
extern const unsigned short bw1_Map[768] __attribute__ ((aligned (4))) ;  // Pal : bw1_Pal
extern const unsigned char bw1_Tiles[47040] __attribute__ ((aligned (4))) ;  // Pal : bw1_Pal

extern const int fontSMB3_Info[3]; // BgMode, Width, Height
extern const unsigned short fontSMB3_Map[768] __attribute__ ((aligned (4))) ;  // Pal : fontSMB3_Pal
extern const unsigned char fontSMB3_Tiles[2560] __attribute__ ((aligned (4))) ;  // Pal : fontSMB3_Pal


// Palette files : 
extern const unsigned short Ninji_Pal[201] __attribute__ ((aligned (4))) ;
extern const unsigned short bg0_Pal[224] __attribute__ ((aligned (4))) ;
extern const unsigned short bg1_Pal[226] __attribute__ ((aligned (4))) ;
extern const unsigned short bg0_ground_Pal[161] __attribute__ ((aligned (4))) ;
extern const unsigned short bg1_ground_Pal[106] __attribute__ ((aligned (4))) ;
extern const unsigned short bw0_Pal[32] __attribute__ ((aligned (4))) ;
extern const unsigned short bw1_Pal[32] __attribute__ ((aligned (4))) ;
extern const unsigned short fontSMB3_Pal[3] __attribute__ ((aligned (4))) ;


#endif

