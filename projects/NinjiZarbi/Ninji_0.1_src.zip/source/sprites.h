#ifndef _SPRITES_H_
#define _SPRITES_H_

#include <PA9.h>

#define GRAVITY 32

#define NINJI_SPRITE_NUMBER 64
#define NINJI_GROUND_Y 128
#define NINJI_OFFSET_X 22
#define NINJI_WIDTH 64
#define NINJI_HEIGHT 32
#define NINJI_JUMP 1152
#define NINJI_KILL_JUMP 512
#define NINJI_KILL_SJUMP 1024
#define NINJI_ADJUST_JUMP 16
#define NINJI_JUMP_MIN_CHARGE 2
#define NINJI_JUMP_MAX_CHARGE 12
#define NINJI_IDLE_ANIM_SPEED 2
#define NINJI_WALK_ANIM_SPEED 14
#define NINJI_WALK_SPEED 384
#define NINJI_PRE_ATTACK_DURATION 3
#define NINJI_ATTACK_DURATION 10
#define NINJI_SPIN_NUNCHAK_SPEED 4
#define NINJI_DAMAGE_VX 128
#define NINJI_DAMAGE_VY 512

#define NINJI_COLLISION_X_GAP 22
#define NINJI_COLLISION_TOP_GAP 13
#define NINJI_SWORD_COLLISION_FRONT_GAP 6
#define NINJI_SWORD_COLLISION_TOP_GAP 7
#define NINJI_JUMP_SWORD_COLLISION_FRONT_GAP 15
#define NINJI_JUMP_SWORD_COLLISION_TOP_GAP 7
#define NINJI_NUNCHAK_COLLISION_FRONT_GAP 0
#define NINJI_NUNCHAK_COLLISION_TOP_GAP 20
#define NINJI_NUNCHAK_SPIN_COLLISION_FRONT_GAP 8
#define NINJI_PUNCH_COLLISION_FRONT_GAP 18
#define NINJI_PUNCH_COLLISION_TOP_GAP 14
#define NINJI_KICK_COLLISION_FRONT_GAP 19
#define NINJI_KICK_COLLISION_TOP_GAP 13

#define BULLET_NB_START 20
#define BULLET_NB_MAX 4
#define BULLET_WIDTH 32
#define BULLET_HEIGHT 32
#define BULLET_COLLISION_X_GAP 2
#define BULLET_COLLISION_TOP_GAP 8
#define BULLET_COLLISION_BOTTOM_GAP 9
#define BULLET_SPEED 256
#define BULLET_ROTSET_START 2
#define BULLET_KILL_JUMP 512
#define BULLET_ROTATION_SPEED 12

#define SHURIKEN_NB_START 10
#define SHURIKEN_NB_MAX 6
#define SHURIKEN_SPEED 640
#define SHURIKEN_ROTATION_SPEED 12
#define SHURIKEN_WIDTH 16
#define SHURIKEN_COLLISION_X_GAP 10
#define SHURIKEN_COLLISION_Y_GAP 2

#define EXPLOSION_SPRITE_NUMBER 19
#define EXPLOSION_WIDTH 64
#define EXPLOSION_ANIM_SPEED 10
#define EXPLOSION_DURATION 36

#define ARCH_SPRITE_NUMBER 0

#define ITEM_SPRITE_NUMBER 30
#define ITEM_WIDTH 16

#define HEART_NB_START 1
#define HEART_NB_MAX 5

#define NB_NINJI_STATES 11
#define NB_NINJI_WEAPONS 4

#define NB_POINTS_BULLET_STOMP 100
#define NB_POINTS_BULLET_SHURIKEN 70
#define NB_POINTS_BULLET_SLASHED 80
#define NB_POINTS_ITEM_GOT 130

#define SCORE_X 30

#define FRAME_SPRITE_NUMBER 9

//------------------------------------------------------------------------------

// Game states

typedef enum
{
  GAME_STATE_TITLE,
  GAME_STATE_GAME,
  GAME_STATE_PRACTICE,
  GAME_STATE_GAME_OVER
}
T_GAME_STATE;

//------------------------------------------------------------------------------

// Ninji states
typedef enum
{
  NINJI_STATE_IDLE,
  NINJI_STATE_WALK_RIGHT,
  NINJI_STATE_WALK_LEFT,
  NINJI_STATE_PRE_JUMP,
  NINJI_STATE_JUMP,
  NINJI_STATE_PUNCH,
  NINJI_STATE_KICK,
  NINJI_STATE_JUMP_PUNCH,
  NINJI_STATE_JUMP_KICK,
  NINJI_STATE_DAMAGE,
  NINJI_STATE_SPIN_NUNCHAK
}
T_NINJI_STATE;

// Ninji weapons
typedef enum
{
  NINJI_WEAPON_NONE,
  NINJI_WEAPON_SWORD,
  NINJI_WEAPON_NUNCHAK,
  NINJI_WEAPON_SHURIKEN
}
T_NINJI_WEAPON;

// Ninji sprite info
struct spriteNinji
{
  s32 x; // x coordinate
  s32 y; // y coordinate
  s32 vx; // horizontal speed
  s32 vy; // vertical speed
  u8 jumpCharge; // jump charge
  u8 attackTimer; // timer used for attack animations
  T_NINJI_STATE state; // current state
  T_NINJI_WEAPON weapon; // current weapon
} g_spriteNinji;

//------------------------------------------------------------------------------

// Bullet states
typedef enum
{
  BULLET_STATE_INACTIVE,
  BULLET_STATE_ALIVE,
  BULLET_STATE_DEAD,
  BULLET_STATE_SLASHED
}
T_BULLET_STATE;

// bullet sprite
typedef struct
{
  s32 x; // x coordinate
  s32 y; // y coordinate
  s32 vx; // horizontal speed
  s32 vy; // vertical speed
  T_BULLET_STATE state;
  u16 angle;
} T_BULLET_SPRITE; 

// bullets
T_BULLET_SPRITE g_bullets[2][BULLET_NB_MAX];

//------------------------------------------------------------------------------

// shuriken sprite
typedef struct
{
  s32 x; // x coordinate
  s32 y; // y coordinate
  s32 vx; // horizontal speed
  bool created;
} T_SHURIKEN_SPRITE; 

// shurikens
T_SHURIKEN_SPRITE g_shurikens[SHURIKEN_NB_MAX];

//------------------------------------------------------------------------------

// Ninji collision info
typedef struct
{
  u8 frontGap;
  u8 backGap;
  u8 topGap;
} T_NINJI_COLLISION_INFO; 

T_NINJI_COLLISION_INFO g_collisionGap[NB_NINJI_STATES][NB_NINJI_WEAPONS];

//------------------------------------------------------------------------------

// Item sprite info
struct spriteItem
{
  s16 x; // x coordinate
  s16 y; // y coordinate
  bool created;
  bool alive;
  s16 alpha;
} g_spriteItem;

//------------------------------------------------------------------------------

// init sprites
void initSprites(void);

#endif
