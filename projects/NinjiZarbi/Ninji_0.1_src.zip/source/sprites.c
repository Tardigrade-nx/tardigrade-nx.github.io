#include "sprites.h"

// init sprites
void initSprites(void)
{
  u8 l_i = 0;
  u8 l_j = 0;
  
  // init Ninji
  g_spriteNinji.x = 96 << 8;
  g_spriteNinji.y = NINJI_GROUND_Y << 8;
  g_spriteNinji.vx = 0;
  g_spriteNinji.vy = 0;
  g_spriteNinji.jumpCharge = 0;
  g_spriteNinji.attackTimer = 0;
  g_spriteNinji.state = NINJI_STATE_IDLE;
  g_spriteNinji.weapon = NINJI_WEAPON_NONE;
  
  // init bullets
  for (l_i = 0; l_i < 2; ++l_i)
  {
    for (l_j = 0; l_j < BULLET_NB_MAX; ++l_j)
    {
      g_bullets[l_i][l_j].x = 0;
      g_bullets[l_i][l_j].y = 0;
      g_bullets[l_i][l_j].vx = 0;
      g_bullets[l_i][l_j].vy = 0;
      g_bullets[l_i][l_j].state = BULLET_STATE_INACTIVE;
      g_bullets[l_i][l_j].angle = 0;
    }
  }
  
  // init Shurikens
  for (l_i = 0; l_i < SHURIKEN_NB_MAX; ++l_i)
  {
    g_shurikens[l_i].x = 0;
    g_shurikens[l_i].y = 0;
    g_shurikens[l_i].vx = 0;
    g_shurikens[l_i].created = false;
  }
  
  // init Item
  g_spriteItem.x = 0;
  g_spriteItem.y = 0;
  g_spriteItem.created = false;
  g_spriteItem.alive = false;
  g_spriteItem.alpha = 0;
  
  // init Ninji collision info
  for (l_i = 0; l_i < NB_NINJI_STATES; ++l_i)
  {
    for (l_j = 0; l_j < NB_NINJI_WEAPONS; ++l_j)
    {
      g_collisionGap[l_i][l_j].frontGap = NINJI_COLLISION_X_GAP;
      g_collisionGap[l_i][l_j].backGap = NINJI_COLLISION_X_GAP;
      g_collisionGap[l_i][l_j].topGap = NINJI_COLLISION_TOP_GAP;
    }
  }
  // Collision when state = punch
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_NONE].frontGap = NINJI_PUNCH_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_NONE].topGap = NINJI_PUNCH_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_SWORD].frontGap = NINJI_SWORD_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_SWORD].topGap = NINJI_SWORD_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_NUNCHAK].frontGap = NINJI_NUNCHAK_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_NUNCHAK].topGap = NINJI_NUNCHAK_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_SHURIKEN].frontGap = NINJI_PUNCH_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_PUNCH][NINJI_WEAPON_SHURIKEN].topGap = NINJI_PUNCH_COLLISION_TOP_GAP;
  // Collision when state = kick
  for (l_j = 0; l_j < NB_NINJI_WEAPONS; ++l_j)
  {
    g_collisionGap[NINJI_STATE_KICK][l_j].frontGap = NINJI_KICK_COLLISION_FRONT_GAP;
    g_collisionGap[NINJI_STATE_KICK][l_j].topGap = NINJI_KICK_COLLISION_TOP_GAP;
  }
  // Collision when state = jump punch
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_NONE].frontGap = NINJI_PUNCH_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_NONE].topGap = NINJI_PUNCH_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_SWORD].frontGap = NINJI_JUMP_SWORD_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_SWORD].topGap = NINJI_JUMP_SWORD_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_NUNCHAK].frontGap = NINJI_NUNCHAK_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_NUNCHAK].topGap = NINJI_NUNCHAK_COLLISION_TOP_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_SHURIKEN].frontGap = NINJI_PUNCH_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_JUMP_PUNCH][NINJI_WEAPON_SHURIKEN].topGap = NINJI_PUNCH_COLLISION_TOP_GAP;
  // Collision when state = jump kick
  for (l_j = 0; l_j < NB_NINJI_WEAPONS; ++l_j)
  {
    g_collisionGap[NINJI_STATE_JUMP_KICK][l_j].frontGap = NINJI_KICK_COLLISION_FRONT_GAP;
    g_collisionGap[NINJI_STATE_JUMP_KICK][l_j].topGap = NINJI_KICK_COLLISION_TOP_GAP;
  }
  // Collision when state = spin nunchak
  g_collisionGap[NINJI_STATE_SPIN_NUNCHAK][NINJI_WEAPON_NUNCHAK].frontGap = NINJI_NUNCHAK_SPIN_COLLISION_FRONT_GAP;
  g_collisionGap[NINJI_STATE_SPIN_NUNCHAK][NINJI_WEAPON_NONE].topGap = NINJI_NUNCHAK_COLLISION_TOP_GAP;
}
