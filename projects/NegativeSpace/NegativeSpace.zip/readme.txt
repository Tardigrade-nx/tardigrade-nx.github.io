Negative Space v1.0
-------------------

Homepage: http://beyondds.free.fr


Presentation
------------

Negative Space is a homebrew puzzle/platform game for the NDS, based on the 
concept of negative space.

The whole game contains only two colors: black and white. The player controls 
two 'blob' characters: the white blob moves in the black space, and the black 
blob in the white space. That's why, empty space for one blob represents solid 
ground and walls for the other.

The aim of the game is for each blob to capture its corresponding flag.
In order to do so, the player can draw directly on the touch screen in black or 
white and thus modify the levels and create new paths and platforms. But keep 
in mind that a new path for one blob means new walls for the other!


Moving the blobs
----------------

One blob is controlled at a time. The blob currently under control is animated,
while the other one is sleeping.

Buttons:

- L or R: switch blob.
- Left/Right/Down, or Y/A/B for left-handed people: move/jump with the blob
  under control.
- Start: reset the current level.


Drawing
-------

The drawing color is the opposite of the blob currently under control. Thus, to
switch between black and white 'ink', just switch blob with L or R.

Drawing is limited:
There are two numbers displayed in the lower-right corner of the upper screen.
The first number indicates the remaining 'ink' for the current line. It
decreases while you're drawing, and when it reaches 0, the line is ended.
The second number represents the number of lines you have left. It is
decremented at each end of line.
These numbers are specific to each level.

Typically, you will have to draw new paths and platforms for the blobs. However, 
it is possible to push or even lift the inactive blob too, by drawing near or 
under it with the same color. Be careful though: if a blob is drowned in its 
own color, it will die.


Credits
-------

Design and development: Mia
Music: Tomasz Andrzej Nidecki
Original concept: Squidi
