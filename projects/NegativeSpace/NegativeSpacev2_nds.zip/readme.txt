Negative Space v2.0
-------------------

Homepage: http://beyondds.free.fr


What's new in version 2.0
--------------------------

- A decent GUI.
- Blob movements with the stylus and not with the d-pad.
- More levels, including a tutorial.
- Save feature (needs DLDI, see http://dldi.drunkencoders.com).
- Circular cursor.


Presentation
------------

Negative Space is a homebrew puzzle game for the NDS, based on the concept of
negative space.

The whole game contains only two colors: black and white.
There are two 'blob' characters: the white blob moves in the black space, and
the black blob in the white space. That's why, empty space for one blob
represents solid ground and walls for the other.

The aim of the game is for each blob to capture its designated flag.
To achieve this goal, the player draws directly on the touch screen in black or
white in order to modify the levels (i.e. create new paths and platforms), and
push the blobs. Keep in mind that a new path for one blob means new walls for
the other!
The blobs are moved by "pushing" or "lifting" them with their own color.


Controls
--------

- Stylus: draw.
- Up/down or Y/B: switch color.
- Start: restart the current level.


Drawing
-------

The remaining ink for each color is displayed on the corresponding gauge, on the
upper screen. The number of lines is limited as well, and represented by the
small icons between the two ink gauges.
The available quantity of ink and lines is specific to each level.


Saving
------

The auto-save feature uses the DLDI driver. That means you may have to patch the
game depending on your card.
Please refer to http://dldi.drunkencoders.com for more information.
It is however possible to play the game without the save feature.


Credits
-------

Design and development: Mia.
Library: PAlib
Music: Tomasz Andrzej Nidecki
Original concept: Squidi.
