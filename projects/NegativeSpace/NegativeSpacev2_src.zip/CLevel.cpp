#include "CLevel.h"

// Gfx
#include "gfx/upscreen.c"
#include "gfx/level01.c"
#include "gfx/level02.c"
#include "gfx/level03.c"
#include "gfx/level04.c"
#include "gfx/level05.c"
#include "gfx/level06.c"
#include "gfx/level07.c"
#include "gfx/level08.c"
#include "gfx/level09.c"
#include "gfx/level10.c"
#include "gfx/level11.c"
#include "gfx/level12.c"
#include "gfx/level13.c"
#include "gfx/level14.c"
#include "gfx/level15.c"
#include "gfx/level16.c"
#include "gfx/level17.c"
#include "gfx/level18.c"
#include "gfx/level19.c"
#include "gfx/level20.c"

// Backgrounds for levels
const unsigned char *l_levelBg[NB_LEVELS + 1] = {NULL, level01_Bitmap, level02_Bitmap, level03_Bitmap, level04_Bitmap, level05_Bitmap,
                                                       level06_Bitmap, level07_Bitmap, level08_Bitmap, level09_Bitmap, level10_Bitmap,
                                                       level11_Bitmap, level12_Bitmap, level13_Bitmap, level14_Bitmap, level15_Bitmap,
                                                       level16_Bitmap, level17_Bitmap, level18_Bitmap, level19_Bitmap, level20_Bitmap};

//==============================================================================

CLevel::CLevel(const u8 p_level, const CSave *p_save):
  m_level(0),
  m_blobBlack(COLOR_BLACK),
  m_blobWhite(COLOR_WHITE),
  m_flagBlack(COLOR_BLACK),
  m_flagWhite(COLOR_WHITE),
  m_capturedFlags(0),
  m_save(p_save)
{
  // Load level upscreen
  PA_LoadSimpleBg(1, 2, upscreen_Tiles, upscreen_Map, PA_GetPAGfxBgSize(upscreen_Info[1], upscreen_Info[2]), 0, 1);
  // Load level
  this->goToLevel(p_level);
}

//==============================================================================

CLevel::~CLevel(void)
{
}

//==============================================================================

void CLevel::update(void)
{
  if (Pad.Newpress.Start)
  {
    // Restart current level
    this->goToLevel(m_level);
  }
  #ifdef SELECT_LEVEL
  else if (Pad.Newpress.R)
  {
    if (m_level == NB_LEVELS) this->goToLevel(1);
    else this->goToLevel(m_level + 1);
  }
  else if (Pad.Newpress.L)
  {
    if (m_level == 1) this->goToLevel(NB_LEVELS);
    else this->goToLevel(m_level - 1);
  }
  #endif
  else
  {
    m_blobBlack.update();
    m_blobWhite.update();
    m_draw.update();
    // Check flags capture
    if (m_flagWhite.isCaptured(m_blobWhite))
    {
      m_flagWhite.hide();
      ++m_capturedFlags;
    }
    if (m_flagBlack.isCaptured(m_blobBlack))
    {
      m_flagBlack.hide();
      ++m_capturedFlags;
    }
    if (m_capturedFlags >= 2)
    {
      // Level beaten
      if (m_level == NB_LEVELS) this->goToLevel(1);
      else this->goToLevel(m_level + 1);
    }
  }
  #ifdef DEBUG
  PA_OutputText(1, 0, 2, "flags %d  ", m_capturedFlags);
  #endif
}

//==============================================================================

void CLevel::goToLevel(const u8 p_level)
{
  #ifdef ENABLE_TRANSITION
  // Transition out
  s8 l_i(0);
  for (; l_i <= TRANS_LENGTH; l_i += 2)
  {
    PA_BgTransDiag(0, TRANSITION_TYPE, 0, 1, l_i);
    PA_WaitForVBL();
  }
  #endif
  // Load level
  PA_Load8bitBitmap(0, l_levelBg[p_level]);
  // Reset blobs
  m_blobBlack.reset(p_level);
  m_blobWhite.reset(p_level);
  // Reset flags
  m_flagBlack.reset(p_level);
  m_flagWhite.reset(p_level);
  m_capturedFlags = 0;
  // Reset ink
  m_draw.reset(p_level);
  // Save new level if necessary
  if (p_level != m_level) m_save->saveLevel(p_level);
  // Print level number
  if (p_level == NB_LEVELS) PA_OutputSimpleText(1, 11, 10, "??");
  else PA_OutputText(1, 11, 10, "%02d", p_level);
  // Update current level number
  m_level = p_level;
  #ifdef ENABLE_TRANSITION
  // Transition in
  for (l_i = TRANS_LENGTH; l_i >= 0; l_i -= 2)
  {
    PA_BgTransDiag(0, TRANSITION_TYPE, 1, 0, l_i);
    PA_WaitForVBL();
  }
  #endif
}
