#ifndef DATA_H_
#define DATA_H_

#include <PA9.h>
#include "def.h"

// These functions provide constant game data.
namespace Data
{
//==============================================================================

  // Returns initial position of the blobs
  void getBlobPosition(const u8 p_level, const T_COLOR p_color, s32 &p_x, s32 &p_y);

  // Returns initial position of the flags
  void getFlagPosition(const u8 p_level, const T_COLOR p_color, s16 &p_x, s16 &p_y);

  // Returns initial quantity of ink
  void getInkQuantity(const u8 p_level, u32 &p_black, u32 &p_white, u8 &p_nbLines);

//==============================================================================
};

#endif
