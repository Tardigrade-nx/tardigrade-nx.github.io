#ifndef CMENU_H_
#define CMENU_H_

#include <PA9.h>
#include "def.h"

// This class manages the main menu.
class CMenu
{
//==============================================================================

  public:
  
  // Constructor
  CMenu(const u8 p_level);

  // Destructor
  virtual ~CMenu(void);

  // Play the menu.
  const T_MENU_CHOICE update(void) const;

//==============================================================================

  private:
  
  // Forbidden
  CMenu(void);
  CMenu(const CMenu &p_source);
  const CMenu &operator=(const CMenu &p_right);
  
//==============================================================================
};

#endif
