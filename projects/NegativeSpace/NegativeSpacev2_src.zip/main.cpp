#include <PA9.h>
#include "CMenu.h"
#include "CLevel.h"
#include "CSave.h"

// Gfx
#include "gfx/blacknwhite.pal.c"
#include "gfx/font.c"

#ifdef PLAY_MUSIC
// Sound
#include "misthunt.h"
#endif

int main(int argc, char ** argv)
{
  // General inits
  PA_Init();
  PA_InitVBL();
  #ifdef PLAY_MUSIC
  PA_InitSound();
  #endif

  // Init bitmap background
  PA_Init8bitBg(0, 3);
  // Load palette for sprites
  PA_LoadSpritePal(0, SPRITE_PALETTE_NB, (void *)blacknwhite_Pal);
  PA_LoadSpritePal(1, SPRITE_PALETTE_NB, (void *)blacknwhite_Pal);
  // Load palette for backgrounds
  PA_LoadBgPal(1, 2, (void*)blacknwhite_Pal);
  PA_Load8bitBgPal(0, (void *)blacknwhite_Pal);
  // Paint bottom screen in black to avoid seeing magenta during init
  {
    u16 *l_pos = &PA_DrawBg[0][0];
    *l_pos = (COLOR_BLACK_VALUE << 8) | COLOR_BLACK_VALUE;
    DC_FlushRange(l_pos, sizeof(u16));
    while (DMA_Active());
    DMA_Force(*l_pos, l_pos + 2, 24575, DMA_16NOW);
  }

  // Init text
  PA_InitText(1, 0);
  PA_InitText(0, 0);
  PA_InitCustomTextEx(1, 0, font_Tiles, font_Map, blacknwhite_Pal);
  PA_InitCustomTextEx(0, 0, font_Tiles, font_Map, blacknwhite_Pal);
  PA_SetTextTileCol(0, 9);
  
  // Get saved level if any
  CSave l_save;
  u8 l_startLevel(l_save.getSavedLevel());

  // Main menu
  {
    T_MENU_CHOICE l_menuChoice(MENU_NONE);
    CMenu l_menu(l_startLevel);
    while(l_menuChoice == MENU_NONE)
    {
      l_menuChoice = l_menu.update();
      PA_WaitForVBL();
    }
    if (l_menuChoice == MENU_NEWGAME || l_startLevel == 0) l_startLevel = 1;
  }

  #ifdef ENABLE_TRANSITION
  // Init transitions
  PA_InitBgTrans(0);
  PA_BgTransDiag(0, TRANSITION_TYPE, 0, 1, 0);
  #endif
  
  // Level object
  CLevel l_level(l_startLevel, &l_save);

  #ifdef PLAY_MUSIC
  // Start to play the music
  u16 l_nbFrames(0);
  PA_PlayMod(misthunt);
  #endif

  // Main loop
  while(1)
  {
    l_level.update();
    #ifdef PLAY_MUSIC
    // Loop music when it's finished
    ++l_nbFrames;
    if (l_nbFrames > MUSIC_DURATION)
    {
      l_nbFrames = 0;
      PA_PlayMod(misthunt);
    }
    #endif
    PA_WaitForVBL();
  }
  
  return 0;
}
