#include "CMenu.h"

// Gfx
#include "gfx/title.c"
#include "gfx/menu.c"
#include "gfx/titleNoSave.c"
#include "gfx/titleNoMusic.c"

//==============================================================================

CMenu::CMenu(const u8 p_level)
{
  // Load menu background
  PA_Load8bitBitmap(0, menu_Bitmap);
  // Load title screen depending on the save feature (p_level = 0 means no save)
  if (p_level)
  {
    // Load backgrounds
    PA_LoadSimpleBg(1, 2, title_Tiles, title_Map, PA_GetPAGfxBgSize(title_Info[1], title_Info[2]), 0, 1);
    // Print level number to resume
    PA_OutputText(0, 11, 20, "%02d", p_level);
  }
  else
  {
    // Save disabled
    PA_LoadSimpleBg(1, 2, titleNoSave_Tiles, titleNoSave_Map, PA_GetPAGfxBgSize(titleNoSave_Info[1], titleNoSave_Info[2]), 0, 1);
  }
}

//==============================================================================

CMenu::~CMenu(void)
{
  PA_ClearTextBg(0);
}

//==============================================================================

const T_MENU_CHOICE CMenu::update(void) const
{
  T_MENU_CHOICE l_return(MENU_NONE);
  // Check stylus
  if (Stylus.Newpress && Stylus.X >= 26 && Stylus.X <= 135)
  {
    if (Stylus.Y >= 121 && Stylus.Y <= 147)
      // 'New game' was clicked
      l_return = MENU_NEWGAME;
    else if (Stylus.Y >= 150 && Stylus.Y <= 176)
      // 'Resume' was clicked
      l_return = MENU_RESUME;
  }
  return l_return;
}
