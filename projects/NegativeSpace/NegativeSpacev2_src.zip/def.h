#ifndef DEF_H_
#define DEF_H_

//==============================================================================

// Code flags
//#define DEBUG
//#define SELECT_LEVEL
#define ENABLE_TRANSITION
#define PLAY_MUSIC

// Utils
#define ABS(X)            ((X) < 0 ? -(X) : X)
#define NORM_LEFT(X)      ((X) < 0 ? 0 : X)
#define NORM_LENGTH(L,DX) (p_x + DX <= 255 ? p_x - DX >= 0 ? L : L + p_x - DX : L - p_x + 255 - DX)
#define DMA_Active()      (REG_DMA3CNT & DMA_ON)

// Number of levels
#define NB_LEVELS 20
// Type of transition effect
#define TRANSITION_TYPE 0
// Ink used for one dot
#define INK_FOR_ONE_DOT 26
// Maximum quantity of ink in stock
#define INK_MAX 1024
// Ratio between ink value and ink meter
#define INK_RATIO 32
// Maximum number of lines
#define NB_LINES_MAX 14
// Gravity
#define GRAVITY 48
// Music duration (frames)
#define MUSIC_DURATION 15000

// Sprite palette number
#define SPRITE_PALETTE_NB 0
// Sprite numbers on upper screen
#define SPRITE_NB_ARROW 10
#define SPRITE_NB_INK_BLACK 15
#define SPRITE_NB_INK_BLACK_BG 16
#define SPRITE_NB_INK_WHITE 17
// Sprite numbers on bottom screen
#define SPRITE_NB_BLOB_BLACK 10
#define SPRITE_NB_BLOB_WHITE 11
#define SPRITE_NB_FLAG_BLACK 20
#define SPRITE_NB_FLAG_WHITE 21

// Blob parameters
#define BLOB_ANIM_SPEED_IDLE 5
#define BLOB_V_MAX_SPEED 768
#define BLOB_LAND 12
// Hit box
#define BLOB_HITBOX_X_RIGHT 15
#define BLOB_HITBOX_X_LEFT 0
#define BLOB_HITBOX_X_MIDDLE 8
#define BLOB_HITBOX_Y_TOP 5
#define BLOB_HITBOX_Y_BOTTOM 15
#define BLOB_HITBOX_Y_MIDDLE 9

// Flag parameters
#define FLAG_ANIM_SPEED 10

// External files
#define SAVE_FILE "NegativeSpace.sav"

//==============================================================================

// Color
typedef enum
{
  COLOR_BLACK = 0,
  COLOR_WHITE = 1
}
T_COLOR;

#define COLOR_BLACK_VALUE 1
#define COLOR_WHITE_VALUE 2

// Blob states
typedef enum
{
  BLOB_STATE_STAND = 0,
  BLOB_STATE_FALL,
  BLOB_STATE_LAND,
  BLOB_STATE_DEAD
}
T_BLOB_STATE;

// Menu choice
typedef enum
{
  MENU_NONE = 0,
  MENU_NEWGAME,
  MENU_RESUME
}
T_MENU_CHOICE;

//==============================================================================

#endif
