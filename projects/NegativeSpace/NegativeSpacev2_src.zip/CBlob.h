#ifndef CBLOB_H_
#define CBLOB_H_

#include <PA9.h>
#include "def.h"

class CBlob
{
//==============================================================================

  public:
  
  // Constructor
  CBlob(const T_COLOR p_color);

  // Destructor
  virtual ~CBlob(void);

  // Update sprite
  void update(void);
  
  // Set blob to its initial position
  void reset(const u8 p_level);

  // Get screen coordinates
  void getCoordinates(s16 &p_x, s16 &p_y) const;

//==============================================================================
  
  private:
  
  // Forbidden
  CBlob(void);
  CBlob(const CBlob &p_source);
  const CBlob &operator=(const CBlob &p_right);

  // Return true if given point is empty from the blob's point of view, false otherwise
  const bool pointIsFree(const s16 p_x, const s16 p_y) const;

  // Go to another state
  void goToState(const T_BLOB_STATE p_newState);

  // Adjust position depending on the collisions
  void adjustPosition(void);
  
  // Returns the number of hit points in the same color
  const u8 health(void) const;

  // Color of the blob
  T_COLOR m_colorIndex;
  u8 m_colorValue;

  // x and y coordinates
  s32 m_x;
  s32 m_y;

  // Vertical speed
  s32 m_vy;

  // State
  T_BLOB_STATE m_state;
  
  // Number of sprite
  u8 m_number;

  // Timer
  u8 m_timer;

//==============================================================================
};

#endif
