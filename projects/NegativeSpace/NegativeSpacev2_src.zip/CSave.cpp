#include "CSave.h"

#include <fat.h>

//==============================================================================

CSave::CSave(void):
  m_FATInit(false)
{
  // Init FAT
  m_FATInit = fatInitDefault();
  #ifdef DEBUG
  PA_OutputText(1, 0, 3, "save %d  ", m_FATInit);
  #endif
}

//==============================================================================

CSave::~CSave(void)
{
}

//==============================================================================

const u8 CSave::getSavedLevel(void) const
{
  u8 l_retVal(0);
  if (m_FATInit)
  {
    // Open save file if any
    FILE* l_file = fopen(SAVE_FILE, "rb");
    if (l_file != NULL)
    {
      // There is a save file => read it
      fread(&l_retVal, 1, 1, l_file);
      fclose(l_file);
    }
    else
    {
      // No save file, first game
      l_retVal = 1;
    }
  }
  return l_retVal;
}

//==============================================================================

void CSave::saveLevel(const u8 p_level) const
{
  if (m_FATInit)
  {
    // Open save file if any
    FILE* l_file = fopen(SAVE_FILE, "wb");
    if (l_file != NULL)
    {
      fwrite(&p_level, 1, 1, l_file);
      fclose(l_file);
    }
  }
}
