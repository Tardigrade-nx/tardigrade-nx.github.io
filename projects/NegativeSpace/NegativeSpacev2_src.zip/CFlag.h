#ifndef CFLAG_H_
#define CFLAG_H_

#include <PA9.h>
#include "def.h"
#include "CBlob.h"

class CFlag
{
//==============================================================================

  public:
  
  // Constructor
  CFlag(const T_COLOR p_color);

  // Destructor
  virtual ~CFlag(void);
  
  // Set position depending on the level
  void reset(const u8 p_level);

  // Returns whether or not the flag is captured by the given blob
  const bool isCaptured(const CBlob &p_blob) const;
  
  // Hide the flag
  void hide(void);
  
//==============================================================================

  private:

  // Forbidden
  CFlag(void);
  CFlag(const CFlag &p_source);
  const CFlag &operator=(const CFlag &p_right);

  // x and y coordinates
  s16 m_x;
  s16 m_y;
  
  // Sprite number
  u8 m_number;
  
  // Color
  T_COLOR m_colorIndex;
  
//==============================================================================
};

#endif
