#include "CFlag.h"
#include "Data.h"

// Gfx
#include "gfx/flagBlack.c"
#include "gfx/flagWhite.c"

//==============================================================================

CFlag::CFlag(const T_COLOR p_color) :
  m_x(0),
  m_y(0),
  m_number(SPRITE_NB_FLAG_BLACK),
  m_colorIndex(p_color)
{
  switch(p_color)
  {
    case COLOR_BLACK:
      PA_CreateSprite(0, m_number, (void *)flagBlack_Sprite, OBJ_SIZE_16X16, 1, SPRITE_PALETTE_NB, 256, 0);
      break;
    case COLOR_WHITE:
      m_number = SPRITE_NB_FLAG_WHITE;
      PA_CreateSprite(0, m_number, (void *)flagWhite_Sprite, OBJ_SIZE_16X16, 1, SPRITE_PALETTE_NB, 256, 0);
      break;
    default:
      break;
  }
  PA_StartSpriteAnim(0, m_number, 0, 4, FLAG_ANIM_SPEED);
  PA_SetSpritePrio(0, m_number, 1);
}

//==============================================================================

CFlag::~CFlag(void)
{
  PA_DeleteSprite(0, m_number);
}

//==============================================================================

void CFlag::reset(const u8 p_level)
{
  // Move the flag to its initial position
  Data::getFlagPosition(p_level, m_colorIndex, m_x, m_y);
  PA_SetSpriteXY(0, m_number, m_x, m_y);
}

//==============================================================================

const bool CFlag::isCaptured(const CBlob &p_blob) const
{
  s16 l_x(0);
  s16 l_y(0);
  p_blob.getCoordinates(l_x, l_y);
  return((PA_Distance(l_x, l_y, m_x, m_y) <= 100) && (m_x < 256));
}

//==============================================================================

void CFlag::hide(void)
{
  m_x = 256;
  m_y = 0;
  PA_SetSpriteXY(0, m_number, m_x, m_y);
}
