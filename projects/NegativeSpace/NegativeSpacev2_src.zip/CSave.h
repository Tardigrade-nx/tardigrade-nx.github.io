#ifndef CSAVE_H_
#define CSAVE_H_

#include <PA9.h>
#include "def.h"

// This class manages the save feature.
class CSave
{
//==============================================================================

  public:
  
  // Constructor
  CSave(void);

  // Destructor
  virtual ~CSave(void);
  
  // Returns saved level, 1 if none, 0 if not activated
  const u8 getSavedLevel(void) const;

  // Save level
  void saveLevel(const u8 p_level) const;

//==============================================================================

  private:
  
  // Forbidden
  CSave(const CSave &p_source);
  const CSave &operator=(const CSave &p_right);
  
  // Result of FAT init
  bool m_FATInit;

//==============================================================================
};

#endif
