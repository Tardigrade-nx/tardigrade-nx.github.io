#ifndef CLEVEL_H_
#define CLEVEL_H_

#include <PA9.h>
#include "def.h"
#include "CDraw.h"
#include "CBlob.h"
#include "CFlag.h"
#include "CSave.h"

// This class manages the current level.
class CLevel
{
//==============================================================================

  public:
  
  // Constructor
  CLevel(const u8 p_level, const CSave *p_save);

  // Destructor
  virtual ~CLevel(void);

  // Play the game
  void update(void);

  // Go to a given level
  void goToLevel(const u8 p_level);

//==============================================================================

  private:
  
  // Forbidden
  CLevel(void);
  CLevel(const CLevel &p_source);
  const CLevel &operator=(const CLevel &p_right);

  // Current level
  u8 m_level;

  // Draw object
  CDraw m_draw;
  
  // The two blobs
  CBlob m_blobBlack;
  CBlob m_blobWhite;
  
  // The two flags
  CFlag m_flagBlack;
  CFlag m_flagWhite;

  // Number of flags captured
  u8 m_capturedFlags;
  
  // Reference to save object
  const CSave *m_save;

//==============================================================================
};

#endif
