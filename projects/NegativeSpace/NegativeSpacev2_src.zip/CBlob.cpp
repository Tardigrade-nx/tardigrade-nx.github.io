#include "CBlob.h"
#include "Data.h"

// Gfx
#include "gfx/blobBlack.c"
#include "gfx/blobWhite.c"

//==============================================================================

CBlob::CBlob(const T_COLOR p_color) :
  m_colorIndex(p_color),
  m_colorValue(COLOR_BLACK_VALUE),
  m_x(0),
  m_y(0),
  m_vy(0),
  m_state(BLOB_STATE_FALL),
  m_number(SPRITE_NB_BLOB_BLACK),
  m_timer(0)
{
  // Init sprite depending on color
  switch(m_colorIndex)
  {
    case COLOR_BLACK:
      PA_CreateSprite(0, SPRITE_NB_BLOB_BLACK, (void *)blobBlack_Sprite, OBJ_SIZE_16X16, 1, SPRITE_PALETTE_NB, 256, 0);
      break;
    case COLOR_WHITE:
      m_colorValue = COLOR_WHITE_VALUE;
      m_number = SPRITE_NB_BLOB_WHITE;
      PA_CreateSprite(0, SPRITE_NB_BLOB_WHITE, (void *)blobWhite_Sprite, OBJ_SIZE_16X16, 1, SPRITE_PALETTE_NB, 256, 0);
      break;
    default: break;
  }
  PA_SetSpriteAnim(0, m_number, 2);
  PA_SetSpritePrio(0, m_number, 1);
}

//==============================================================================

CBlob::~CBlob(void)
{
  // Delete sprite
  switch(m_colorIndex)
  {
    case COLOR_BLACK: PA_DeleteSprite(0, SPRITE_NB_BLOB_BLACK); break;
    case COLOR_WHITE: PA_DeleteSprite(0, SPRITE_NB_BLOB_WHITE); break;
    default: break;
  }
}

//==============================================================================

const bool CBlob::pointIsFree(const s16 p_x, const s16 p_y) const
{
  // Point free = inside the screen, and of different color
  return ((p_x <= 255) && (p_x >= 0) && (p_y <= 191) && (p_y >= 0) && (PA_Get8bitPixel(0, p_x, p_y) != m_colorValue));
}

//==============================================================================

void CBlob::goToState(const T_BLOB_STATE p_newState)
{
  switch(p_newState)
  {
    case BLOB_STATE_STAND:
      PA_StartSpriteAnim(0, m_number, 0, 3, BLOB_ANIM_SPEED_IDLE);
      m_timer = 0;
      break;
    case BLOB_STATE_FALL:
      PA_StopSpriteAnim(0, m_number);
      PA_SetSpriteAnim(0, m_number, 2);
      m_timer = 0;
      break;
    case BLOB_STATE_LAND:
      PA_SetSpriteAnim(0, m_number, 8);
      m_timer = BLOB_LAND;
      break;
    case BLOB_STATE_DEAD:
      PA_StopSpriteAnim(0, m_number);
      PA_SetSpriteAnim(0, m_number, 9);
      m_timer = 0;
      break;
    default:
      break;
  }
  m_vy = 0;
  m_state = p_newState;
}

//==============================================================================

void CBlob::adjustPosition(void)
{
  // Bottom collision
  while((!pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_BOTTOM)) &&
        (pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_TOP - 1)))
    m_y = ((m_y >> 8) - 1) << 8;
  // Top collision
  while((!pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_TOP)) &&
        (pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_BOTTOM + 1)))
  {
    if (m_vy) m_vy = 0;
    m_y = ((m_y >> 8) + 1) << 8;
  }
  // Left collision
  while((!pointIsFree((m_x >> 8) + BLOB_HITBOX_X_LEFT, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE)) &&
        (pointIsFree((m_x >> 8) + BLOB_HITBOX_X_RIGHT + 1, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE)))
    m_x = ((m_x >> 8) + 1) << 8;
  // Right collision
  while((!pointIsFree((m_x >> 8) + BLOB_HITBOX_X_RIGHT, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE)) &&
        (pointIsFree((m_x >> 8) + BLOB_HITBOX_X_LEFT - 1, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE)))
    m_x = ((m_x >> 8) - 1) << 8;
}

//==============================================================================

void CBlob::update(void)
{
  // Update blob's coordinates
  if (m_state == BLOB_STATE_FALL)
  {
    m_vy += GRAVITY;
    if (m_vy > BLOB_V_MAX_SPEED) m_vy = BLOB_V_MAX_SPEED;
    m_y += m_vy;
  }
//------------------------------------------------------------------------------
  // Adjust position
  this->adjustPosition();
//------------------------------------------------------------------------------
  // Update blob's state
  switch (m_state)
  {
    case BLOB_STATE_STAND:
      // If the blob is the air
      if (pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_BOTTOM + 1)) goToState(BLOB_STATE_FALL);
      // Check health
      if (!this->health()) goToState(BLOB_STATE_DEAD);
      break;
    case BLOB_STATE_FALL:
      // If the blob is on the ground
      if (!pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_BOTTOM + 1))
      {
        if (m_vy == BLOB_V_MAX_SPEED) goToState(BLOB_STATE_LAND);
        else goToState(BLOB_STATE_STAND);
      }
      break;
    case BLOB_STATE_LAND:
      if (m_timer) --m_timer;
      if (!m_timer) goToState(BLOB_STATE_STAND);
      break;
    case BLOB_STATE_DEAD:
      if (this->health() >= 4) goToState(BLOB_STATE_FALL);
      break;
    default: break;
  }
//------------------------------------------------------------------------------
  // Move the sprite
  PA_SetSpriteXY(0, m_number, m_x >> 8, m_y >> 8);
//------------------------------------------------------------------------------
  // Debug
  #ifdef DEBUG
  PA_OutputText(1, 0, m_colorIndex, "blob %d  %d  %d  %d   ", m_colorIndex, m_state, this->health(), m_timer);
  #endif
}

//==============================================================================

void CBlob::reset(const u8 p_level)
{
  this->goToState(BLOB_STATE_FALL);
  Data::getBlobPosition(p_level, m_colorIndex, m_x, m_y);
  PA_SetSpriteXY(0, m_number, m_x >> 8, m_y >> 8);
}

//==============================================================================

void CBlob::getCoordinates(s16 &p_x, s16 &p_y) const
{
  p_x = m_x >> 8;
  p_y = m_y >> 8;
}

//==============================================================================

const u8 CBlob::health(void) const
{
    return this->pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_BOTTOM) +
         this->pointIsFree((m_x >> 8) + BLOB_HITBOX_X_MIDDLE, (m_y >> 8) + BLOB_HITBOX_Y_TOP) +
         this->pointIsFree((m_x >> 8) + BLOB_HITBOX_X_LEFT, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE) +
         this->pointIsFree((m_x >> 8) + BLOB_HITBOX_X_RIGHT, (m_y >> 8) + BLOB_HITBOX_Y_MIDDLE);
}
