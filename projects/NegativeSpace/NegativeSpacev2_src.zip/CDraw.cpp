#include "CDraw.h"
#include "Data.h"

// Gfx
#include "gfx/arrow.c"
#include "gfx/inkBlack.c"
#include "gfx/inkWhite.c"

//==============================================================================

CDraw::CDraw(void) :
  m_colorIndex(COLOR_BLACK),
  m_colorValue(COLOR_BLACK_VALUE),
  m_x(0),
  m_y(0),
  m_drawing(false),
  m_lines(0)
{
  m_ink[COLOR_BLACK] = INK_MAX;
  m_ink[COLOR_WHITE] = INK_MAX;
  // Arrow
  PA_CreateSprite(1, SPRITE_NB_ARROW, (void *)arrow_Sprite, OBJ_SIZE_16X16, 1, SPRITE_PALETTE_NB, 181, 128);
  // Ink
  PA_CreateSprite(1, SPRITE_NB_INK_BLACK, (void *)inkBlack_Sprite, OBJ_SIZE_16X32, 1, SPRITE_PALETTE_NB, 201, 112);
  PA_CreateSprite(1, SPRITE_NB_INK_WHITE, (void *)inkWhite_Sprite, OBJ_SIZE_16X32, 1, SPRITE_PALETTE_NB, 201, 34);
  PA_CloneSprite(1, SPRITE_NB_INK_BLACK_BG, SPRITE_NB_INK_WHITE);
  PA_SetSpriteY(1, SPRITE_NB_INK_BLACK_BG, 112);
  PA_SetSpritePrio(1, SPRITE_NB_INK_BLACK, 3);
  PA_SetSpritePrio(1, SPRITE_NB_INK_BLACK_BG, 3);
  PA_SetSpritePrio(1, SPRITE_NB_INK_WHITE, 3);
}

//==============================================================================

CDraw::~CDraw(void)
{
  // Delete sprites
  PA_DeleteSprite(1, SPRITE_NB_ARROW);
  PA_DeleteSprite(1, SPRITE_NB_INK_BLACK);
  PA_DeleteSprite(1, SPRITE_NB_INK_WHITE);
  PA_DeleteSprite(1, SPRITE_NB_INK_BLACK_BG);
}

//==============================================================================

void CDraw::update(void)
{
  if (m_drawing)
  {
    if (Stylus.Held && (m_x != Stylus.X || m_y != Stylus.Y))
    {
      // Draw line if the stylus has moved
      this->drawCustomLine(m_x, m_y, Stylus.X, Stylus.Y);
      // Update remaining ink level
      this->updateInkLevel(m_colorIndex);
      // Update last point
      m_x = Stylus.X;
      m_y = Stylus.Y;
    }
    else if (Stylus.Released)
    {
      this->endOfLine();
    }
  }
  else
  {
    // Check buttons
    if ((Pad.Newpress.Up || Pad.Newpress.X) && m_colorIndex == COLOR_BLACK)
    {
      // Switch to white
      m_colorIndex = COLOR_WHITE;
      m_colorValue = COLOR_WHITE_VALUE;
      PA_SetSpriteY(1, SPRITE_NB_ARROW, 50);
      PA_SetSpriteAnim(1, SPRITE_NB_ARROW, 1);
    }
    else if ((Pad.Newpress.Down || Pad.Newpress.B) && m_colorIndex == COLOR_WHITE)
    {
      // Switch to black
      m_colorIndex = COLOR_BLACK;
      m_colorValue = COLOR_BLACK_VALUE;
      PA_SetSpriteY(1, SPRITE_NB_ARROW, 128);
      PA_SetSpriteAnim(1, SPRITE_NB_ARROW, 0);
    }
    // Check stylus
    else if(Stylus.Newpress)
    {
      // First point of the stroke
      this->drawCustomDot();
      // Update remaining ink level
      this->updateInkLevel(m_colorIndex);
      // Update last point
      m_x = Stylus.X;
      m_y = Stylus.Y;
      // Arrow blink
      PA_StartSpriteAnim(1, SPRITE_NB_ARROW, 0, 1, 5);
      // Flag
      m_drawing = true;
    }
  }
}

//==============================================================================

void CDraw::drawCustomLine(s16 p_x0, s16 p_y0, s16 p_x1, s16 p_y1)
{
  // Bresenham's algorithm
  s16 l_x(0);
  s16 l_y(0);
  bool l_steep = ABS(p_y1 - p_y0) > ABS(p_x1 - p_x0);
  if(l_steep)
  {
    // Swap x0 / y0
    l_x = p_x0;
    p_x0 = p_y0;
    p_y0 = l_x;
    // Swap x1 / y1
    l_x = p_x1;
    p_x1 = p_y1;
    p_y1 = l_x;
  }
  if(p_x0 > p_x1)
  {
    // Swap x0 / x1
    l_x = p_x0;
    p_x0 = p_x1;
    p_x1 = l_x;
    // Swap y0 / y1
    l_y = p_y0;
    p_y0 = p_y1;
    p_y1 = l_y;
  }
  s16 l_deltax = p_x1 - p_x0;
  s16 l_deltay = ABS(p_y1 - p_y0);
  s16 l_error = l_deltax >> 8;
  s16 l_ystep(0);
  l_y = p_y0;
  if (p_y0 < p_y1) l_ystep = 1; else l_ystep = -1;
  for (l_x = p_x0; l_x <= p_x1; ++l_x)
  {
    if (m_ink[m_colorIndex])
    {
      if (l_steep) this->drawCursor(l_y, l_x); else this->drawCursor(l_x, l_y);
      --m_ink[m_colorIndex];
    }
    l_error = l_error - l_deltay;
    if(l_error < 0)
    {
      l_y = l_y + l_ystep;
      l_error = l_error + l_deltax;
    }
  }
}

//==============================================================================

void CDraw::drawCustomDot(void)
{
  // Draw a dot of ink
  if (m_ink[m_colorIndex] > 0)
  {
    this->drawCursor(Stylus.X, Stylus.Y);
    if (m_ink[m_colorIndex] > INK_FOR_ONE_DOT)
      m_ink[m_colorIndex] -= INK_FOR_ONE_DOT;
    else
      m_ink[m_colorIndex] = 0;
  }
}

//==============================================================================

void CDraw::drawCursor(const s16 &p_x, const s16 &p_y) const
{
  // Draw a filled circle
  if (p_y >= 8)   this->drawHorizLine(NORM_LEFT(p_x - 3), p_y - 8, NORM_LENGTH( 7, 3));
  if (p_y >= 7)   this->drawHorizLine(NORM_LEFT(p_x - 5), p_y - 7, NORM_LENGTH(11, 5));
  if (p_y >= 6)   this->drawHorizLine(NORM_LEFT(p_x - 6), p_y - 6, NORM_LENGTH(13, 6));
  if (p_y >= 5)   this->drawHorizLine(NORM_LEFT(p_x - 7), p_y - 5, NORM_LENGTH(15, 7));
  if (p_y >= 4)   this->drawHorizLine(NORM_LEFT(p_x - 7), p_y - 4, NORM_LENGTH(15, 7));
  if (p_y >= 3)   this->drawHorizLine(NORM_LEFT(p_x - 8), p_y - 3, NORM_LENGTH(17, 8));
  if (p_y >= 2)   this->drawHorizLine(NORM_LEFT(p_x - 8), p_y - 2, NORM_LENGTH(17, 8));
  if (p_y >= 1)   this->drawHorizLine(NORM_LEFT(p_x - 8), p_y - 1, NORM_LENGTH(17, 8));
                  this->drawHorizLine(NORM_LEFT(p_x - 8), p_y,     NORM_LENGTH(17, 8));
  if (p_y <= 190) this->drawHorizLine(NORM_LEFT(p_x - 8), p_y + 1, NORM_LENGTH(17, 8));
  if (p_y <= 189) this->drawHorizLine(NORM_LEFT(p_x - 8), p_y + 2, NORM_LENGTH(17, 8));
  if (p_y <= 188) this->drawHorizLine(NORM_LEFT(p_x - 8), p_y + 3, NORM_LENGTH(17, 8));
  if (p_y <= 187) this->drawHorizLine(NORM_LEFT(p_x - 7), p_y + 4, NORM_LENGTH(15, 7));
  if (p_y <= 186) this->drawHorizLine(NORM_LEFT(p_x - 7), p_y + 5, NORM_LENGTH(15, 7));
  if (p_y <= 185) this->drawHorizLine(NORM_LEFT(p_x - 6), p_y + 6, NORM_LENGTH(13, 6));
  if (p_y <= 184) this->drawHorizLine(NORM_LEFT(p_x - 5), p_y + 7, NORM_LENGTH(11, 5));
  if (p_y <= 183) this->drawHorizLine(NORM_LEFT(p_x - 3), p_y + 8, NORM_LENGTH( 7, 3));
}

//==============================================================================

void CDraw::reset(const u8 p_level)
{
  // Stop arrow blinking
  PA_StopSpriteAnim(1, SPRITE_NB_ARROW);
  PA_SetSpriteAnim(1, SPRITE_NB_ARROW, m_colorIndex);
  // Init ink level
  Data::getInkQuantity(p_level, m_ink[COLOR_BLACK], m_ink[COLOR_WHITE], m_lines);
  this->updateInkLevel(COLOR_BLACK);
  this->updateInkLevel(COLOR_WHITE);
  this->updateNumberOfLines();
  // Flag
  m_drawing = false;
}

//==============================================================================

void CDraw::updateInkLevel(const T_COLOR p_color) const
{
  switch(p_color)
  {
    case COLOR_BLACK: PA_SetSpriteY(1, SPRITE_NB_INK_BLACK, ((INK_MAX - m_ink[COLOR_BLACK]) / INK_RATIO) + 112); break;
    case COLOR_WHITE: PA_SetSpriteY(1, SPRITE_NB_INK_WHITE, ((INK_MAX - m_ink[COLOR_WHITE]) / INK_RATIO) + 34); break;
    default: break;
  }
}

//==============================================================================

void CDraw::updateNumberOfLines(void) const
{
  char l_string[NB_LINES_MAX + 1];
  l_string[NB_LINES_MAX] = '\0';
  memset(l_string, '#', NB_LINES_MAX);
  if (m_lines < NB_LINES_MAX) memset(l_string, ' ', NB_LINES_MAX - m_lines);
  PA_OutputSimpleText(1, 14, 11, l_string);
}

//==============================================================================

void CDraw::endOfLine(void)
{
  // Stop arrow blinking
  PA_StopSpriteAnim(1, SPRITE_NB_ARROW);
  PA_SetSpriteAnim(1, SPRITE_NB_ARROW, m_colorIndex);
  // Update number of lines
  if (m_lines)
  {
    --m_lines;
    if (!m_lines)
    {
      m_ink[COLOR_BLACK] = 0;
      m_ink[COLOR_WHITE] = 0;
      this->updateInkLevel(COLOR_BLACK);
      this->updateInkLevel(COLOR_WHITE);
    }
  }
  this->updateNumberOfLines();
  // Flag
  m_drawing = false;
}

//==============================================================================

void CDraw::drawHorizLine(const s16 &p_x, const s16 &p_y, u16 p_width) const
{
  u16 *l_pos = &PA_DrawBg[0][(p_y << 7) + (p_x >> 1)];
  if (p_x & 1)
  {
    // Draw the first pixel
    *l_pos &= 0xff;
    *l_pos |= m_colorValue << 8;
    // Set new start position and width
    l_pos++;
    --p_width;
  }
  if (p_width > 1)
  {
    // Draw 2 initial pixels
    *l_pos = m_colorValue | (m_colorValue << 8);
    if (p_width & 1)
    {
      u16 l_dmaWidth = (p_width - 3) >> 1;
      // Ensure DMA can see latest memory state
      DC_FlushRange(l_pos, sizeof(u16));
      // Wait until DMA channel is clear
      while (DMA_Active());
      // Duplicate pixels
      if (l_dmaWidth) DMA_Force(*l_pos, l_pos + 2, l_dmaWidth, DMA_16NOW);
      // Draw last pixel
      l_pos += l_dmaWidth + 1;
      *l_pos &= 0xff00;
      *l_pos |= m_colorValue;
    }
    else
    {
      u16 l_dmaWidth = (p_width - 2) >> 1;
      // Ensure DMA can see latest memory state
      DC_FlushRange(l_pos, sizeof(u16));
      // Wait until DMA channel is clear
      while (DMA_Active());
      // Duplicate pixels
      if (l_dmaWidth) DMA_Force(*l_pos, l_pos + 2, l_dmaWidth, DMA_16NOW);
    }
  }
  else if (p_width > 0)
  {
    // Draw the only pixel
    *l_pos &= 0xff00;
    *l_pos |= m_colorValue;
  }
}

