#ifndef CDRAW_H_
#define CDRAW_H_

#include <PA9.h>
#include "def.h"

// This class manages the drawing mechanics.
class CDraw
{
//==============================================================================

  public:
  
  // Constructor
  CDraw(void);

  // Destructor
  virtual ~CDraw(void);
  
  // Draw
  void update(void);

  // Set initial ink quantity
  void reset(const u8 p_level);

//==============================================================================
  
  private:
  
  // Forbidden
  CDraw(const CDraw &p_source);
  const CDraw &operator=(const CDraw &p_right);
  
  // Draw a custom line
  void drawCustomLine(s16 p_x0, s16 p_y0, s16 p_x1, s16 p_y1);
  
  // Same thing but for a simple dot
  void drawCustomDot(void);

  // Draw circle cursor
  void drawCursor(const s16 &p_x, const s16 &p_y) const;
  
  // Draw a horizontal line fast (using DMA)
  inline void drawHorizLine(const s16 &p_x, const s16 &p_y, u16 p_width) const;
  
  // Update ink level
  void updateInkLevel(const T_COLOR p_color) const;
  
  // Update number of lines
  void updateNumberOfLines(void) const;
  
  // Ends a line
  void endOfLine(void);
  
  // The current color used for drawing
  T_COLOR m_colorIndex;
  u8 m_colorValue;
  
  // Last point clicked
  s16 m_x;
  s16 m_y;
  
  // The remaining ink for each color
  u32 m_ink[2];
  
  // Flag that indicates drawing in progress
  bool m_drawing;
  
  // The remaining number of lines
  u8 m_lines;

//==============================================================================
};

#endif
