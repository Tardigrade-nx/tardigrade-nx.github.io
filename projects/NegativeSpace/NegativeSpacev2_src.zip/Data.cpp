#include "Data.h"

//==============================================================================

void Data::getBlobPosition(const u8 p_level, const T_COLOR p_color, s32 &p_x, s32 &p_y)
{
  switch (p_color)
  {
//------------------------------------------------------------------------------
    case COLOR_BLACK:
      switch (p_level)
      {
        case 1: p_x = 0; p_y = 192 << 8; break;
        case 2: p_x = 38 << 8; p_y = 90 << 8; break;
        case 3: p_x = 90 << 8; p_y = 70 << 8; break;
        case 4: p_x = 54 << 8; p_y = 37 << 8; break;
        case 5: p_x = 47 << 8; p_y = 135 << 8; break;
        case 6: p_x = 164 << 8; p_y = 91 << 8; break;
        case 7: p_x = 168 << 8; p_y = 141 << 8; break;
        case 8: p_x = 115 << 8; p_y = 125 << 8; break;
        case 9: p_x = 121 << 8; p_y = 6 << 8; break;
        case 10: p_x = 49 << 8; p_y = 102 << 8; break;
        case 11: p_x = 131 << 8; p_y = 161 << 8; break;
        case 12: p_x = 183 << 8; p_y = 19 << 8; break;
        case 13: p_x = 121 << 8; p_y = 153 << 8; break;
        case 14: p_x = 35 << 8; p_y = 28 << 8; break;
        case 15: p_x = 96 << 8; p_y = 67 << 8; break;
        case 16: p_x = 52 << 8; p_y = 45 << 8; break;
        case 17: p_x = 155 << 8; p_y = 100 << 8; break;
        case 18: p_x = 213 << 8; p_y = 136 << 8; break;
        case 19: p_x = 166 << 8; p_y = 145 << 8; break;
        case 20: p_x = 17 << 8; p_y = 176 << 8; break;
        default: p_x = 256 << 8; p_y = 0; break;
      }
      break;
//------------------------------------------------------------------------------
    case COLOR_WHITE:
      switch (p_level)
      {
        case 1: p_x = 110 << 8; p_y = 31 << 8; break;
        case 2: p_x = 0; p_y = 192 << 8; break;
        case 3: p_x = 68 << 8; p_y = 130 << 8; break;
        case 4: p_x = 53 << 8; p_y = 91 << 8; break;
        case 5: p_x = 16 << 8; p_y = 5 << 8; break;
        case 6: p_x = 75 << 8; p_y = 91 << 8; break;
        case 7: p_x = 133 << 8; p_y = 16 << 8; break;
        case 8: p_x = 108 << 8; p_y = 13 << 8; break;
        case 9: p_x = 180 << 8; p_y = 40 << 8; break;
        case 10: p_x = 178 << 8; p_y = 25 << 8; break;
        case 11: p_x = 131 << 8; p_y = 9 << 8; break;
        case 12: p_x = 47 << 8; p_y = 54 << 8; break;
        case 13: p_x = 121 << 8; p_y = 8 << 8; break;
        case 14: p_x = 210 << 8; p_y = 59 << 8; break;
        case 15: p_x = 120 << 8; p_y = 27 << 8; break;
        case 16: p_x = 128 << 8; p_y = 0 << 8; break;
        case 17: p_x = 204 << 8; p_y = 10 << 8; break;
        case 18: p_x = 63 << 8; p_y = 68 << 8; break;
        case 19: p_x = 75 << 8; p_y = 14 << 8; break;
        case 20: p_x = 75 << 8; p_y = 14 << 8; break;
        default: p_x = 256 << 8; p_y = 0; break;
      }
      break;
//------------------------------------------------------------------------------
    default:
      break;
  }
}

//==============================================================================

void Data::getFlagPosition(const u8 p_level, const T_COLOR p_color, s16 &p_x, s16 &p_y)
{
  switch (p_color)
  {
//------------------------------------------------------------------------------
    case COLOR_BLACK:
      switch (p_level)
      {
        case 1: p_x = 0; p_y = 192; break;
        case 2: p_x = 197; p_y = 51; break;
        case 3: p_x = 146; p_y = 156; break;
        case 4: p_x = 161; p_y = 51; break;
        case 5: p_x = 198; p_y = 135; break;
        case 6: p_x = 125; p_y = 168; break;
        case 7: p_x = 144; p_y = 141; break;
        case 8: p_x = 99; p_y = 47; break;
        case 9: p_x = 105; p_y = 176; break;
        case 10: p_x = 141; p_y = 85; break;
        case 11: p_x = 131; p_y = 53; break;
        case 12: p_x = 65; p_y = 156; break;
        case 13: p_x = 170; p_y = 105; break;
        case 14: p_x = 213; p_y = 33; break;
        case 15: p_x = 121; p_y = 131; break;
        case 16: p_x = 198; p_y = 22; break;
        case 17: p_x = 155; p_y = 137; break;
        case 18: p_x = 33; p_y = 60; break;
        case 19:
          switch(PA_RandMax(3))
          {
            case 0: p_x = 43; p_y = 14; break;
            case 1: p_x = 192; p_y = 11; break;
            case 2: p_x = 45; p_y = 164; break;
            case 3: p_x = 195; p_y = 161; break;
            default: break;
          }
          break;
        default: p_x = 256; p_y = 0; break;
      }
      break;
//------------------------------------------------------------------------------
    case COLOR_WHITE:
      switch (p_level)
      {
        case 1: p_x = 137; p_y = 176; break;
        case 2: p_x = 0; p_y = 192; break;
        case 3: p_x = 146; p_y = 130; break;
        case 4: p_x = 176; p_y = 176; break;
        case 5: p_x = 168; p_y = 123; break;
        case 6: p_x = 168; p_y = 71; break;
        case 7: p_x = 110; p_y = 176; break;
        case 8: p_x = 115; p_y = 142; break;
        case 9: p_x = 51; p_y = 170; break;
        case 10: p_x = 124; p_y = 116; break;
        case 11: p_x = 131; p_y = 118; break;
        case 12: p_x = 184; p_y = 36; break;
        case 13: p_x = 74; p_y = 176; break;
        case 14: p_x = 17; p_y = 176; break;
        case 15: p_x = 104; p_y = 150; break;
        case 16: p_x = 21; p_y = 176; break;
        case 17: p_x = 122; p_y = 116; break;
        case 18: p_x = 120; p_y = 71; break;
        case 19: p_x = 120; p_y = 88; break;
        default: p_x = 256; p_y = 0; break;
      }
      break;
//------------------------------------------------------------------------------
    default:
      break;
  }
}

//==============================================================================

void Data::getInkQuantity(const u8 p_level, u32 &p_black, u32 &p_white, u8 &p_nbLines)
{
  switch (p_level)
  {
    case 1: p_black = 800; p_white = 0; p_nbLines = 6; break;
    case 2: p_black = INK_MAX; p_white = 0; p_nbLines = 6; break;
    case 3: p_black = 512; p_white = 512; p_nbLines = 5; break;
    case 4: p_black = 512; p_white = 300; p_nbLines = 2; break;
    case 5: p_black = 360; p_white = 850; p_nbLines = 2; break;
    case 6: p_black = 540; p_white = 540; p_nbLines = 3; break;
    case 7: p_black = 650; p_white = 620; p_nbLines = 1; break;
    case 8: p_black = 420; p_white = 320; p_nbLines = 2; break;
    case 9: p_black = 380; p_white = 570; p_nbLines = 2; break;
    case 10: p_black = 550; p_white = 220; p_nbLines = 2; break;
    case 11: p_black = 490; p_white = 190; p_nbLines = 5; break;
    case 12: p_black = 440; p_white = 840; p_nbLines = 2; break;
    case 13: p_black = 640; p_white = 640; p_nbLines = 1; break;
    case 14: p_black = INK_MAX; p_white = 660; p_nbLines = 5; break;
    case 15: p_black = 440; p_white = INK_FOR_ONE_DOT; p_nbLines = 2; break;
    case 16: p_black = 890; p_white = 540; p_nbLines = 2; break;
    case 17: p_black = 0; p_white = 240; p_nbLines = 3; break;
    case 18: p_black = 680; p_white = 690; p_nbLines = 2; break;
    case 19: p_black = INK_MAX; p_white = INK_MAX; p_nbLines = 10; break;
    case 20: p_black = 0; p_white = 0; p_nbLines = 0; break;
    default: p_black = INK_MAX; p_white = INK_MAX; p_nbLines = NB_LINES_MAX; break;
  }
}
